# Manifest

78 files listed (79 in the archive including this file) · 9.05 MB uncompressed · SHA-256 per file.

| file | bytes | sha256 (first 16) |
|---|---|---|
| `01_source/data/captions.json` | 9,891 | `0742473bceb81c8e…` |
| `01_source/data/timeline.json` | 4,190 | `7581c9a383db0f27…` |
| `01_source/scripts/build_audio_master.py` | 19,118 | `a924ec4e3afc8bc0…` |
| `01_source/scripts/build_captions.py` | 8,029 | `6224a4b1317bc5ed…` |
| `01_source/scripts/build_single_file.py` | 3,676 | `1d5b6b0c7ab43b6b…` |
| `01_source/scripts/compute_splits.py` | 1,161 | `b451252c39064b66…` |
| `01_source/scripts/gen_web_data.py` | 4,502 | `0104e01cbe7b08a3…` |
| `01_source/scripts/prepare_assets.py` | 2,712 | `e5d5b438bf619978…` |
| `01_source/scripts/transcribe_vo.py` | 874 | `45bfd237fa847cbe…` |
| `01_source/scripts/word_timing.py` | 675 | `39077c901c2ef473…` |
| `01_source/scripts/word_timing_all.py` | 778 | `42596749e9c702ae…` |
| `01_source/web/core.js` | 10,796 | `82da378e889bf9ec…` |
| `01_source/web/data.js` | 18,146 | `609c1ec6294151fb…` |
| `01_source/web/engine.js` | 13,981 | `343d3fcfacda220d…` |
| `01_source/web/film.css` | 17,737 | `883f1b160dc42087…` |
| `01_source/web/fonts.css` | 214,248 | `374518f80e681698…` |
| `01_source/web/index.html` | 5,761 | `611c7d708aa25da1…` |
| `01_source/web/scenes_a.js` | 65,898 | `97312dbdd88206b3…` |
| `01_source/web/scenes_b.js` | 83,492 | `28be03c785f9ed9c…` |
| `01_source/web/scenes_c.js` | 31,419 | `5a971f74dfec8e5f…` |
| `01_source/web/styles.css` | 15,330 | `d9101fd5eb2a65a4…` |
| `02_pipeline/encode_mp4.sh` | 697 | `428658bad9c380bd…` |
| `02_pipeline/render_mp4.py` | 2,959 | `5a24b6b203efc60d…` |
| `02_pipeline/shoot.py` | 1,378 | `a79fe06eed2cda13…` |
| `03_brand/lockup_dark.png` | 322,714 | `542721ff4219d151…` |
| `03_brand/lockup_dark.webp` | 136,028 | `014cdefa5917d389…` |
| `03_brand/lockup_light.png` | 143,612 | `50d5334b5fff559e…` |
| `03_brand/lockup_light.webp` | 77,160 | `c6b51690c5c525a5…` |
| `03_brand/mark.png` | 110,545 | `63d7745789747f3c…` |
| `03_brand/mark.webp` | 44,756 | `9431ce2ac8cb8ebf…` |
| `03_brand/mark_light.png` | 72,535 | `5a959eb80c5f882d…` |
| `03_brand/mark_light.webp` | 41,102 | `c0addbb9ac24b4b2…` |
| `03_brand/word.png` | 206,344 | `16804387541abd16…` |
| `03_brand/word.webp` | 86,144 | `da8ed61c83bad8de…` |
| `03_brand/word_light.png` | 62,229 | `749c04286bab05df…` |
| `03_brand/word_light.webp` | 32,552 | `e5896d3b32f95adb…` |
| `04_audio/vo_01_hook.mp3` | 194,578 | `d4c55288e813d55e…` |
| `04_audio/vo_02_problem.mp3` | 230,104 | `a60724741ef25a47…` |
| `04_audio/vo_03_intro.mp3` | 202,101 | `4cae9842b20ba23d…` |
| `04_audio/vo_04_student.mp3` | 257,480 | `dadb557daf0a64f0…` |
| `04_audio/vo_05_organization.mp3` | 284,857 | `072ed4f7beb4ac97…` |
| `04_audio/vo_06_university.mp3` | 234,284 | `fbd8ec649ddcbcbe…` |
| `04_audio/vo_07_admin.mp3` | 218,819 | `d43d5e607c147422…` |
| `04_audio/vo_08_09_why_build.mp3` | 229,477 | `fbabebdd4e66a91d…` |
| `04_audio/vo_10_11_arch_market.mp3` | 186,427 | `610a92fba2815340…` |
| `04_audio/vo_12_13_roadmap_close.mp3` | 199,384 | `5c667db2c845b834…` |
| `04_audio/vo_timing.json` | 1,095 | `161ba614dc594507…` |
| `04_audio/vo_transcript.json` | 8,369 | `fac1b9be5e87baed…` |
| `04_audio/word_timing.json` | 25,670 | `d91a99a9e52a930e…` |
| `05_portal_screens/admin_approvals.png` | 268,157 | `4a811940f2236a50…` |
| `05_portal_screens/admin_audit.png` | 218,365 | `196b449eaf5f83d1…` |
| `05_portal_screens/admin_dashboard.png` | 465,435 | `f5e657f9a1b35507…` |
| `05_portal_screens/admin_reviews.png` | 400,545 | `96bfa1165195094c…` |
| `05_portal_screens/admin_tickets.png` | 265,528 | `aa32f275c8c3bc9f…` |
| `05_portal_screens/org_candidates.png` | 181,774 | `666372ed14a84bc6…` |
| `05_portal_screens/org_home.png` | 232,247 | `3407712854653833…` |
| `05_portal_screens/org_pipeline.png` | 114,523 | `ea30bda4a0e7ad36…` |
| `05_portal_screens/org_post_job.png` | 129,170 | `1d0c677fc2542158…` |
| `05_portal_screens/org_requests.png` | 128,262 | `a46e8ef37810818d…` |
| `05_portal_screens/public_demo.png` | 117,256 | `e54844001be04292…` |
| `05_portal_screens/public_fairness.png` | 189,186 | `5e4c44ec2e9615d5…` |
| `05_portal_screens/public_home.png` | 477,582 | `45acb69fb4e1bec2…` |
| `05_portal_screens/student_home.png` | 277,687 | `0d65c259a68155bf…` |
| `05_portal_screens/student_resume.png` | 154,783 | `0444f410c02b9e77…` |
| `05_portal_screens/student_scorecard.png` | 221,005 | `4efe5ceffb9cb94a…` |
| `05_portal_screens/student_sharing.png` | 119,157 | `9333e1cf088b43ba…` |
| `05_portal_screens/student_submit.png` | 145,599 | `a2e4c4a46c4ed2f2…` |
| `05_portal_screens/uni_overview.png` | 332,679 | `b904329f21d104ff…` |
| `05_portal_screens/uni_placements.png` | 166,773 | `d1138c969d11d84f…` |
| `05_portal_screens/uni_skills.png` | 258,794 | `0c5c51ff8fa1f8ca…` |
| `06_capture_tooling/crawl_all_portals.py` | 8,437 | `2f67040fc738aaed…` |
| `06_capture_tooling/crawl_deep.py` | 7,225 | `888c37fd94945109…` |
| `06_capture_tooling/crawl_finish.py` | 6,849 | `474544431e6922fe…` |
| `06_capture_tooling/crawl_spa_nav.py` | 5,196 | `45751655dbd3e331…` |
| `06_capture_tooling/discover_routes.py` | 1,457 | `4b2c8679f0fb8f3e…` |
| `README.md` | 4,379 | `015d208d3f3f90ec…` |
| `SECURITY.md` | 2,277 | `f85339a2b1be0db4…` |
| `SUMMARY.md` | 3,425 | `e3e86bad27912f67…` |

## Full checksums

```
0742473bceb81c8ebe4330a54f326bcb0e7f4191a6578570be3a1a93f623e6d9  01_source/data/captions.json
7581c9a383db0f2717c07e24c893cb3fa8243ed96eca114ba313288322ccbb56  01_source/data/timeline.json
a924ec4e3afc8bc043f8f8f57d467640c17a684d0cda0d3b0d5968ec18cd73be  01_source/scripts/build_audio_master.py
6224a4b1317bc5ed2b6e63e9aada6de22b70f38857066cc412e1d009da552e81  01_source/scripts/build_captions.py
1d5b6b0c7ab43b6bee8fe56a7d3edcbc1df259ee514516165d50ff143252dfb6  01_source/scripts/build_single_file.py
b451252c39064b66a4ba40cdf5b37df6fce05eb465304964e9c8a9136a4f8188  01_source/scripts/compute_splits.py
0104e01cbe7b08a3676ae5bdb974634a7cb74c2aa582b72fa840702d6d886491  01_source/scripts/gen_web_data.py
e5d5b438bf619978e4b35cd6a13f7a1d6c68038661de87729d77cf5f0a5d8a77  01_source/scripts/prepare_assets.py
45bfd237fa847cbe6255b73f4d32590f921d5116a9a505cdec75694393feded2  01_source/scripts/transcribe_vo.py
39077c901c2ef4739625b1fb4da442bb109339002568a1db88b6c5df60c37a99  01_source/scripts/word_timing.py
42596749e9c702aeac00ec16cfcaea9ae17e227bf17248590cdcbbb4126f0952  01_source/scripts/word_timing_all.py
82da378e889bf9ecd6a6d091e345fa1c7ef945533667e0a84dfefff629cb58e4  01_source/web/core.js
609c1ec6294151fb7cdbbbf01f7c9dc8ba303617a01de0b056c00f391233b37d  01_source/web/data.js
343d3fcfacda220db4a8adda8d7da86e8c0433f48b6ddb0dad8cae9cc4e82009  01_source/web/engine.js
883f1b160dc420878021c3544442bdd97e322025138d9c0cbbd3e5c3c9cfc2b8  01_source/web/film.css
374518f80e681698856e451466f11e5a9194ff2d32cb75cf4b04d8a2a097e46e  01_source/web/fonts.css
611c7d708aa25da13b4eeafa4b491d44e8b4fd0dc86f79eecf488f794e62db3b  01_source/web/index.html
97312dbdd88206b32ab1b6cdabf6ebccd897f1f6a1c6d123f218c1fff3358977  01_source/web/scenes_a.js
28be03c785f9ed9c9ff560247e07971db5a97ce99a88002b88bfc1a3e6856d57  01_source/web/scenes_b.js
5a971f74dfec8e5f2000074eeb48e9c6fb0501a851a2e18a2a82e1376c075af1  01_source/web/scenes_c.js
d9101fd5eb2a65a4bccd059b4664d78bb9ae9b189e7271ea6a8cec00136f2ef1  01_source/web/styles.css
428658bad9c380bdc2ace9e590457343ee86c0048f97fb657a3d11aed2ec3760  02_pipeline/encode_mp4.sh
5a24b6b203efc60d5b6ff480302afede2dd62f6f731280ed5b8eff9d37f0996a  02_pipeline/render_mp4.py
a79fe06eed2cda131c81a08ad484fa72ff83136788adedfdad7077aeb35d4083  02_pipeline/shoot.py
542721ff4219d151ab0795d9f03bd6ddd8a84deb2166819a7810b41b65d22e26  03_brand/lockup_dark.png
014cdefa5917d389239fc2cb5d549e0e66c34f8169a073d54a6762e657821889  03_brand/lockup_dark.webp
50d5334b5fff559e2cf8e18bc11f5d5c24f374f48cc540b3d4bca44040226a60  03_brand/lockup_light.png
c6b51690c5c525a5b742a18425661fb594439affeb8fcf9f32596212f96e449b  03_brand/lockup_light.webp
63d7745789747f3cda8125c85f78f4c9b51a6f0d072f6bcca04c8273903f97e8  03_brand/mark.png
9431ce2ac8cb8ebfa8e1228434cbbdf8fb0683701f2a2b3f0033a4de5d5181b2  03_brand/mark.webp
5a959eb80c5f882d94584347c4096b8084fc1861a773cf2de5a47a3da311cb48  03_brand/mark_light.png
c0addbb9ac24b4b2b797e4bd9a8324cd5070a1db067c9b3eef4cf742880203b9  03_brand/mark_light.webp
16804387541abd165b417a0e20b22e908eadd57cd930207082617147d32d9fad  03_brand/word.png
da8ed61c83bad8de1223082237c61e87b443ec4f412e53b62b6a2747637fe273  03_brand/word.webp
749c04286bab05df4c33ef833004b5aae5a9a0a05665133a62642ea6c0396e63  03_brand/word_light.png
e5896d3b32f95adb84ffdccaa54a80ec43a12b992c1556bfde677f658b82a8ee  03_brand/word_light.webp
d4c55288e813d55e59bd17ede95457f2a59b2c04ba63d06adaf37e1d8f92b8df  04_audio/vo_01_hook.mp3
a60724741ef25a474425b3a1ffe27ecbdcd8e579978d4180afa97a67ff4e5f78  04_audio/vo_02_problem.mp3
4cae9842b20ba23df2ccf98388555f236b27faf68108e93f2b9f47695ddb0119  04_audio/vo_03_intro.mp3
dadb557daf0a64f046eae2b81a73d8b6f171bf7df19f19cefd62b88342969ac2  04_audio/vo_04_student.mp3
072ed4f7beb4ac97c78b2a7d8bf1415475ba1d44e24b0b3121525aa421445a3f  04_audio/vo_05_organization.mp3
fbd8ec649ddcbcbe9a9c227d6a1c1d2a61d66cb69b44a5340be324a977c08355  04_audio/vo_06_university.mp3
d43d5e607c147422f8de2f20b0483338b78002792f69c007f01cd54f33b6d6b2  04_audio/vo_07_admin.mp3
fbabebdd4e66a91d5d78987719b67e34f89e7a42bfc0fb3bf9d38b5ca9bbe1a0  04_audio/vo_08_09_why_build.mp3
610a92fba2815340c49a79d8ae7f8bd2c7e5aa7037e485c47ec4154f89961e53  04_audio/vo_10_11_arch_market.mp3
5c667db2c845b834e386f100550cdda3503fc9b415ac7b4552e835fe14f07f7b  04_audio/vo_12_13_roadmap_close.mp3
161ba614dc594507cb5e8353307f2a330c4076a835dbc5a934d69739f4147bf6  04_audio/vo_timing.json
fac1b9be5e87baed5b558f0e2e92e744736a70bafa791b3aaebcc9fb4fa302af  04_audio/vo_transcript.json
d91a99a9e52a930e0ce563a8327fece7d3e0a9065bd3678b3b0897a1805303b3  04_audio/word_timing.json
4a811940f2236a502d682423b137454479309e58e261b6e4e9fe08458bbf9060  05_portal_screens/admin_approvals.png
196b449eaf5f83d12db1400cdabd9db52f8e249f08b110e0d6f28e31aa85d396  05_portal_screens/admin_audit.png
f5e657f9a1b3550723e5cb475e22a9665809520510c4fdd542d26c32fac5b276  05_portal_screens/admin_dashboard.png
96bfa1165195094c02fcc46b3daa089b895593fadafb0b7e028f2cf7c35380d3  05_portal_screens/admin_reviews.png
aa32f275c8c3bc9f4dca64bf2c607673bc7f3cbd4641243e7883eef7dba7a6a8  05_portal_screens/admin_tickets.png
666372ed14a84bc6977a1ddad898b0f8b2f8900c49881b6a508a60f7715bb1cc  05_portal_screens/org_candidates.png
3407712854653833409529d41e567757dc3d3aa99bc4a7c67eb87b3590da7ade  05_portal_screens/org_home.png
ea30bda4a0e7ad36f34a15a3b61364ac3c157aa4e690ab2ecec639de29429a0e  05_portal_screens/org_pipeline.png
1d0c677fc254215830382a3bee0d7e04881d2353c1fbb3536c9c25fe41d3f8ed  05_portal_screens/org_post_job.png
a46e8ef37810818de431a855e2e90d60ba5c6df2dc30bc3f06b893eaece23332  05_portal_screens/org_requests.png
e54844001be04292fba5fd8eed1dee13e191537200c931b3a59b61a8147fb48f  05_portal_screens/public_demo.png
5e4c44ec2e9615d5b3ee89c9f8d33b8862df5a105cc1c044bb5f00412096614c  05_portal_screens/public_fairness.png
45acb69fb4e1bec25c159d7eb2a7d3a44384776861fe8a787fcd48e0c52062b6  05_portal_screens/public_home.png
0d65c259a68155bf53cc979bf6e35648767791c1b948436deb0af0112d30b28c  05_portal_screens/student_home.png
0444f410c02b9e7776b42146702d4789123b9d02b72be430899f7a776cd8a41d  05_portal_screens/student_resume.png
4efe5ceffb9cb94aaf8c8b6a76b4a5d4f5d61bbf70598fa4f306b1b7e12730e4  05_portal_screens/student_scorecard.png
9333e1cf088b43ba87d796a444502365dd1dae7f06fd268dc99616e8a14fe055  05_portal_screens/student_sharing.png
a2e4c4a46c4ed2f25aad170279dcefa81c7bcd5201cf1c6745f975814d06b698  05_portal_screens/student_submit.png
b904329f21d104ff571eb5800cd3fd5f624d23f6b21bf747a1ee2fb3e995ee94  05_portal_screens/uni_overview.png
d1138c969d11d84f8f43b1f7b49f6a6ec9707cade64388d724764b31a62a893b  05_portal_screens/uni_placements.png
0c5c51ff8fa1f8ca21895232ccb4584f312d483af465308c11db61517a423a67  05_portal_screens/uni_skills.png
2f67040fc738aaed18859f7d9773a8507e9647f96273a9f0bafd0923f569da2b  06_capture_tooling/crawl_all_portals.py
888c37fd94945109bcca3515286cdf5a7fd71137eb9715e8645b3180c72c3e14  06_capture_tooling/crawl_deep.py
474544431e6922fe5d11ed77b1eab37c2d413ca78f7558d462964642d669c99f  06_capture_tooling/crawl_finish.py
45751655dbd3e3312d7cb83dca8b1b3f1183984708ad511738eacef4ebb60f7a  06_capture_tooling/crawl_spa_nav.py
4b2c8679f0fb8f3eac025b07ea22537f30900311d9d162aa7bc4de942a65234f  06_capture_tooling/discover_routes.py
015d208d3f3f90ecfb3a40c71e4214a01dd1f0049f09872c6d0adf861ff75b19  README.md
f85339a2b1be0db44bf8de7e1f09f40fbb30b8107413e1f2a2d4fa6b1b6a0b79  SECURITY.md
e3e86bad27912f67eed58cda0fe7bf86181dfca2ff003edc4dfa068cf7a6f15b  SUMMARY.md
```
