import sys, asyncio, os
from playwright.async_api import async_playwright
times = [float(x) for x in sys.argv[1].split(",")]
outdir = sys.argv[2]; os.makedirs(outdir, exist_ok=True)
SRC = "file://project/AptoHire_Interactive_Film.html?render=1"
async def main():
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path="/usr/bin/chromium",
            args=["--no-sandbox","--disable-dev-shm-usage","--hide-scrollbars","--mute-audio",
                  "--force-device-scale-factor=1","--disable-lcd-text"])
        ctx = await b.new_context(viewport={"width":1920,"height":1080})
        pg = await ctx.new_page()
        errs=[]; pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(SRC, wait_until="load")
        await pg.wait_for_function("window.__ready === true", timeout=30000)
        await pg.evaluate("document.fonts.ready"); await pg.wait_for_timeout(500)
        for t in times:
            await pg.evaluate(f"window.__seekTo({t})")
            await pg.evaluate("() => new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)))")
            pg_out = os.path.join(outdir, f"f_{t:09.3f}.png")
            if os.path.exists(pg_out): os.remove(pg_out)
            await pg.screenshot(path=pg_out)
        if errs: print("JS ERRORS:", errs[:4])
        await b.close()
asyncio.run(main())
print("done")
