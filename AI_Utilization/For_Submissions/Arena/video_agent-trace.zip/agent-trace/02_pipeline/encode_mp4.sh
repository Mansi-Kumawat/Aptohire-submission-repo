#!/bin/sh
set -e
AUDIO=project/audio/master_soundtrack.mp3
OUT=project/AptoHire_Product_Film_1080p.mp4
# CFR 30fps + the -14 LUFS master. Threads/lookahead capped: the box has 1 GB RAM.
ffmpeg -y -hide_banner -loglevel warning \
  -threads 2 -filter_threads 1 \
  -framerate 30 -i /var/tmp/rt/frames/%06d.jpg \
  -i "$AUDIO" \
  -map 0:v -map 1:a \
  -c:v libx264 -preset veryfast -crf 20 -pix_fmt yuv420p \
  -profile:v high -level 4.1 -g 60 -keyint_min 30 \
  -x264-params "threads=3:rc-lookahead=15:ref=3:bframes=3:sync-lookahead=0" \
  -colorspace bt709 -color_primaries bt709 -color_trc bt709 \
  -c:a aac -b:a 192k -ar 48000 -ac 2 \
  -movflags +faststart -shortest \
  "$OUT"
ls -lh "$OUT"
