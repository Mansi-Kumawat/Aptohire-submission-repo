"""Deterministic frame-accurate capture of the film -> MP4.
Renders the single-file deliverable in ?render=1 at t = k/30 for the full runtime,
then encodes with the -14 LUFS master. Resumable: existing frames are skipped.
"""
import asyncio, os, sys, time
from playwright.async_api import async_playwright

FPS      = 30
TOTAL    = 309.75
SRC      = "file://project/AptoHire_Interactive_Film.html?render=1"
OUTDIR   = "/var/tmp/rt/frames"
NFRAMES  = int(round(TOTAL * FPS))

async def main():
    os.makedirs(OUTDIR, exist_ok=True)
    have = sum(1 for k in range(NFRAMES) if os.path.exists(os.path.join(OUTDIR, f"{k:06d}.jpg")))
    print(f"frames to render: {NFRAMES - have} of {NFRAMES}", flush=True)

    async with async_playwright() as p:
        b = await p.chromium.launch(
            executable_path="/usr/bin/chromium",
            args=["--no-sandbox", "--disable-dev-shm-usage", "--hide-scrollbars",
                  "--mute-audio", "--force-device-scale-factor=1", "--disable-gpu",
                  "--disable-lcd-text", "--force-color-profile=srgb",
                  "--disable-features=CalculateNativeWinOcclusion",
                  "--js-flags=--max-old-space-size=256"])
        ctx = await b.new_context(viewport={"width": 1920, "height": 1080},
                                  device_scale_factor=1)
        pg = await ctx.new_page()
        errs = []
        pg.on("pageerror", lambda e: errs.append(str(e)))
        await pg.goto(SRC, wait_until="load", timeout=60000)
        await pg.wait_for_function("window.__ready === true", timeout=60000)
        await pg.evaluate("document.fonts.ready")
        await pg.wait_for_timeout(600)
        # discover the real runtime from the engine (guard against drift)
        total = await pg.evaluate("window.__film.total")
        print(f"engine total: {total}s  ->  {int(round(total*FPS))} frames", flush=True)

        cdp = await ctx.new_cdp_session(pg)
        t0 = time.time(); done = 0
        for k in range(NFRAMES):
            path = os.path.join(OUTDIR, f"{k:06d}.jpg")
            if os.path.exists(path):
                continue
            tt = k / FPS
            await pg.evaluate(f"window.__seekTo({tt:.5f})")
            r = await cdp.send("Page.captureScreenshot",
                               {"format": "jpeg", "quality": 95, "optimizeForSpeed": True})
            with open(path + ".part", "wb") as f:
                import base64
                f.write(base64.b64decode(r["data"]))
            os.replace(path + ".part", path)
            done += 1
            if done % 100 == 0:
                el = time.time() - t0
                per = el / done
                left = (NFRAMES - have - done) * per
                print(f"{k+1}/{NFRAMES}  {per*1000:.0f} ms/f  eta {left/60:.1f} min", flush=True)
        if errs:
            print("JS ERRORS:", errs[:6], flush=True)
        print("CAPTURE_DONE", flush=True)
        await b.close()

asyncio.run(main())
