# Summary

A one-page account of what this archive is, what was in it, and what was
deliberately left out. Written to be read first.

---

## What was delivered

**`agent-trace.zip`** — 8.1 MB compressed, 79 files (9.05 MB unpacked).
A build record for the AptoHire product film, structured so someone else can
rebuild or audit it rather than just admire it.

```
agent-trace/
├── README.md              what the film is, rebuild steps, the 13 scenes
├── SUMMARY.md             this file
├── MANIFEST.md            every file + SHA-256 checksums
├── SECURITY.md            what was redacted, excluded, and why
├── 01_source/             the film itself (editable)
│   ├── web/               index.html, core.js, engine.js, scenes_a|b|c.js, film.css …
│   ├── scripts/           the 11-step build chain, in order
│   └── data/              timeline.json, captions.json
├── 02_pipeline/           render_mp4.py, encode_mp4.sh, shoot.py
├── 03_brand/              logo kit — lockup / mark / word, dark + light, PNG + WebP
├── 04_audio/              10 narration takes + word timings
├── 05_portal_screens/     21 screenshots the film is built from
└── 06_capture_tooling/    the crawlers that produced them
```

---

## Sensitive data — found and removed

The one real exposure was the **admin two-factor setup screen**. It displays a
TOTP secret in plain text *and* its enrolment QR in the pixels — together, a
working second factor for the demo admin account.

| Removed | Where it lived |
|---|---|
| MFA screen + QR | 2 PNGs in `captures/`, 2 in `captures_v2/`, plus the account-security page |
| The secret as text | `deep_report.json`, `portal_report.json` — accessibility dumps reproducing it ~20× |
| Hardcoded demo passwords | `crawl_spa_nav.py`, `crawl_deep.py` → now `os.environ.get("APTOHIRE_DEMO_PASSWORD", "")` |

Also stripped: absolute local build paths, and demo-account email addresses
normalised to `@demo.example`.

### Verified, not assumed

The finished ZIP was re-extracted and checked three ways:

1. **Zero** secret strings in any text file.
2. **Zero** MFA screens by SHA-256 comparison against the known originals.
3. **Pixel-level** comparison of the exact secret region (x 610–950, y 495–555)
   against all 21 shipped screenshots — no match.

Plus: shipped `scenes_a.js` confirmed to contain the 1:01 fix, all JS passes a
parser, and `timeline.json` still reads 309.75 s / 13 scenes / 103 caption cues.

---

## Two deliberate judgement calls

**Kept** — the 21 portal screenshots. They contain demo names and candidate IDs
like `K7F2`, but the product labels every page *"All people, universities and
organizations shown are fictional / Demo only · No real candidate data."* They
are the visual evidence for the film's claims, so they belong in a build record.

**Excluded for size, not secrecy** — the 7.4 MB audio master, 2.1 MB of derived
WebPs, the font binaries, and 210 of the 231 screenshots. All regenerable with
`prepare_assets.py`, and documented as such in `SECURITY.md`.

---

## One thing worth flagging

The demo passwords sat in the crawler scripts, and a demo MFA secret was sitting
in the audit captures. This archive is clean now, but if that demo deployment is
still live, the admin enrolment is worth rotating — the secret existed in the
working files for a while.
