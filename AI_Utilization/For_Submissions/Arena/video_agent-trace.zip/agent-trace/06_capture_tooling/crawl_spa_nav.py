import asyncio, os, json
from playwright.async_api import async_playwright

# Demo password is supplied at run time — never committed.
DEMO_PASSWORD = os.environ.get("APTOHIRE_DEMO_PASSWORD", "")

OUT_DIR = "audit/captures_v2"

async def snap(page, slug, wait_ms=1500):
    await page.wait_for_timeout(wait_ms)
    await page.screenshot(path=os.path.join(OUT_DIR, f"{slug}.png"), full_page=False)
    await page.screenshot(path=os.path.join(OUT_DIR, f"{slug}_full.png"), full_page=True)
    text = await page.evaluate("() => document.body.innerText")
    return {"slug": slug, "url": page.url, "text": text}

async def spa_student(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-student.vercel.app/login", wait_until="networkidle")
    await page.get_by_text("Aarav Sharma", exact=False).first.click()
    await page.wait_for_timeout(2000)
    out.append(await snap(page, "stu_home", 1200))
    for nav_label, slug in [("Projects", "stu_projects"), ("Scorecard", "stu_scorecard"), ("Sharing", "stu_sharing"), ("Resume", "stu_resume"), ("Profile", "stu_profile")]:
        lk = page.locator("nav a, aside a").filter(has_text=nav_label).first
        if await lk.count() > 0:
            await lk.click()
            out.append(await snap(page, slug, 1500))
    await ctx.close()
    return out

async def spa_org(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-organization.vercel.app/login", wait_until="networkidle")
    # Click Northwind Labs demo button directly and check what happens
    btns = page.locator("button").filter(has_text="Northwind Labs")
    if await btns.count() > 0:
        await btns.first.click()
    else:
        await page.get_by_text("Northwind Labs", exact=False).first.click()
    await page.wait_for_timeout(2000)
    if "/login" in page.url:
        pw = page.locator("input[type='password']").first
        await pw.fill(DEMO_PASSWORD)
        await page.locator("button[type='submit']").first.click()
        await page.wait_for_timeout(2000)
    out.append(await snap(page, "org_home", 1200))
    nav_links = await page.evaluate("() => Array.from(document.querySelectorAll('nav a, aside a')).map(a => ({text: a.innerText.trim(), href: a.getAttribute('href')}))")
    print("Org nav links:", nav_links)
    for item in nav_links:
        t = item["text"].splitlines()[0] if item["text"] else ""
        if not t:
            continue
        slug = "org_" + t.lower().replace(" ", "_").replace("&", "and")
        lk = page.locator("nav a, aside a").filter(has_text=t).first
        if await lk.count() > 0:
            await lk.click()
            out.append(await snap(page, slug, 1400))
    # Also click into first job or candidate if present
    job_a = page.locator("a[href*='/jobs/']").first
    if await job_a.count() > 0:
        await job_a.click()
        out.append(await snap(page, "org_job_view", 1400))
    await ctx.close()
    return out

async def spa_admin(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-admin.vercel.app/login", wait_until="networkidle")
    await page.get_by_text("Continue with demo account", exact=False).first.click()
    await page.wait_for_timeout(2200)
    if "mfa" in page.url:
        inp = page.locator("input").first
        await inp.click()
        await inp.type("123456", delay=50)
        await page.wait_for_timeout(400)
        btn = page.get_by_role("button", name="Verify", exact=False)
        if await btn.count() > 0 and await btn.first.is_enabled():
            await btn.first.click()
        await page.wait_for_timeout(2200)
    out.append(await snap(page, "adm_dashboard", 1400))
    nav_links = await page.evaluate("() => Array.from(document.querySelectorAll('nav a, aside a')).map(a => ({text: a.innerText.trim(), href: a.getAttribute('href')}))")
    print("Admin nav links:", nav_links)
    for item in nav_links:
        t = item["text"].splitlines()[0] if item["text"] else ""
        if not t:
            continue
        slug = "adm_" + t.lower().replace(" ", "_").replace("&", "and")
        lk = page.locator("nav a, aside a").filter(has_text=t).first
        if await lk.count() > 0:
            await lk.click()
            out.append(await snap(page, slug, 1400))
    await ctx.close()
    return out

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-dev-shm-usage"])
        stu, org, adm = await asyncio.gather(spa_student(browser), spa_org(browser), spa_admin(browser))
        await browser.close()
    with open("audit/spa_report.json", "w") as f:
        json.dump({"student": stu, "organization": org, "admin": adm}, f, indent=2)
    for k, v in [("student", stu), ("organization", org), ("admin", adm)]:
        print(k, "->", [(x["slug"], x["url"]) for x in v])

asyncio.run(main())
