import asyncio, os, os, json
from playwright.async_api import async_playwright

OUT_DIR = "audit/captures"

async def grab(page, slug, wait_ms=1000):
    await page.wait_for_timeout(wait_ms)
    img_path = os.path.join(OUT_DIR, f"{slug}.png")
    if not os.path.exists(img_path):
        await page.screenshot(path=img_path, full_page=False)
    text = await page.evaluate("() => document.body.innerText")
    return {"url": page.url, "slug": slug, "text": text[:5000]}

async def crawl_public(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    res = []
    for route, slug in [("/", "public_home"), ("/demo", "public_demo"), ("/verify/9efdf52c1c90863fa1", "public_verify"), ("/pricing", "public_pricing"), ("/ai-and-fairness", "public_fairness")]:
        await page.goto(f"https://aptohire.vercel.app{route}", wait_until="domcontentloaded")
        res.append(await grab(page, slug, 800))
    await ctx.close()
    return res

async def crawl_student(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    res = []
    await page.goto("https://aptohire-student.vercel.app/login", wait_until="networkidle")
    await page.get_by_text("Aarav Sharma", exact=False).first.click()
    await page.wait_for_timeout(1500)
    res.append(await grab(page, "student_dashboard", 800))
    for route, slug in [("/scorecard", "student_scorecard"), ("/scorecard/react", "student_scorecard_react"), ("/projects", "student_projects"), ("/sharing", "student_sharing"), ("/resume", "student_resume"), ("/profile", "student_profile")]:
        await page.goto(f"https://aptohire-student.vercel.app{route}", wait_until="domcontentloaded")
        res.append(await grab(page, slug, 900))
    # also grab project detail
    await page.goto("https://aptohire-student.vercel.app/projects", wait_until="domcontentloaded")
    await page.wait_for_timeout(800)
    hrefs = await page.evaluate("() => Array.from(document.querySelectorAll('a')).map(a => a.href)")
    for h in hrefs:
        if ("/projects/" in h and not h.endswith("/new")) or "/submissions/" in h:
            await page.goto(h, wait_until="domcontentloaded")
            res.append(await grab(page, "student_project_detail", 1000))
            break
    await ctx.close()
    return res

async def crawl_org(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    res = []
    await page.goto("https://aptohire-organization.vercel.app/login", wait_until="networkidle")
    await page.get_by_text("Northwind Labs", exact=False).first.click()
    await page.wait_for_timeout(1500)
    res.append(await grab(page, "org_dashboard", 800))
    for route, slug in [("/jobs/new", "org_jobs_new"), ("/candidates", "org_candidates"), ("/requests", "org_requests"), ("/pipeline", "org_pipeline"), ("/directory", "org_directory")]:
        await page.goto(f"https://aptohire-organization.vercel.app{route}", wait_until="domcontentloaded")
        res.append(await grab(page, slug, 900))
    await page.goto("https://aptohire-organization.vercel.app/", wait_until="domcontentloaded")
    await page.wait_for_timeout(800)
    hrefs = await page.evaluate("() => Array.from(document.querySelectorAll('a')).map(a => a.href)")
    for h in hrefs:
        if "/jobs/" in h and not h.endswith("/new") and not h.endswith("/edit"):
            await page.goto(h, wait_until="domcontentloaded")
            res.append(await grab(page, "org_job_detail", 1000))
            break
    await ctx.close()
    return res

async def crawl_uni(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    res = []
    await page.goto("https://aptohire-university.vercel.app/login", wait_until="networkidle")
    await page.get_by_text("Aravalli Institute", exact=False).first.click()
    await page.wait_for_timeout(1200)
    if "/login" in page.url:
        btn = page.locator("button[type='submit']").first
        if await btn.count() > 0 and await btn.is_enabled():
            await btn.click()
            await page.wait_for_timeout(1500)
    res.append(await grab(page, "uni_dashboard", 900))
    for route, slug in [("/roster", "uni_roster"), ("/students", "uni_students"), ("/skills", "uni_skills"), ("/placements", "uni_placements"), ("/directory", "uni_directory")]:
        await page.goto(f"https://aptohire-university.vercel.app{route}", wait_until="domcontentloaded")
        res.append(await grab(page, slug, 900))
    await ctx.close()
    return res

async def crawl_admin(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    res = []
    await page.goto("https://aptohire-admin.vercel.app/login", wait_until="networkidle")
    await page.get_by_text("Continue with demo account", exact=False).first.click()
    await page.wait_for_timeout(1200)
    if "mfa" in page.url:
        inputs = page.locator("input")
        cnt = await inputs.count()
        if cnt == 1:
            await inputs.first.fill("123456")
        elif cnt >= 6:
            for idx, ch in enumerate("123456"):
                await inputs.nth(idx).fill(ch)
        await page.wait_for_timeout(1800)
        if "mfa" in page.url:
            btn = page.locator("button[type='submit']").first
            if await btn.count() > 0 and await btn.is_enabled():
                await btn.click()
                await page.wait_for_timeout(1500)
    res.append(await grab(page, "admin_dashboard", 1200))
    for route, slug in [("/approvals", "admin_approvals"), ("/reviews", "admin_reviews"), ("/tickets", "admin_tickets"), ("/runs", "admin_runs"), ("/library", "admin_library"), ("/audit-log", "admin_audit_log"), ("/reports", "admin_reports"), ("/users", "admin_users"), ("/settings", "admin_settings")]:
        await page.goto(f"https://aptohire-admin.vercel.app{route}", wait_until="domcontentloaded")
        res.append(await grab(page, slug, 1000))
    await ctx.close()
    return res

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-dev-shm-usage"])
        pub, stu, org, uni, adm = await asyncio.gather(
            crawl_public(browser),
            crawl_student(browser),
            crawl_org(browser),
            crawl_uni(browser),
            crawl_admin(browser)
        )
        await browser.close()
    report = {"public": pub, "student": stu, "organization": org, "university": uni, "admin": adm}
    with open("audit/portal_report.json", "w") as f:
        json.dump(report, f, indent=2)
    print("ALL 5 PORTALS CRAWLED SUCCESSFULLY!")

asyncio.run(main())
