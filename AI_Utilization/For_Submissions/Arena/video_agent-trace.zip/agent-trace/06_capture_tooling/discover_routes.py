import urllib.request, re, json

apps = {
    "public": "https://aptohire.vercel.app",
    "student": "https://aptohire-student.vercel.app",
    "university": "https://aptohire-university.vercel.app",
    "organization": "https://aptohire-organization.vercel.app",
    "admin": "https://aptohire-admin.vercel.app",
}

for name, base in apps.items():
    url = base if name == "public" else base + "/login"
    html = urllib.request.urlopen(url, timeout=15).read().decode("utf-8", "ignore")
    scripts = re.findall(r'src="([^"]+\.js)"', html)
    css_links = re.findall(r'href="([^"]+\.css)"', html)
    print(f"=== {name.upper()} ({base}) ===")
    for s in scripts:
        surl = s if s.startswith("http") else base + s
        js = urllib.request.urlopen(surl, timeout=15).read().decode("utf-8", "ignore")
        paths = sorted(set(re.findall(r'path:\s*["`]([^"`]+)["`]', js)))
        print("  Routes:", paths)
        if name == "admin":
            roles = sorted(set(re.findall(r'role[s]?:\s*["`\[]([^"`\]]+)["`\]]', js)))
            demos = re.findall(r'[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.test', js)
            print("  Admin emails:", sorted(set(demos)))
    for c in css_links:
        curl = c if c.startswith("http") else base + c
        css = urllib.request.urlopen(curl, timeout=15).read().decode("utf-8", "ignore")
        vars_found = re.findall(r'(--[a-zA-Z0-9-]+:\s*[^;\}]+)', css)
        print("  CSS vars sample:", vars_found[:15])
