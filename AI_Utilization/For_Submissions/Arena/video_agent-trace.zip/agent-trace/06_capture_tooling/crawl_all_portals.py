import asyncio, os, os, json
from playwright.async_api import async_playwright

OUT_DIR = "audit/captures"
os.makedirs(OUT_DIR, exist_ok=True)

async def dump_page(page, slug, wait_ms=1500):
    await page.wait_for_timeout(wait_ms)
    img_path = os.path.join(OUT_DIR, f"{slug}.png")
    await page.screenshot(path=img_path, full_page=False)
    full_img_path = os.path.join(OUT_DIR, f"{slug}_full.png")
    await page.screenshot(path=full_img_path, full_page=True)
    text = await page.evaluate("() => document.body.innerText")
    links = await page.evaluate("() => Array.from(document.querySelectorAll('a')).map(a => ({text: a.innerText.trim(), href: a.href})).filter(x => x.text || x.href)")
    return {"url": page.url, "slug": slug, "text": text[:6000], "links": links[:40]}

async def main():
    report = {}
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-dev-shm-usage"])

        # 1. PUBLIC SITE
        ctx = await browser.new_context(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page = await ctx.new_page()
        report["public"] = []
        for route, slug in [("/", "public_home"), ("/demo", "public_demo"), ("/verify/9efdf52c1c90863fa1", "public_verify"), ("/pricing", "public_pricing"), ("/ai-and-fairness", "public_fairness")]:
            await page.goto(f"https://aptohire.vercel.app{route}", wait_until="networkidle")
            report["public"].append(await dump_page(page, slug, 1500))
        await ctx.close()

        # 2. STUDENT PORTAL (Aarav Sharma)
        ctx = await browser.new_context(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page = await ctx.new_page()
        report["student"] = []
        await page.goto("https://aptohire-student.vercel.app/login", wait_until="networkidle")
        report["student"].append(await dump_page(page, "student_login", 1000))
        # Click Aarav Sharma demo button
        btn = page.get_by_text("Aarav Sharma", exact=False).first
        await btn.click()
        await page.wait_for_timeout(2000)
        report["student"].append(await dump_page(page, "student_dashboard", 1500))
        for route, slug in [("/scorecard", "student_scorecard"), ("/scorecard/react", "student_scorecard_react"), ("/projects", "student_projects"), ("/projects/new", "student_projects_new"), ("/sharing", "student_sharing"), ("/resume", "student_resume"), ("/profile", "student_profile")]:
            try:
                await page.goto(f"https://aptohire-student.vercel.app{route}", wait_until="networkidle")
                report["student"].append(await dump_page(page, slug, 1200))
            except Exception as e:
                print("Student err", route, e)
        # Check first project/submission link if found
        for item in report["student"]:
            for lk in item["links"]:
                if "/submissions/" in lk["href"] or ("/projects/" in lk["href"] and not lk["href"].endswith("/new")):
                    await page.goto(lk["href"], wait_until="networkidle")
                    report["student"].append(await dump_page(page, "student_submission_detail", 1200))
                    break
            if any(x["slug"] == "student_submission_detail" for x in report["student"]):
                break
        await ctx.close()

        # 3. ORGANIZATION PORTAL (Northwind Labs)
        ctx = await browser.new_context(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page = await ctx.new_page()
        report["organization"] = []
        await page.goto("https://aptohire-organization.vercel.app/login", wait_until="networkidle")
        report["organization"].append(await dump_page(page, "org_login", 1000))
        await page.get_by_text("Northwind Labs", exact=False).first.click()
        await page.wait_for_timeout(2000)
        report["organization"].append(await dump_page(page, "org_dashboard", 1500))
        for route, slug in [("/jobs/new", "org_jobs_new"), ("/candidates", "org_candidates"), ("/requests", "org_requests"), ("/pipeline", "org_pipeline"), ("/directory", "org_directory")]:
            try:
                await page.goto(f"https://aptohire-organization.vercel.app{route}", wait_until="networkidle")
                report["organization"].append(await dump_page(page, slug, 1200))
            except Exception as e:
                print("Org err", route, e)
        # Also visit first job detail if linked
        for item in report["organization"]:
            for lk in item["links"]:
                if "/jobs/" in lk["href"] and not lk["href"].endswith("/new") and not lk["href"].endswith("/edit"):
                    await page.goto(lk["href"], wait_until="networkidle")
                    report["organization"].append(await dump_page(page, "org_job_detail", 1200))
                    break
            if any(x["slug"] == "org_job_detail" for x in report["organization"]):
                break
        await ctx.close()

        # 4. UNIVERSITY PORTAL (Aravalli Institute)
        ctx = await browser.new_context(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page = await ctx.new_page()
        report["university"] = []
        await page.goto("https://aptohire-university.vercel.app/login", wait_until="networkidle")
        report["university"].append(await dump_page(page, "uni_login", 1000))
        await page.get_by_text("Aravalli Institute", exact=False).first.click()
        await page.wait_for_timeout(1500)
        # Check if clicking filled form or signed in directly
        if "/login" in page.url:
            btn_sign = page.locator("button[type='submit']").first
            if await btn_sign.count() > 0:
                await btn_sign.click()
                await page.wait_for_timeout(2000)
        report["university"].append(await dump_page(page, "uni_dashboard", 1500))
        for route, slug in [("/roster", "uni_roster"), ("/students", "uni_students"), ("/skills", "uni_skills"), ("/placements", "uni_placements"), ("/directory", "uni_directory")]:
            try:
                await page.goto(f"https://aptohire-university.vercel.app{route}", wait_until="networkidle")
                report["university"].append(await dump_page(page, slug, 1200))
            except Exception as e:
                print("Uni err", route, e)
        await ctx.close()

        # 5. ADMIN PORTAL (Demo account + MFA 123456)
        ctx = await browser.new_context(viewport={"width": 1920, "height": 1080}, device_scale_factor=1)
        page = await ctx.new_page()
        report["admin"] = []
        await page.goto("https://aptohire-admin.vercel.app/login", wait_until="networkidle")
        report["admin"].append(await dump_page(page, "admin_login", 1000))
        await page.get_by_text("Continue with demo account", exact=False).first.click()
        await page.wait_for_timeout(1500)
        report["admin"].append(await dump_page(page, "admin_mfa", 1000))
        if "mfa" in page.url:
            inputs = page.locator("input")
            cnt = await inputs.count()
            if cnt == 1:
                await inputs.first.fill("123456")
            elif cnt >= 6:
                for idx, ch in enumerate("123456"):
                    await inputs.nth(idx).fill(ch)
            submit_btn = page.locator("button[type='submit']").first
            if await submit_btn.count() > 0:
                await submit_btn.click()
            await page.wait_for_timeout(2000)
        report["admin"].append(await dump_page(page, "admin_dashboard", 1500))
        for route, slug in [("/approvals", "admin_approvals"), ("/reviews", "admin_reviews"), ("/tickets", "admin_tickets"), ("/runs", "admin_runs"), ("/library", "admin_library"), ("/audit-log", "admin_audit_log"), ("/reports", "admin_reports"), ("/users", "admin_users"), ("/settings", "admin_settings")]:
            try:
                await page.goto(f"https://aptohire-admin.vercel.app{route}", wait_until="networkidle")
                report["admin"].append(await dump_page(page, slug, 1200))
            except Exception as e:
                print("Admin err", route, e)
        await ctx.close()

        await browser.close()

    with open("audit/portal_report.json", "w") as f:
        json.dump(report, f, indent=2)
    print("DONE! Saved portal_report.json and screenshots.")

asyncio.run(main())
