import asyncio, os, json
from playwright.async_api import async_playwright

# Demo password is supplied at run time — never committed.
DEMO_PASSWORD = os.environ.get("APTOHIRE_DEMO_PASSWORD", "")

OUT_DIR = "audit/captures_v2"
os.makedirs(OUT_DIR, exist_ok=True)

async def snap(page, slug, wait_ms=2200):
    await page.wait_for_timeout(wait_ms)
    # Dismiss cookie banner if visible
    got_it = page.get_by_role("button", name="Got it")
    if await got_it.count() > 0 and await got_it.first.is_visible():
        await got_it.first.click()
        await page.wait_for_timeout(200)
    await page.screenshot(path=os.path.join(OUT_DIR, f"{slug}.png"), full_page=False)
    await page.screenshot(path=os.path.join(OUT_DIR, f"{slug}_full.png"), full_page=True)
    text = await page.evaluate("() => document.body.innerText")
    return {"slug": slug, "url": page.url, "text": text}

async def do_public(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    for route, slug in [("/", "public_home"), ("/demo", "public_demo"), ("/verify/9efdf52c1c90863fa1", "public_verify"), ("/ai-and-fairness", "public_fairness")]:
        await page.goto(f"https://aptohire.vercel.app{route}", wait_until="networkidle")
        out.append(await snap(page, slug, 2000))
    await ctx.close()
    return out

async def do_student(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-student.vercel.app/login", wait_until="networkidle")
    await snap(page, "student_login", 1000)
    await page.get_by_text("Aarav Sharma", exact=False).first.click()
    await page.wait_for_timeout(3000)
    out.append(await snap(page, "student_home", 2000))
    for route, slug in [("/projects", "student_projects"), ("/projects/new", "student_projects_new"), ("/submissions/new", "student_submissions_new"), ("/scorecard", "student_scorecard"), ("/scorecard/react", "student_scorecard_react"), ("/sharing", "student_sharing"), ("/resume", "student_resume"), ("/profile", "student_profile")]:
        await page.goto(f"https://aptohire-student.vercel.app{route}", wait_until="networkidle")
        out.append(await snap(page, slug, 2200))
    await ctx.close()
    return out

async def do_org(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-organization.vercel.app/login", wait_until="networkidle")
    await snap(page, "org_login", 1000)
    await page.get_by_text("Northwind Labs", exact=False).first.click()
    await page.wait_for_timeout(1500)
    if "/login" in page.url:
        pw = page.locator("input[type='password']")
        if await pw.count() > 0:
            val = await pw.first.input_value()
            if not val:
                await pw.first.fill(DEMO_PASSWORD)
        btn = page.get_by_role("button", name="Sign in")
        if await btn.count() > 0:
            await btn.first.click()
            await page.wait_for_timeout(2500)
    out.append(await snap(page, "org_home", 2000))
    # Find job links on org home
    hrefs = await page.evaluate("() => Array.from(document.querySelectorAll('a')).map(a => a.href)")
    job_links = [h for h in hrefs if "/jobs/" in h and not h.endswith("/new") and not h.endswith("/edit")]
    for route, slug in [("/jobs/new", "org_jobs_new"), ("/candidates", "org_candidates"), ("/requests", "org_requests"), ("/pipeline", "org_pipeline"), ("/directory", "org_directory")]:
        await page.goto(f"https://aptohire-organization.vercel.app{route}", wait_until="networkidle")
        out.append(await snap(page, slug, 2200))
    if job_links:
        await page.goto(job_links[0], wait_until="networkidle")
        out.append(await snap(page, "org_job_detail", 2200))
    await ctx.close()
    return out

async def do_uni(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-university.vercel.app/login", wait_until="networkidle")
    await snap(page, "uni_login", 1000)
    await page.get_by_text("Aravalli Institute", exact=False).first.click()
    await page.wait_for_timeout(2000)
    if "/login" in page.url:
        pw = page.locator("input[type='password']")
        if await pw.count() > 0 and not (await pw.first.input_value()):
            await pw.first.fill(DEMO_PASSWORD)
        btn = page.locator("button[type='submit']").first
        if await btn.count() > 0:
            await btn.click()
            await page.wait_for_timeout(2500)
    out.append(await snap(page, "uni_overview", 2000))
    for route, slug in [("/students", "uni_students"), ("/roster", "uni_roster"), ("/placements", "uni_placements"), ("/skills", "uni_skills"), ("/directory", "uni_directory")]:
        await page.goto(f"https://aptohire-university.vercel.app{route}", wait_until="networkidle")
        out.append(await snap(page, slug, 2000))
    await ctx.close()
    return out

async def do_admin(browser):
    ctx = await browser.new_context(viewport={"width": 1920, "height": 1080})
    page = await ctx.new_page()
    out = []
    await page.goto("https://aptohire-admin.vercel.app/login", wait_until="networkidle")
    await snap(page, "admin_login", 1000)
    await page.get_by_text("Continue with demo account", exact=False).first.click()
    await page.wait_for_timeout(2500)
    out.append(await snap(page, "admin_mfa", 500))
    if "mfa" in page.url:
        inp = page.locator("input").first
        await inp.click()
        await inp.type("123456", delay=60)
        await page.wait_for_timeout(500)
        btn = page.get_by_role("button", name="Verify", exact=False)
        if await btn.count() > 0 and await btn.first.is_enabled():
            await btn.first.click()
        await page.wait_for_timeout(2500)
    out.append(await snap(page, "admin_dashboard", 2000))
    for route, slug in [("/approvals", "admin_approvals"), ("/reviews", "admin_reviews"), ("/tickets", "admin_tickets"), ("/runs", "admin_runs"), ("/library", "admin_library"), ("/audit-log", "admin_audit_log"), ("/reports", "admin_reports"), ("/users", "admin_users"), ("/settings", "admin_settings")]:
        await page.goto(f"https://aptohire-admin.vercel.app{route}", wait_until="networkidle")
        out.append(await snap(page, slug, 1800))
    await ctx.close()
    return out

async def main():
    async with async_playwright() as p:
        browser = await p.chromium.launch(executable_path="/usr/bin/chromium", args=["--no-sandbox", "--disable-dev-shm-usage"])
        pub, stu, org, uni, adm = await asyncio.gather(
            do_public(browser), do_student(browser), do_org(browser), do_uni(browser), do_admin(browser)
        )
        await browser.close()
    data = {"public": pub, "student": stu, "organization": org, "university": uni, "admin": adm}
    with open("audit/deep_report.json", "w") as f:
        json.dump(data, f, indent=2)
    for k, v in data.items():
        print(k, "->", [(x["slug"], x["url"]) for x in v])

asyncio.run(main())
