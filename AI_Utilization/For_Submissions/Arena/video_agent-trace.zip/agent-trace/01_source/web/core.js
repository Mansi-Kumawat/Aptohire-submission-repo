/* =========================================================================
   AptoHire Film — core utilities
   Deterministic animation primitives. Every value is a pure function of t.
   ========================================================================= */
(function () {
  'use strict';

  const ez = {
    linear:  p => p,
    inQuad:  p => p * p,
    outCubic: p => 1 - Math.pow(1 - p, 3),
    outQuart: p => 1 - Math.pow(1 - p, 4),
    outQuint: p => 1 - Math.pow(1 - p, 5),
    inCubic: p => p * p * p,
    inOutCubic: p => p < 0.5 ? 4 * p * p * p : 1 - Math.pow(-2 * p + 2, 3) / 2,
    inOutQuart: p => p < 0.5 ? 8 * p * p * p * p : 1 - Math.pow(-2 * p + 2, 4) / 2,
    inOutQuint: p => p < 0.5 ? 16 * p * p * p * p * p : 1 - Math.pow(-2 * p + 2, 5) / 2,
    outBack: p => { const c1 = 1.35, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); },
    outBackSoft: p => { const c1 = 0.62, c3 = c1 + 1; return 1 + c3 * Math.pow(p - 1, 3) + c1 * Math.pow(p - 1, 2); },
    outElastic: p => p === 0 ? 0 : p === 1 ? 1 : Math.pow(2, -9 * p) * Math.sin((p * 10 - 0.75) * (2 * Math.PI / 3)) + 1,
  };

  /** eased 0..1 progress across [t0,t1] */
  function S(t, t0, t1, ease) {
    if (t <= t0) return 0;
    if (t >= t1) return 1;
    const p = (t - t0) / (t1 - t0);
    return (ease || ez.inOutCubic)(p);
  }
  const lerp = (a, b, p) => a + (b - a) * p;
  const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;

  /** apply a transform/opacity/filter state to an element. Cached to avoid layout thrash. */
  function put(el, s) {
    if (!el) return;
    const T = [];
    if (s.x || s.y || s.z) T.push(`translate3d(${(s.x || 0).toFixed(2)}px,${(s.y || 0).toFixed(2)}px,${(s.z || 0).toFixed(2)}px)`);
    if (s.rz) T.push(`rotate(${s.rz.toFixed(3)}deg)`);
    if (s.ry) T.push(`rotateY(${s.ry.toFixed(3)}deg)`);
    if (s.rx) T.push(`rotateX(${s.rx.toFixed(3)}deg)`);
    if (s.s !== undefined && s.s !== 1) T.push(`scale(${s.s.toFixed(4)})`);
    if (s.sx !== undefined || s.sy !== undefined) T.push(`scale(${(s.sx ?? 1).toFixed(4)},${(s.sy ?? 1).toFixed(4)})`);
    const tr = T.length ? T.join(' ') : 'none';
    if (el.__tr !== tr) { el.style.transform = tr; el.__tr = tr; }
    const o = s.o === undefined ? 1 : s.o;
    const oo = o.toFixed(3);
    if (el.__o !== oo) { el.style.opacity = oo; el.__o = oo; }
    if (s.blur !== undefined) {
      const f = s.blur > 0.05 ? `blur(${s.blur.toFixed(2)}px)` : 'none';
      if (el.__f !== f) { el.style.filter = f; el.__f = f; }
    }
    if (s.d !== undefined) {
      const d = s.d ? 'block' : 'none';
      if (el.__d !== d) { el.style.display = d; el.__d = d; }
    }
  }

  /** entrance: fade + rise (+ optional blur), returns element's state */
  function enter(t, t0, dur, o) {
    o = o || {};
    const p = S(t, t0, t0 + (dur || 0.62), o.ease || ez.outCubic);
    return {
      o: p,
      y: lerp(o.y === undefined ? 26 : o.y, 0, p),
      x: lerp(o.x === undefined ? 0 : o.x, 0, p),
      s: lerp(o.s === undefined ? 1 : o.s, 1, p),
      blur: lerp(o.blur === undefined ? 7 : o.blur, 0, p),
    };
  }

  /** exit: fade + small drift */
  function exit(t, t0, dur, o) {
    o = o || {};
    const p = S(t, t0, t0 + (dur || 0.4), ez.inCubic);
    return { o: 1 - p, y: lerp(0, o.y === undefined ? -16 : o.y, p), s: lerp(1, o.s === undefined ? 0.985 : o.s, p), blur: lerp(0, 4, p) };
  }

  /** combined in-then-out envelope */
  function inout(t, tin, tout, o) {
    const a = enter(t, tin, o && o.dur, o);
    const b = exit(t, tout, o && o.exitDur, o);
    return { o: Math.min(a.o, b.o), y: a.y + b.y, x: a.x, s: a.s * b.s, blur: Math.max(a.blur, b.blur) };
  }

  /** word-level stagger; returns array of per-word states */
  function stagger(t, t0, per, n, o) {
    o = o || {};
    const out = [];
    for (let i = 0; i < n; i++) {
      const p = S(t, t0 + i * per, t0 + i * per + (o.dur || 0.5), o.ease || ez.outCubic);
      out.push({ p, o: p, y: lerp(o.y === undefined ? 30 : o.y, 0, p), blur: lerp(o.blur === undefined ? 9 : o.blur, 0, p), s: lerp(0.94, 1, p) });
    }
    return out;
  }

  /** split text into word spans (keeps punctuation with the word) */
  function wordsHTML(str, cls) {
    return str.split(' ').map(w => `<span class="kw ${cls || ''}">${w}</span>`).join(' ');
  }

  function applyWords(els, states, extra) {
    for (let i = 0; i < els.length; i++) {
      const s = states[Math.min(i, states.length - 1)];
      const e = els[i];
      put(e, Object.assign({}, s, extra && extra(i)));
    }
  }

  /** SVG trim-path helper: sets dasharray/dashoffset from progress */
  function trim(el, p, len) {
    if (!el) return;
    const L = len || el.__len || (el.__len = (el.getTotalLength ? el.getTotalLength() : 1000));
    const off = (L * (1 - clamp01(p))).toFixed(1);
    const ds = L.toFixed(1);
    if (el.__ds !== ds + off) {
      el.style.strokeDasharray = ds;
      el.style.strokeDashoffset = off;
      el.__ds = ds + off;
    }
  }

  // ---------------- icon set (lucide-flavoured, stroke based) ----------------
  const P = (d, extra) => `<svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" ${extra || ''}>${d}</svg>`;
  const ICON = {
    check:    P('<path d="M20 6 9 17l-5-5"/>'),
    checkCircle: P('<circle cx="12" cy="12" r="9"/><path d="m8.5 12.2 2.4 2.4 4.6-4.9"/>'),
    lock:     P('<rect x="4.5" y="10.5" width="15" height="10.5" rx="2.5"/><path d="M8 10.5V7a4 4 0 0 1 8 0v3.5"/>'),
    shield:   P('<path d="M12 3 20 6v6c0 4.4-3.2 8.1-8 9-4.8-.9-8-4.6-8-9V6z"/><path d="m9 12 2 2 4-4"/>'),
    users:    P('<path d="M16 20v-1.6a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4V20"/><circle cx="9" cy="7" r="3.2"/><path d="M22 20v-1.6a4 4 0 0 0-3-3.87"/><path d="M16.5 4.2a3.2 3.2 0 0 1 0 6.2"/>'),
    user:     P('<circle cx="12" cy="8" r="3.6"/><path d="M5 20v-1.5A5.5 5.5 0 0 1 10.5 13h3A5.5 5.5 0 0 1 19 18.5V20"/>'),
    briefcase:P('<rect x="2.5" y="7" width="19" height="13" rx="2.5"/><path d="M8.5 7V5.6A2.1 2.1 0 0 1 10.6 3.5h2.8a2.1 2.1 0 0 1 2.1 2.1V7"/><path d="M2.5 12.5h19"/>'),
    building: P('<rect x="4" y="3" width="16" height="18" rx="1.8"/><path d="M9 7h2M13 7h2M9 11h2M13 11h2M9 15h2M13 15h2"/><path d="M10 21v-2.6h4V21"/>'),
    chart:    P('<path d="M4 20V10M10 20V4M16 20v-7M22 20H2"/>'),
    trendUp:  P('<path d="m3 16.5 5.5-5.5 3.6 3.6L21 6"/><path d="M15.5 6H21v5.5"/>'),
    sparkle:  P('<path d="M12 3.2 13.9 9l5.8 1.9-5.8 1.9L12 18.6l-1.9-5.8L4.3 10.9 10.1 9z"/><path d="M19 16.5 19.8 19l2.5.8-2.5.8-.8 2.5-.8-2.5-2.5-.8 2.5-.8z"/>'),
    arrow:    P('<path d="M5 12h14"/><path d="m13 6 6 6-6 6"/>'),
    arrowUR:  P('<path d="M7 17 17 7"/><path d="M9 7h8v8"/>'),
    chevron:  P('<path d="m9 6 6 6-6 6"/>'),
    search:   P('<circle cx="10.5" cy="10.5" r="6.5"/><path d="m20 20-4.5-4.5"/>'),
    code:     P('<path d="m9 8-5 4 5 4"/><path d="m15 8 5 4-5 4"/>'),
    video:    P('<rect x="2.5" y="6" width="13" height="12" rx="2.4"/><path d="m15.5 12 6-3.6v7.2z"/>'),
    file:     P('<path d="M14 2.8H7.4A2.4 2.4 0 0 0 5 5.2v13.6a2.4 2.4 0 0 0 2.4 2.4h9.2a2.4 2.4 0 0 0 2.4-2.4V7.8z"/><path d="M14 2.8V7.8h5"/>'),
    qr:       P('<rect x="3.5" y="3.5" width="6" height="6" rx="1"/><rect x="14.5" y="3.5" width="6" height="6" rx="1"/><rect x="3.5" y="14.5" width="6" height="6" rx="1"/><path d="M14.5 14.5h2.5v2.5h-2.5zM18 18h2.5v2.5H18zM14.5 20.5h1"/>'),
    bell:     P('<path d="M18 8.6a6 6 0 1 0-12 0c0 5-2 6.4-2 6.4h16s-2-1.4-2-6.4"/><path d="M13.7 19a2 2 0 0 1-3.4 0"/>'),
    grid:     P('<rect x="3.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.6"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.6"/><rect x="13.5" y="13.5" width="7" height="7" rx="1.6"/>'),
    list:     P('<path d="M8 6h13M8 12h13M8 18h13M3.5 6h.01M3.5 12h.01M3.5 18h.01"/>'),
    clock:    P('<circle cx="12" cy="12" r="8.6"/><path d="M12 7.4V12l3.2 2"/>'),
    flag:     P('<path d="M5 21V4"/><path d="M5 4.6h11.8l-2 4 2 4H5z"/>'),
    refresh:  P('<path d="M20 11.5a8 8 0 1 0-1.6 6"/><path d="M20 5v6h-6"/>'),
    layers:   P('<path d="m12 3 9 5-9 5-9-5z"/><path d="m3 13 9 5 9-5"/>'),
    database: P('<ellipse cx="12" cy="6" rx="8" ry="3.2"/><path d="M4 6v6c0 1.8 3.6 3.2 8 3.2s8-1.4 8-3.2V6"/><path d="M4 12v6c0 1.8 3.6 3.2 8 3.2s8-1.4 8-3.2v-6"/>'),
    globe:    P('<circle cx="12" cy="12" r="8.6"/><path d="M3.6 12h16.8"/><path d="M12 3.4c2.4 2.4 3.6 5.4 3.6 8.6S14.4 18.2 12 20.6C9.6 18.2 8.4 15.2 8.4 12S9.6 5.8 12 3.4z"/>'),
    pen:      P('<path d="m4 20 4.2-1 10-10a2.4 2.4 0 0 0-3.4-3.4l-10 10z"/><path d="M14.2 6.4 17.6 9.8"/>'),
    filter:   P('<path d="M3.5 5h17l-6.6 7.8v6.4l-3.8 2v-8.4z"/>'),
    plus:     P('<path d="M12 5v14M5 12h14"/>'),
    download: P('<path d="M12 3.5v11"/><path d="m7.5 10.5 4.5 4.5 4.5-4.5"/><path d="M4 20.5h16"/>'),
    external: P('<path d="M14 4h6v6"/><path d="M20 4 11 13"/><path d="M18 14.5v4A1.5 1.5 0 0 1 16.5 20h-11A1.5 1.5 0 0 1 4 18.5v-11A1.5 1.5 0 0 1 5.5 6h4"/>'),
    play:     P('<path d="M8 5.5v13l11-6.5z"/>'),
    star:     P('<path d="m12 3.6 2.6 5.5 6 .8-4.4 4.2 1.1 6-5.3-2.9-5.3 2.9 1.1-6L3.4 9.9l6-.8z"/>'),
    ban:      P('<circle cx="12" cy="12" r="8.6"/><path d="m6.2 6.2 11.6 11.6"/>'),
    eyeOff:   P('<path d="M10.6 6.3A7.6 7.6 0 0 1 12 6.2c5 0 8.6 5.8 8.6 5.8a16 16 0 0 1-2.7 3.4"/><path d="M6.2 7.9A16.4 16.4 0 0 0 3.4 12s3.6 5.8 8.6 5.8c1.4 0 2.7-.4 3.8-1.1"/><path d="m3 3 18 18"/>'),
    zap:      P('<path d="M13 2.5 4.5 13.5H11l-1 8 8.5-11H12z"/>'),
    gauge:    P('<path d="M4 18a8.5 8.5 0 1 1 16 0"/><path d="m12 14 4-4"/>'),
    link:     P('<path d="M10 13.5a3.5 3.5 0 0 0 5 0l3-3a3.5 3.5 0 0 0-5-5l-1.6 1.6"/><path d="M14 10.5a3.5 3.5 0 0 0-5 0l-3 3a3.5 3.5 0 0 0 5 5l1.6-1.6"/>'),
    home:     P('<path d="m3.5 10.5 8.5-7 8.5 7V20a1 1 0 0 1-1 1h-15a1 1 0 0 1-1-1z"/><path d="M9.5 21v-6h5v6"/>'),
    target:   P('<circle cx="12" cy="12" r="8.6"/><circle cx="12" cy="12" r="4.4"/><circle cx="12" cy="12" r="0.6" fill="currentColor"/>'),
    scale:    P('<path d="M12 3.5v17"/><path d="M5 7.5h14"/><path d="M5 7.5 2.5 14h5z"/><path d="M19 7.5 16.5 14h5z"/>'),
    book:     P('<path d="M4 4.5A1.5 1.5 0 0 1 5.5 3H19v18H5.5A1.5 1.5 0 0 1 4 19.5z"/><path d="M4 17.5h15"/>'),
    key:      P('<circle cx="8" cy="15" r="4"/><path d="m11 12 9-9"/><path d="m16.5 6.5 2.5 2.5"/>'),
  };
  const ico = (name, size, color) => `<span class="ico" style="width:${size || 24}px;height:${size || 24}px;${color ? 'color:' + color : ''}">${ICON[name] || ''}</span>`.replace('width="24" height="24"', `width="${size || 24}" height="${size || 24}"`);

  window.AH = { ez, S, lerp, clamp, clamp01, put, enter, exit, inout, stagger, wordsHTML, applyWords, trim, ICON, ico };
})();
