/* =========================================================================
   AptoHire Film — Scenes 8-13
   ========================================================================= */
(function () {
  'use strict';
  const { ez, S, lerp, clamp, put, enter, exit, inout, stagger, wordsHTML, applyWords, trim, ico } = AH;
  const SCENES = window.SCENES;

  /* =======================================================================
     SCENE 08 — WHY APTOHIRE IS DIFFERENT  (217.733 -> 231.183)
     ======================================================================= */
  SCENES.push({
    id: 'scene_08', portal: 'The philosophy',
    build(root) {
      root.classList.add('bg-paper');
      root.innerHTML = `
        <div style="position:absolute;inset:0;background:radial-gradient(900px 560px at 50% 42%, rgba(8,122,85,.07), transparent 70%)"></div>
        <div class="sh" style="position:absolute;left:0;right:0;top:118px;text-align:center;z-index:20">
          <div class="micro c-green" style="opacity:0" data-kick>The philosophy</div>
          <div class="display-m" style="margin-top:22px;max-width:1380px;margin-left:auto;margin-right:auto">
            <span data-h>${wordsHTML('What makes AptoHire different')}</span>
          </div>
        </div>

        <div style="position:absolute;left:50%;transform:translateX(-50%);top:352px;display:flex;align-items:stretch;gap:0;z-index:22">
          <!-- degree -->
          <div class="pcard" data-pc="0" style="width:390px;background:#fff;border:1px solid rgba(30,41,59,.1);border-radius:18px 0 0 18px;padding:30px 30px;opacity:0">
            <div style="width:46px;height:46px;border-radius:12px;background:#F1F4F7;display:flex;align-items:center;justify-content:center;color:#64748B;margin-bottom:20px">${ico('book', 22)}</div>
            <div style="font-size:11.5px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)">A degree shows</div>
            <div style="font-size:34px;font-weight:800;letter-spacing:-.03em;margin-top:8px;color:#475569">what someone studied.</div>
            <div style="margin-top:20px;padding-top:18px;border-top:1px solid rgba(30,41,59,.08);font-size:14.5px;color:var(--muted);line-height:1.5">A record of curriculum, completed on a fixed timeline.</div>
          </div>
          <!-- resume -->
          <div class="pcard" data-pc="1" style="width:390px;background:#fff;border-top:1px solid rgba(30,41,59,.1);border-bottom:1px solid rgba(30,41,59,.1);padding:30px 30px;opacity:0">
            <div style="width:46px;height:46px;border-radius:12px;background:#F1F4F7;display:flex;align-items:center;justify-content:center;color:#64748B;margin-bottom:20px">${ico('file', 22)}</div>
            <div style="font-size:11.5px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)">A resume summarizes</div>
            <div style="font-size:34px;font-weight:800;letter-spacing:-.03em;margin-top:8px;color:#475569">where they have been.</div>
            <div style="margin-top:20px;padding-top:18px;border-top:1px solid rgba(30,41,59,.08);font-size:14.5px;color:var(--muted);line-height:1.5">A self-written summary, editable by anyone, verifiable by no one.</div>
          </div>
          <!-- evidence -->
          <div class="pcard" data-pc="2" style="width:440px;background:linear-gradient(155deg,#0A5C41,#087A55 60%,#0B9266);border:2px solid var(--gold);border-radius:0 18px 18px 0;padding:30px 32px;box-shadow:0 30px 70px rgba(8,122,85,.32);opacity:0">
            <div style="width:46px;height:46px;border-radius:12px;background:rgba(255,255,255,.14);display:flex;align-items:center;justify-content:center;color:#F2C879;margin-bottom:20px">${ico('shield', 22)}</div>
            <div style="font-size:11.5px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:#9FE9C9">Practical evidence proves</div>
            <div style="font-size:34px;font-weight:800;letter-spacing:-.03em;margin-top:8px;color:#fff">what they can do.</div>
            <div style="margin-top:20px;padding-top:18px;border-top:1px solid rgba(255,255,255,.16);font-size:14.5px;color:rgba(255,255,255,.72);line-height:1.5">Working artifacts, public rubric, verifiable proof.</div>
          </div>
        </div>

        <div class="eq" style="position:absolute;left:0;right:0;top:790px;text-align:center;z-index:23;opacity:0">
          <div style="display:inline-flex;align-items:center;gap:20px;padding:18px 34px;border-radius:999px;background:#fff;border:1px solid rgba(30,41,59,.1);box-shadow:0 18px 44px rgba(23,32,51,.1)">
            <span style="font-size:21px;font-weight:600;color:var(--muted)">Not <b style="color:var(--ink)">where you studied</b></span>
            <span style="width:1px;height:26px;background:rgba(30,41,59,.14)"></span>
            <span style="font-size:21px;font-weight:600;color:var(--muted)">Not <b style="color:var(--ink)">who you know</b></span>
            <span style="width:1px;height:26px;background:rgba(30,41,59,.14)"></span>
            <span style="font-size:21px;font-weight:800;color:var(--green)">But what you can prove.</span>
          </div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = { kick: q('[data-kick]'), pcs: [...root.querySelectorAll('[data-pc]')], eq: q('.eq') };
      this.frame = (t, lt, D) => {
        put(el.kick, { o: S(t, 218.0, 218.6), y: lerp(10, 0, S(t, 218.0, 218.7, ez.outCubic)) });
        applyWords(root.querySelectorAll('[data-h] .kw'), stagger(t, 218.25, 0.085, 5, { y: 30, dur: 0.55 }));
        el.pcs.forEach((c, i) => {
          const p = S(t, 221.35 + i * 0.62, 222.25 + i * 0.62, ez.outCubic);
          put(c, { o: p, y: lerp(44, 0, p), s: lerp(0.96, 1, p), blur: lerp(9, 0, p) });
        });
        const e = S(t, 226.30, 227.20, ez.outCubic);
        put(el.eq, { o: e, y: lerp(22, 0, e), s: lerp(0.96, 1, e) });
      };
    }
  });

  /* =======================================================================
     SCENE 09 — BEHIND THE BUILD  (231.183 -> 250.785)
     ======================================================================= */
  SCENES.push({
    id: 'scene_09', portal: 'Behind the build',
    build(root) {
      root.classList.add('bg-black');
      root.innerHTML = `
        <div class="broll" style="opacity:0" data-plate><img src="assets/broll_founders.webp" alt=""></div>
        <div class="broll-veil warm"></div>
        <div class="letterbox"></div>

        <div style="position:absolute;left:128px;top:150px;z-index:20;max-width:1000px">
          <div class="micro c-gold" style="opacity:0" data-kick>Behind the build · October 2026</div>
          <div class="display-l" style="color:#fff;margin-top:22px;text-shadow:0 8px 44px rgba(0,0,0,.8)">
            <div data-h="0">${wordsHTML('Three co-founders.')}</div>
            <div data-h="1" style="margin-top:6px">${wordsHTML('One focused two-week sprint.')}</div>
          </div>
          <div class="subhead" style="color:rgba(255,255,255,.72);margin-top:26px;max-width:760px;opacity:0" data-sub>
            A working prototype built end-to-end in October 2026 — with AI-assisted research, planning, documentation and coding.
          </div>
        </div>

        <div class="cards" style="position:absolute;right:120px;top:196px;width:520px;z-index:21;display:flex;flex-direction:column;gap:14px">
          ${[['sparkle', 'AI-assisted', 'Research, planning, documentation, coding'],
             ['layers', 'Across', 'Gemini · Claude · ChatGPT · Arena AI']].map((c, i) => `
            <div data-card="${i}" style="opacity:0;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.13);border-radius:15px;padding:20px 22px;display:flex;gap:15px;align-items:flex-start;backdrop-filter:blur(9px)">
              <span style="width:40px;height:40px;border-radius:11px;background:rgba(242,200,121,.14);border:1px solid rgba(242,200,121,.3);display:flex;align-items:center;justify-content:center;color:#F2C879;flex:none">${ico(c[0], 19)}</span>
              <div>
                <div style="font-size:18px;font-weight:700;color:#fff">${c[1]}</div>
                <div style="font-size:14px;color:rgba(255,255,255,.6);margin-top:4px;line-height:1.45">${c[2]}</div>
              </div>
            </div>`).join('')}
          <div data-card="2" style="opacity:0;background:linear-gradient(150deg,rgba(8,122,85,.34),rgba(8,122,85,.14));border:1.5px solid rgba(10,207,131,.5);border-radius:15px;padding:20px 22px;display:flex;gap:15px;align-items:flex-start">
            <span style="width:40px;height:40px;border-radius:11px;background:rgba(10,207,131,.18);border:1px solid rgba(10,207,131,.4);display:flex;align-items:center;justify-content:center;color:#6EE7B7;flex:none">${ico('shield', 19)}</span>
            <div>
              <div style="font-size:18px;font-weight:700;color:#fff">Rigorous human review</div>
              <div style="font-size:14px;color:rgba(255,255,255,.68);margin-top:4px;line-height:1.45">Architecture, testing and code review, owned by the team — every release.</div>
            </div>
          </div>
        </div>

        <div class="stat" style="position:absolute;left:128px;bottom:150px;z-index:22;display:flex;gap:56px;opacity:0">
          ${[['14', 'days to a working prototype'], ['5', 'role-based portals, one database'], ['10', 'AI review dimensions on a public rubric']].map((s, i) => `
            <div>
              <div style="font-size:52px;font-weight:800;letter-spacing:-.04em;color:#F2C879;line-height:1">${s[0]}</div>
              <div style="font-size:14px;color:rgba(255,255,255,.66);margin-top:8px;max-width:190px;line-height:1.4">${s[1]}</div>
            </div>`).join('')}
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = { plate: q('[data-plate]'), img: q('[data-plate] img'), kick: q('[data-kick]'), sub: q('[data-sub]'),
        cards: [...root.querySelectorAll('[data-card]')], stat: q('.stat') };
      this.frame = (t, lt, D) => {
        put(el.plate, { o: S(t, 231.20, 232.5) });
        put(el.img, { s: lerp(1.10, 1.0, S(t, 231.2, 250.8, ez.linear)), x: lerp(0, -24, S(t, 231.2, 250.8, ez.linear)) });
        put(el.kick, { o: S(t, 231.5, 232.2), x: lerp(-18, 0, S(t, 231.5, 232.3, ez.outCubic)) });
        applyWords(root.querySelectorAll('[data-h="0"] .kw'), stagger(t, 231.87, 0.09, 3, { y: 34 }));
        applyWords(root.querySelectorAll('[data-h="1"] .kw'), stagger(t, 233.10, 0.075, 5, { y: 34 }));
        put(el.sub, { o: S(t, 234.40, 235.2), y: lerp(18, 0, S(t, 234.4, 235.3, ez.outCubic)) });
        el.cards.forEach((c, i) => { const p = S(t, 235.55 + i * 0.55, 236.4 + i * 0.55, ez.outCubic); put(c, { o: p, x: lerp(46, 0, p), blur: lerp(7, 0, p) }); });
        const s = S(t, 240.6, 241.6, ez.outCubic);
        put(el.stat, { o: s, y: lerp(24, 0, s) });
      };
    }
  });

  /* =======================================================================
     SCENE 10 — SYSTEM ARCHITECTURE & LOCKS  (250.785 -> 263.819)
     ======================================================================= */
  SCENES.push({
    id: 'scene_10', portal: 'Architecture & permission locks',
    build(root) {
      root.classList.add('bg-navy');
      const NODE = [
    { id: 'student', label: 'Student', meta: 'portal s1', x: 200, y: 350, icon: 'user' },
    { id: 'org', label: 'Organization', meta: 'portal s2', x: 200, y: 500, icon: 'briefcase' },
    { id: 'uni', label: 'University', meta: 'portal s3', x: 200, y: 650, icon: 'building' },
    { id: 'admin', label: 'Admin', meta: 'portal s4 · MFA', x: 200, y: 800, icon: 'shield' },
    
  ];
      root.innerHTML = `
        <div style="position:absolute;inset:0;background:radial-gradient(1000px 700px at 50% 46%, rgba(8,122,85,.2), transparent 70%)"></div>
        <div style="position:absolute;left:120px;top:88px;z-index:20">
          <div class="micro" style="color:#6EE7B7;opacity:0" data-kick>Under the hood</div>
          <div class="display-m" style="color:#fff;margin-top:16px;max-width:1120px"><span data-h>${wordsHTML('Five portals. One database.')}</span></div>
          <div class="subhead" style="color:#94A3B8;margin-top:12px;opacity:0" data-sub>Row-level security, with deterministic permission locks at every boundary.</div>
        </div>

        <svg class="conn-svg" style="z-index:21" viewBox="0 0 1920 1080">
          ${NODE.map((n, i) => `<path class="conn-path" data-cl="${i}" d="M ${n.x + 196} ${n.y + 46} C ${n.x + 316} ${n.y + 46}, 620 ${520 + (i - 1.5) * 34}, 812 520"/>`).join('')}
        </svg>

        <div style="position:absolute;left:200px;top:0;z-index:22">
          ${NODE.map((n, i) => `
            <div class="node" data-node="${i}" style="left:0;top:${n.y}px;width:196px;height:92px;opacity:0">
              <div style="color:#6EE7B7">${ico(n.icon, 20)}</div>
              <div class="n-name">${n.label}</div>
              <div class="n-meta">${n.meta}</div>
            </div>`).join('')}
        </div>

        <div class="node core" data-core style="left:812px;top:404px;width:260px;height:232px;opacity:0;z-index:23">
          <div style="color:#F2C879">${ico('database', 34)}</div>
          <div style="font-size:22px;font-weight:800;letter-spacing:-.02em;margin-top:4px">Single source of truth</div>
          <div class="n-meta" style="font-size:12.5px">Postgres · row-level security</div>
          <div style="margin-top:12px;display:flex;gap:6px">
            ${['RLS', 'JWT', 'RBAC'].map(t => `<span style="font-family:var(--mono);font-size:10px;letter-spacing:.06em;padding:3px 7px;border-radius:5px;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.2)">${t}</span>`).join('')}
          </div>
        </div>

        <div class="node" data-lock style="left:1122px;top:404px;width:260px;height:232px;opacity:0;z-index:23;border-color:rgba(214,168,79,.5);background:rgba(214,168,79,.07)">
          <div style="color:#F2C879">${ico('lock', 30)}</div>
          <div style="font-size:20px;font-weight:800;letter-spacing:-.02em;margin-top:6px">Permission lock</div>
          <div class="n-meta" style="font-size:12px">deterministic · pre-query</div>
          <div style="margin-top:12px;display:flex;flex-direction:column;gap:5px;width:100%;padding:0 26px">
            ${['role checked', 'scope checked', 'consent checked'].map((c, i) => `<div style="display:flex;align-items:center;gap:7px;font-size:11.5px;color:rgba(255,255,255,.72)" data-lockstep="${i}">${ico('check', 11, '#F2C879')} ${c}</div>`).join('')}
          </div>
        </div>

        <div class="node" data-gate style="left:1442px;top:404px;width:250px;height:232px;opacity:0;z-index:23">
          <div style="color:#94A3B8">${ico('users', 28)}</div>
          <div style="font-size:19px;font-weight:800;letter-spacing:-.02em;margin-top:6px">Candidate data</div>
          <div class="n-meta" style="font-size:12px">released only on consent</div>
          <div style="margin-top:12px;font-family:var(--mono);font-size:10.5px;color:#94A3B8">0 bytes until accepted</div>
        </div>

        <div style="position:absolute;left:104px;bottom:74px;z-index:24;display:flex;gap:14px" data-facts>
          ${[['lock', 'Consent before data'], ['scale', 'Tenant isolation by row'], ['book', 'Append-only audit trail']].map((f, i) => `
            <div data-fact="${i}" style="opacity:0;display:flex;align-items:center;gap:9px;padding:11px 17px;border-radius:9px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.12);font-size:13px;color:rgba(255,255,255,.78)">
              ${ico(f[0], 15, '#6EE7B7')} ${f[1]}
            </div>`).join('')}
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = { kick: q('[data-kick]'), sub: q('[data-sub]'), nodes: [...root.querySelectorAll('[data-node]')],
        core: q('[data-core]'), lock: q('[data-lock]'), gate: q('[data-gate]'), cl: [...root.querySelectorAll('[data-cl]')],
        lockstep: [...root.querySelectorAll('[data-lockstep]')], facts: [...root.querySelectorAll('[data-fact]')] };
      this.frame = (t, lt, D) => {
        put(el.kick, { o: S(t, 251.0, 251.7) });
        applyWords(root.querySelectorAll('[data-h] .kw'), stagger(t, 251.31, 0.09, 6, { y: 28 }));
        put(el.sub, { o: S(t, 252.5, 253.2) });
        el.nodes.forEach((n, i) => {
          const p = S(t, 251.6 + i * 0.10, 252.5 + i * 0.10, ez.outCubic);
          put(n, { o: p, x: lerp(-56, 0, p), blur: lerp(6, 0, p) });
        });
        el.cl.forEach((c, i) => trim(c, S(t, 253.3 + i * 0.12, 254.7 + i * 0.12, ez.inOutCubic), 700));
        const cp = S(t, 253.9, 255.0, ez.outCubic);
        put(el.core, { o: cp, s: lerp(0.85, 1, S(t, 253.9, 255.1, ez.outBackSoft)) });
        const lp = S(t, 256.9, 257.8, ez.outCubic);
        put(el.lock, { o: lp, s: lerp(0.88, 1, S(t, 256.9, 258.0, ez.outBackSoft)) });
        el.lockstep.forEach((s, i) => { const p = S(t, 257.6 + i * 0.22, 258.3 + i * 0.22, ez.outCubic); put(s, { o: p, x: lerp(-10, 0, p) }); });
        const gp = S(t, 259.1, 260.0, ez.outCubic);
        put(el.gate, { o: gp * 0.85, s: lerp(0.88, 1, gp) });
        el.facts.forEach((f, i) => { const p = S(t, 260.4 + i * 0.20, 261.1 + i * 0.20, ez.outCubic); put(f, { o: p, y: lerp(14, 0, p) }); });
      };
    }
  });

  /* =======================================================================
     SCENE 11 — THE MARKET OPPORTUNITY  (263.819 -> 278.296)
     ======================================================================= */
  SCENES.push({
    id: 'scene_11', portal: 'The opportunity',
    build(root) {
      root.classList.add('bg-paper');
      root.innerHTML = `
        <div style="position:absolute;inset:0;background:radial-gradient(900px 560px at 74% 30%, rgba(214,168,79,.10), transparent 72%)"></div>

        <div style="position:absolute;left:0;right:0;top:170px;text-align:center;z-index:20">
          <div class="micro c-muted" style="opacity:0" data-kick>The opportunity</div>
          <div style="display:flex;align-items:baseline;justify-content:center;gap:4px;margin-top:26px">
            <span class="display-xl" data-big style="color:var(--green);opacity:0">0</span>
            <span class="display-l" data-bigsub style="color:var(--green);opacity:0">,+</span>
          </div>
          <div class="headline" style="margin-top:14px;opacity:0;font-size:42px" data-lab>Indian colleges producing graduates every year</div>
        </div>

        <div style="position:absolute;left:50%;transform:translateX(-50%);top:520px;display:flex;gap:20px;z-index:21">
          ${[['s1', 'Applications', 'Job applications keep climbing every cycle.', 'trendUp', '#C2544A'],
             ['s2', 'Resume noise', 'Identical profiles make shortlisting a guessing game.', 'file', '#C98A2E'],
             ['s3', 'Proof gap', 'Almost no verified signal about what a graduate can build.', 'target', '#087A55']].map((s, i) => `
            <div data-scard="${i}" style="opacity:0;width:340px;background:#fff;border:1px solid rgba(30,41,59,.1);border-radius:16px;padding:24px 26px;box-shadow:0 18px 44px rgba(23,32,51,.08)">
              <span style="width:42px;height:42px;border-radius:11px;background:${s[4]}12;color:${s[4]};display:flex;align-items:center;justify-content:center">${ico(s[3], 20)}</span>
              <div style="font-size:22px;font-weight:800;letter-spacing:-.025em;margin-top:16px">${s[1]}</div>
              <div style="font-size:14.5px;color:var(--muted);margin-top:7px;line-height:1.5">${s[2]}</div>
            </div>`).join('')}
        </div>

        <div class="wedge" style="position:absolute;left:0;right:0;top:800px;display:flex;justify-content:center;z-index:22;opacity:0">
          <div style="display:inline-flex;align-items:center;gap:16px;padding:16px 30px;border-radius:14px;background:var(--navy);color:#fff;box-shadow:0 22px 50px rgba(23,32,51,.28)">
            <span style="color:#6EE7B7">${ico('arrow', 20)}</span>
            <span style="font-size:20px;font-weight:600">AptoHire starts where trust is verifiable — <b style="color:#F2C879">universities and students.</b></span>
          </div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = { kick: q('[data-kick]'), big: q('[data-big]'), bigsub: q('[data-bigsub]'), lab: q('[data-lab]'),
        scard: [...root.querySelectorAll('[data-scard]')], wedge: q('.wedge') };
      this.frame = (t, lt, D) => {
        put(el.kick, { o: S(t, 264.4, 265.1) });
        const p = S(t, 264.70, 267.30, ez.outQuart);
        put(el.big, { o: S(t, 264.55, 265.0), y: lerp(24, 0, p), s: lerp(0.9, 1, p) });
        el.big.textContent = Math.round(45000 * p).toLocaleString('en-IN');
        put(el.bigsub, { o: S(t, 266.2, 266.8) });
        put(el.lab, { o: S(t, 266.35, 267.05), y: lerp(14, 0, S(t, 266.35, 267.1, ez.outCubic)) });
        root.querySelector('[data-bigsub]').textContent = '+';
        el.scard.forEach((c, i) => { const pp = S(t, 266.5 + i * 0.22, 267.35 + i * 0.22, ez.outCubic); put(c, { o: pp, y: lerp(30, 0, pp), blur: lerp(7, 0, pp) }); });
        const w = S(t, 271.4, 272.4, ez.outCubic);
        put(el.wedge, { o: w, y: lerp(26, 0, w) });
      };
    }
  });

  /* =======================================================================
     SCENE 12 — BUSINESS MODEL & ROADMAP  (278.296 -> 292.688)
     ======================================================================= */
  SCENES.push({
    id: 'scene_12', portal: 'Model & roadmap',
    build(root) {
      root.classList.add('bg-paper');
      root.innerHTML = `
        <div style="position:absolute;inset:0;background:radial-gradient(1000px 620px at 30% 24%, rgba(8,122,85,.08), transparent 70%)"></div>
        <div style="position:absolute;left:120px;top:104px;z-index:20">
          <div class="micro c-green" style="opacity:0" data-kick>Model &amp; roadmap</div>
          <div class="display-m" style="margin-top:18px;max-width:1000px"><span data-h>${wordsHTML('Free for students. Forever.')}</span></div>
        </div>

        <div style="position:absolute;left:120px;top:318px;display:flex;gap:18px;z-index:21">
          ${[['Students', '₹0', 'forever', 'Every learner keeps full access, always.', true],
             ['Universities', 'Pilot', 'program', 'Institutional insight, priced after validation.', false],
             ['Organizations', 'Pilot', 'program', 'Skill-first hiring, priced on seats later.', false]].map((c, i) => `
            <div data-price="${i}" style="opacity:0;width:330px;border-radius:16px;padding:24px 26px;${c[4]
              ? 'background:linear-gradient(155deg,#0A5C41,#087A55);border:2px solid var(--gold);box-shadow:0 24px 56px rgba(8,122,85,.28);'
              : 'background:#fff;border:1px solid rgba(30,41,59,.1);box-shadow:0 16px 38px rgba(23,32,51,.07);'}">
              <div style="font-size:11.5px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:${c[4] ? '#9FE9C9' : 'var(--muted)'}">${c[0]}</div>
              <div style="display:flex;align-items:baseline;gap:8px;margin-top:12px">
                <span style="font-size:44px;font-weight:800;letter-spacing:-.04em;color:${c[4] ? '#fff' : 'var(--ink)'}">${c[1]}</span>
                <span style="font-size:15px;font-weight:600;color:${c[4] ? 'rgba(255,255,255,.7)' : 'var(--muted)'}">${c[2]}</span>
              </div>
              <div style="font-size:14px;color:${c[4] ? 'rgba(255,255,255,.75)' : 'var(--muted)'};margin-top:10px;line-height:1.5">${c[3]}</div>
            </div>`).join('')}
        </div>

        <div style="position:absolute;left:120px;right:120px;top:600px;z-index:22">
          <div style="font-size:11.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted);opacity:0" data-kick2>What comes next</div>
          <div style="position:relative;height:2px;background:rgba(30,41,59,.1);margin-top:26px;border-radius:2px">
            <div data-track style="position:absolute;left:0;top:0;height:2px;width:0;background:var(--green);border-radius:2px"></div>
          </div>
          <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:22px;margin-top:-9px">
            ${[['Harden', 'Security &amp; reliability', 0], ['Validate', 'University pilots', 1], ['Scale', 'Institutional plans', 2], ['Grow', 'Employer network', 3]].map((s, i) => `
              <div data-step="${i}" style="opacity:0">
                <div style="width:18px;height:18px;border-radius:50%;background:#fff;border:3px solid var(--green);box-shadow:0 0 0 4px rgba(8,122,85,.10)"></div>
                <div style="font-size:20px;font-weight:800;letter-spacing:-.02em;margin-top:16px">${s[0]}</div>
                <div style="font-size:13.5px;color:var(--muted);margin-top:4px">${s[1]}</div>
              </div>`).join('')}
          </div>
        </div>

        <div style="position:absolute;left:120px;right:120px;bottom:52px;z-index:23;opacity:0" data-foot>
          <div style="display:flex;align-items:center;gap:12px;font-size:15px;color:var(--muted)">
            ${ico('shield', 16, '#0B7F49')} Honest stage: working prototype as of October 2026. Pricing for institutions is a pilot program, not a public commitment.
          </div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = { kick: q('[data-kick]'), kick2: q('[data-kick2]'), price: [...root.querySelectorAll('[data-price]')],
        track: q('[data-track]'), step: [...root.querySelectorAll('[data-step]')], foot: q('[data-foot]') };
      this.frame = (t, lt, D) => {
        put(el.kick, { o: S(t, 278.6, 279.2), y: lerp(10, 0, S(t, 278.6, 279.3, ez.outCubic)) });
        applyWords(root.querySelectorAll('[data-h] .kw'), stagger(t, 278.81, 0.085, 4, { y: 30 }));
        el.price.forEach((c, i) => { const p = S(t, 280.15 + i * 0.20, 280.95 + i * 0.20, ez.outCubic); put(c, { o: p, y: lerp(28, 0, p), s: lerp(0.97, 1, p) }); });
        put(el.kick2, { o: S(t, 282.6, 283.2) });
        const tp = S(t, 283.0, 285.4, ez.inOutCubic);
        el.track.style.width = (tp * 100).toFixed(2) + '%';
        el.step.forEach((s, i) => { const p = S(t, 283.0 + i * 0.62, 283.7 + i * 0.62, ez.outCubic); put(s, { o: p, y: lerp(18, 0, p) }); });
        put(el.foot, { o: S(t, 286.0, 286.8) });
      };
    }
  });

  /* =======================================================================
     SCENE 13 — PROVE SKILLS. GET HIRED.  (292.688 -> 309.750)
     ======================================================================= */
  SCENES.push({
    id: 'scene_13', portal: 'AptoHire',
    build(root) {
      root.classList.add('bg-black');
      root.innerHTML = `
        <div class="broll" style="opacity:0" data-plate><img src="assets/broll_student_warm.webp" alt=""></div>
        <div class="broll-veil warm" style="background:radial-gradient(1000px 620px at 50% 52%, rgba(5,7,12,.86) 0%, rgba(5,7,12,.62) 46%, rgba(5,7,12,.35) 100%)"></div>
        <div class="letterbox"></div>

        <div class="s1" style="position:absolute;left:0;right:0;top:0;bottom:0;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:20;text-align:center;padding:0 160px;opacity:0">
          <div style="font-size:15px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:#F2C879;margin-bottom:26px">The belief</div>
          <div class="display-m" style="color:#fff;max-width:1320px;line-height:1.24;text-shadow:0 8px 44px rgba(0,0,0,.8)">
            <div data-l="0">${wordsHTML('Talent should never remain invisible')}</div>
            <div data-l="1" style="margin-top:6px">${wordsHTML('because it does not fit neatly on a page.')}</div>
          </div>
          <div class="display-m" style="margin-top:44px;color:#F2C879;text-shadow:0 8px 44px rgba(0,0,0,.8)">
            <span data-l="2">${wordsHTML('Your potential is what you can do with what you know.')}</span>
          </div>
        </div>

        <div class="s2" style="position:absolute;left:0;right:0;top:0;bottom:0;display:flex;flex-direction:column;align-items:center;justify-content:center;z-index:21;opacity:0">
          <div style="display:flex;align-items:center;justify-content:center" data-lockrow>
            <img src="assets/lockup_light.webp" alt="AptoHire" style="width:600px;display:block;filter:drop-shadow(0 20px 52px rgba(10,207,131,.3))">
          </div>
          <div style="margin-top:34px;display:flex;flex-direction:column;align-items:center;gap:12px;text-align:center">
            <div data-tag="0" style="font-size:50px;font-weight:800;letter-spacing:-.03em;color:#fff;opacity:0">Prove skills.</div>
            <div data-tag="1" style="font-size:50px;font-weight:800;letter-spacing:-.03em;color:#6EE7B7;opacity:0">Match potential.</div>
            <div data-tag="2" style="font-size:50px;font-weight:800;letter-spacing:-.03em;color:#F2C879;opacity:0">Get hired.</div>
          </div>
          <div class="endcard-urls" style="margin-top:46px;opacity:0" data-urls>
            <span class="u">aptohire.vercel.app</span>
            <span class="u">aptohire-student.vercel.app</span>
            <span class="u">aptohire-organization.vercel.app</span>
            <span class="u">aptohire-university.vercel.app</span>
            <span class="u">aptohire-admin.vercel.app</span>
          </div>
          <div style="margin-top:26px;font-size:13px;letter-spacing:.1em;text-transform:uppercase;color:rgba(255,255,255,.4);opacity:0" data-fine>
            Working prototype · October 2026 · All sample data is fictional
          </div>
        </div>

        <div class="endcap" style="position:absolute;inset:0;z-index:30;background:#05070C;opacity:0"></div>
      `;
      const q = s => root.querySelector(s);
      const el = { plate: q('[data-plate]'), img: q('[data-plate] img'), s1: q('.s1'), s2: q('.s2'),
        lockrow: q('[data-lockrow]'), tags: [0, 1, 2].map(i => q(`[data-tag="${i}"]`)),
        urls: q('[data-urls]'), fine: q('[data-fine]'), endcap: q('.endcap') };
      this.frame = (t, lt, D) => {
        put(el.plate, { o: S(t, 292.80, 294.2) });
        put(el.img, { s: lerp(1.09, 1.0, S(t, 292.8, 306.0, ez.linear)), x: lerp(-10, 14, S(t, 292.8, 306.0, ez.linear)) });

        const s1o = S(t, 292.80, 293.6) * (1 - S(t, 300.55, 301.35, ez.inCubic));
        put(el.s1, { o: s1o, y: lerp(0, -26, S(t, 300.4, 301.6, ez.inOutCubic)) });
        ['0', '1', '2'].forEach((k, i) => {
          const t0 = [293.47, 295.63, 298.01][i];
          applyWords(root.querySelectorAll(`[data-l="${k}"] .kw`), stagger(t, t0, 0.062, 7, { y: 32 }));
        });
        // second line reveal (298.01) continues; fine.
        const s2o = S(t, 301.55, 302.45, ez.outCubic);
        put(el.s2, { o: s2o });
        const lp = S(t, 301.35, 302.60, ez.outBackSoft);
        put(el.lockrow, { s: lerp(0.86, 1, lp), o: S(t, 301.30, 301.9) });
        el.tags.forEach((d, i) => {
          const t0 = [302.59, 303.89, 305.13][i];
          const p = S(t, t0, t0 + 0.62, ez.outCubic);
          put(d, { o: p, y: lerp(22, 0, p), blur: lerp(8, 0, p) });
        });
        put(el.urls, { o: S(t, 306.05, 306.9), y: lerp(14, 0, S(t, 306.05, 306.95, ez.outCubic)) });
        put(el.fine, { o: S(t, 306.60, 307.4) });
        put(el.endcap, { o: S(t, 309.05, 309.72, ez.inOutCubic) });
      };
    }
  });
})();
