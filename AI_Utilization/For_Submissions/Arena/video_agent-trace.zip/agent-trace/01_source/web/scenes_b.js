/* =========================================================================
   AptoHire Film — Scenes 5-7  (Organization · University · Admin)
   ========================================================================= */
(function () {
  'use strict';
  const { ez, S, lerp, clamp, put, enter, exit, inout, stagger, wordsHTML, applyWords, trim, ico } = AH;
  const SCENES = window.SCENES;

  function sidebar(o) {
    const items = o.nav.map(n => `
      <div class="nav-item ${n.label === o.active ? 'active' : ''}">
        <span style="display:flex;align-items:center;gap:10px">${ico(n.icon, 18)}${n.label}</span>
        ${n.badge ? `<span class="nav-badge">${n.badge}</span>` : ''}
      </div>`).join('');
    return `
    <div class="portal-sidebar ${o.tint || ''}">
      <div class="brand-lockup">
        <img class="brand-logo" src="assets/lockup_dark.webp" alt="AptoHire">
        <span class="role-pill">${o.role}</span>
      </div>
      ${items}
      ${o.footer ? `<div style="margin-top:auto">${o.footer}</div>` : ''}
    </div>`;
  }
  function toprail(num, label, url, badge) {
    return `
    <div style="position:absolute;left:0;right:0;top:0;height:96px;display:flex;align-items:center;justify-content:space-between;padding:0 44px;z-index:25;border-bottom:1px solid rgba(30,41,59,.07);background:rgba(255,255,255,.7)">
      <div style="display:flex;align-items:center;gap:14px" data-rail>
        <span style="font-family:var(--mono);font-size:12px;font-weight:700;letter-spacing:.14em;padding:5px 11px;border-radius:6px;background:var(--green);color:#fff">${num}</span>
        <span style="font-size:13px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--muted)">${label}</span>
      </div>
      <div style="display:flex;align-items:center;gap:10px" data-rail2>
        <span style="display:flex;align-items:center;gap:7px;font-family:var(--mono);font-size:12.5px;color:var(--muted)">${ico('globe', 14)} ${url}</span>
        <span style="font-size:11px;font-weight:700;letter-spacing:.08em;padding:4px 9px;border-radius:999px;background:var(--mint);color:var(--green);border:1px solid rgba(8,122,85,.2)">${badge}</span>
      </div>
    </div>`;
  }
  function rigShell(top, w, h) {
    return `<div class="iso-rig" style="top:${top}px"><div class="iso-plane" data-plane style="width:${w}px;height:${h}px">
      <div class="portal-window" style="width:${w}px;height:${h}px;grid-template-columns:236px 1fr" data-pw>`;
  }

  const CAND = [
    ['K7F2', 'Tier 2 · University', 86, 'High', 'Year 3', 3, 'Awaiting response', false],
    ['M3Q8', 'Tier 2 · University', 81, 'High', 'Year 3', 3, 'Access accepted', true],
    ['T9R4', 'Tier 3 · University', 66, 'Medium', 'Alumni', 2, 'Request access', false],
    ['P2W5', 'Tier 3 · University', 62, 'Medium', 'Year 2', 2, 'Request access', false],
    ['B8N1', 'Tier 3 · University', 60, 'Medium', 'Year 4', 1, 'Request access', false],
    ['L4D7', 'Tier 3 · University', 58, 'Medium', 'Alumni', 2, 'Request access', false],
  ];

  /* =======================================================================
     SCENE 05 — ORGANIZATION PORTAL  (119.294 -> 157.005)
     ======================================================================= */
  SCENES.push({
    id: 'scene_05', portal: 'Organization portal',
    build(root) {
      root.classList.add('bg-paper');
      const nav = [{ label: 'Jobs', icon: 'briefcase' }, { label: 'Candidates', icon: 'users' },
        { label: 'Requests', icon: 'lock' }, { label: 'Pipeline', icon: 'layers' }, { label: 'Directory', icon: 'building' }];
      root.innerHTML = toprail('05', 'Organization portal · the hirer', 'aptohire-organization.vercel.app', 'LIVE PROTOTYPE') + `
        <div class="iso-rig" style="top:96px"><div class="iso-plane" data-plane style="width:1700px;height:840px">
          <div class="portal-window" style="width:1700px;height:840px;grid-template-columns:236px 1fr" data-pw>
            ${sidebar({ role: 'org', nav, active: 'Jobs', tint: 'org-tint' })}
            <div class="portal-main">

              <!-- 1. JOBS HOME -->
              <div class="ps" data-ps="0" style="padding:26px 34px">
                <div class="hero-band" style="background:linear-gradient(120deg,#FFF6EC 0%,#FDFBF7 58%,#F2F8F4 100%);padding:28px 32px;display:flex;align-items:center;justify-content:space-between">
                  <div>
                    <div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">
                      <span class="tag amber">${ico('sparkle', 13)} Welcome back, R. Mehta</span>
                      <span class="tag ghost">Demo workspace</span>
                    </div>
                    <div style="font-size:44px;font-weight:800;letter-spacing:-.04em;line-height:1.08">Build your team around<br><span style="color:var(--green)">what they can do.</span></div>
                    <div style="font-size:16px;color:var(--muted);margin-top:14px;max-width:520px;line-height:1.5">Review skill-first matches, move roles forward, and keep candidate identity private until consent.</div>
                    <div style="margin-top:20px;display:flex;gap:12px">
                      <span style="padding:12px 22px;border-radius:10px;background:var(--amber-cta);color:#fff;font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px">${ico('plus', 16)} Create a role</span>
                      <span class="tag ghost" style="padding:12px 18px;font-size:14px">${ico('search', 15)} Explore candidates</span>
                    </div>
                  </div>
                  <div style="display:flex;flex-direction:column;gap:14px;align-items:flex-end">
                    <span class="tag" style="padding:10px 16px;font-size:14px">${ico('checkCircle', 15)} Verified skills</span>
                    <span class="tag gold" style="padding:10px 16px;font-size:14px">${ico('lock', 15)} Blind by default</span>
                  </div>
                </div>

                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin-top:18px">
                  ${[['Open roles', '2', 'of 2 sample roles'], ['Candidate matches', '23', 'across all roles'], ['Access requests', '3', 'review consent status']].map((k, i) => `
                    <div class="card-lite" style="padding:18px 22px;display:flex;align-items:center;justify-content:space-between" data-kpi="${i}">
                      <div>
                        <div style="font-size:11.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)">${k[0]}</div>
                        <div style="display:flex;align-items:baseline;gap:9px;margin-top:7px"><span class="mono" style="font-size:36px;font-weight:800;letter-spacing:-.04em" data-count>${k[1]}</span></div>
                        <div style="font-size:12.5px;color:var(--muted);margin-top:4px">${k[2]}</div>
                      </div>
                      <span style="width:40px;height:40px;border-radius:11px;background:var(--mint);display:flex;align-items:center;justify-content:center;color:var(--green)">${ico(['briefcase', 'users', 'lock'][i], 19)}</span>
                    </div>`).join('')}
                </div>

                <div style="margin-top:20px;font-size:11.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)">Your workspace</div>
                <div style="font-size:24px;font-weight:700;letter-spacing:-.02em;margin-top:4px">Your roles <span style="font-size:15px;font-weight:600;color:var(--muted)">2</span></div>
                <div class="card-lite" style="margin-top:12px;padding:0;overflow:hidden">
                  <table class="dtable" style="font-size:14px">
                    <thead><tr><th style="padding-left:22px">Role</th><th>Status</th><th>Openings</th><th>Mode / location</th><th>Required skills</th><th>Matches</th><th>Requests</th></tr></thead>
                    <tbody>
                      <tr data-job="0">
                        <td style="padding-left:22px;font-weight:700">Front-end developer (React)</td>
                        <td><span class="tag" style="font-size:11.5px;padding:3px 9px">Open</span></td>
                        <td class="mono">2</td>
                        <td>Hybrid · Bengaluru</td>
                        <td style="font-size:12.5px">React · Proficient<span style="color:var(--muted)"> / </span>TypeScript · Competent</td>
                        <td class="mono" style="font-weight:700">14</td>
                        <td class="mono" style="font-weight:700;color:var(--amber-cta)">2</td>
                      </tr>
                      <tr data-job="1">
                        <td style="padding-left:22px;font-weight:700">Backend engineer (Node.js)</td>
                        <td><span class="tag ghost" style="font-size:11.5px;padding:3px 9px">Paused</span></td>
                        <td class="mono">1</td>
                        <td>Remote · India</td>
                        <td style="font-size:12.5px">Node.js · Competent<span style="color:var(--muted)"> / </span>SQL · Competent</td>
                        <td class="mono" style="font-weight:700">9</td>
                        <td class="mono" style="font-weight:700">1</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              <!-- 2. POST A JOB -->
              <div class="ps" data-ps="1" style="padding:22px 34px">
                <div style="font-size:13px;color:var(--muted);margin-bottom:10px">${ico('arrow', 13)} Jobs</div>
                <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Post a job</div>
                <div style="font-size:15px;color:var(--muted);margin-top:5px">Write a clear role brief so skill-first matches can find you.</div>
                <div style="display:flex;align-items:center;gap:16px;margin-top:14px">
                  <span style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;color:var(--green)"><span style="width:24px;height:24px;border-radius:50%;background:var(--green);color:#fff;display:flex;align-items:center;justify-content:center;font-size:12px">1</span>Role details</span>
                  <span style="width:60px;height:1px;background:rgba(30,41,59,.16)"></span>
                  <span style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:600;color:var(--muted)"><span style="width:24px;height:24px;border-radius:50%;background:#E9EEF0;color:var(--muted);display:flex;align-items:center;justify-content:center;font-size:12px">2</span>Skills &amp; publish</span>
                  <span style="margin-left:auto;display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--muted)">${ico('lock', 13)} Only role details are shared</span>
                </div>

                <div style="display:grid;grid-template-columns:1.55fr 1fr;gap:20px;margin-top:16px">
                  <div class="card-lite" style="padding:20px 24px">
                    <div style="display:flex;align-items:center;gap:10px;font-size:17px;font-weight:700;margin-bottom:4px">${ico('briefcase', 17)} Role details</div>
                    <div style="font-size:12.5px;color:var(--muted);margin-bottom:14px">Start with the essentials candidates need to know.</div>
                    <div style="font-size:12.5px;font-weight:600;color:var(--muted);margin-bottom:6px">Job title <span class="c-green">*</span></div>
                    <div style="border:1px solid rgba(30,41,59,.14);border-radius:8px;padding:10px 13px;font-size:14px" data-typed>Front-end Developer (React)<span style="display:inline-block;width:1.5px;height:15px;background:var(--green);vertical-align:-3px;margin-left:2px"></span></div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px">
                      <div><div style="font-size:12.5px;font-weight:600;color:var(--muted);margin-bottom:6px">Openings <span class="c-green">*</span></div>
                      <div style="border:1px solid rgba(30,41,59,.14);border-radius:8px;padding:10px 13px;font-size:14px" class="mono">2</div></div>
                      <div><div style="font-size:12.5px;font-weight:600;color:var(--muted);margin-bottom:6px">Work mode</div>
                      <div style="border:1px solid rgba(30,41,59,.14);border-radius:8px;padding:10px 13px;font-size:14px;display:flex;justify-content:space-between">Hybrid ${ico('chevron', 14, '#94A3B8')}</div></div>
                    </div>
                    <div style="font-size:12.5px;font-weight:600;color:var(--muted);margin:14px 0 6px">Location</div>
                    <div style="border:1px solid rgba(30,41,59,.14);border-radius:8px;padding:10px 13px;font-size:14px;display:flex;align-items:center;gap:8px;width:fit-content">${ico('target', 14, '#94A3B8')} Bengaluru, Karnataka</div>

                    <div style="margin-top:16px;font-size:12.5px;font-weight:600;color:var(--muted);margin-bottom:8px">Required skills</div>
                    <div style="display:flex;flex-wrap:wrap;gap:8px" data-reqskills>
                      ${[['React', 'Proficient'], ['TypeScript', 'Competent'], ['Testing', 'Competent']].map((s, i) => `
                        <span class="reqs" data-req="${i}" style="display:inline-flex;align-items:center;gap:8px;font-size:13px;font-weight:600;padding:7px 13px;border-radius:999px;border:1px solid rgba(8,122,85,.28);background:var(--mint);color:var(--green);opacity:0">
                          ${ico('check', 12)} ${s[0]} <span style="font-weight:500;color:var(--muted);font-size:12px">${s[1]}</span>
                        </span>`).join('')}
                      <span style="display:inline-flex;align-items:center;gap:7px;font-size:12.5px;font-weight:600;color:var(--green);padding:7px 13px;border-radius:999px;border:1px dashed rgba(8,122,85,.35)">${ico('sparkle', 12)} Read from description</span>
                    </div>
                  </div>

                  <div style="display:flex;flex-direction:column;gap:14px">
                    <div style="border-radius:14px;padding:20px 22px;background:linear-gradient(160deg,#EAF7EF,#F4FBF7);border:1px solid rgba(8,122,85,.24)">
                      <div style="font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:var(--green);margin-bottom:14px">Live preview</div>
                      <div style="width:38px;height:38px;border-radius:10px;background:#fff;display:flex;align-items:center;justify-content:center;color:var(--green);margin-bottom:12px">${ico('briefcase', 19)}</div>
                      <div style="font-size:22px;font-weight:800;letter-spacing:-.025em;line-height:1.15">Front-end Developer (React)</div>
                      <div style="font-size:13px;color:var(--muted);margin-top:6px">Hybrid · Bengaluru, Karnataka</div>
                      <div style="font-size:13px;color:var(--muted);margin-top:3px">2 openings</div>
                      <div style="height:1px;background:rgba(8,122,85,.16);margin:14px 0"></div>
                      <div style="font-size:11.5px;color:var(--muted);margin-bottom:8px">Looking for</div>
                      <div style="display:flex;gap:7px;flex-wrap:wrap"><span class="tag" style="font-size:11.5px;padding:3px 9px">React</span><span class="tag" style="font-size:11.5px;padding:3px 9px">TypeScript</span></div>
                      <div style="display:flex;align-items:center;gap:7px;font-size:12px;color:var(--muted);margin-top:14px;padding-top:12px;border-top:1px solid rgba(8,122,85,.14)">${ico('lock', 12)} Matches are blind by default</div>
                    </div>
                    <div style="border-radius:12px;padding:14px 16px;background:#FDF4E7;border:1px solid rgba(214,168,79,.3);font-size:12.5px;color:#8A5F10;line-height:1.5">
                      <b>Helpful tip</b><br>Focus on skills that can be demonstrated in projects or reviewed evidence.
                    </div>
                    <span style="padding:12px;border-radius:9px;background:var(--amber-cta);color:#fff;font-size:14px;font-weight:700;text-align:center;display:flex;align-items:center;justify-content:center;gap:8px">Publish job ${ico('arrow', 15)}</span>
                  </div>
                </div>
              </div>

              <!-- 3. CANDIDATES -->
              <div class="ps" data-ps="2" style="padding:22px 34px">
                <div style="display:flex;align-items:flex-end;justify-content:space-between">
                  <div>
                    <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Candidates</div>
                    <div style="font-size:14px;color:var(--muted);margin-top:5px">Explore skill-first matches. Candidate identity remains hidden unless the student chooses to share it.</div>
                  </div>
                  <div style="display:flex;align-items:center;gap:9px;font-size:12.5px;font-weight:600;color:var(--muted);background:#F4F7F5;border:1px solid rgba(30,41,59,.09);border-radius:9px;padding:9px 14px">${ico('lock', 14, '#B8862B')} Identity hidden until consent</div>
                </div>

                <div style="display:flex;align-items:center;gap:14px;margin-top:14px;padding:12px 18px;border-radius:11px;background:#F6FAF7;border:1px solid rgba(8,122,85,.14)">
                  <div style="display:flex;align-items:center;gap:8px;font-size:13px;font-weight:700;color:var(--green)">${ico('target', 15)} 14 candidates</div>
                  <span style="font-size:13px;color:var(--muted)">Ranked by verified skill fit, not predicted hiring success.</span>
                  <span style="margin-left:auto;font-size:12px;color:var(--muted);display:flex;align-items:center;gap:7px">${ico('filter', 13)} Front-end Developer (React)</span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-top:14px">
                  ${CAND.slice(0, 6).map((c, i) => `
                    <div class="cand-card ${c[7] ? 'sel' : ''}" data-cand="${i}">
                      <div style="display:flex;align-items:flex-start;justify-content:space-between">
                        <div style="display:flex;align-items:center;gap:9px">
                          <span style="width:30px;height:30px;border-radius:50%;background:#F0F4F2;display:flex;align-items:center;justify-content:center;color:#94A3B8">${ico('user', 16)}</span>
                          <div>
                            <div style="font-size:14.5px;font-weight:700">Candidate ${c[0]}</div>
                            <div style="font-size:11.5px;color:var(--muted)">${c[1]}</div>
                          </div>
                        </div>
                        <span style="color:#CBD5E1">${ico('arrowUR', 13)}</span>
                      </div>
                      <div style="display:flex;align-items:baseline;gap:4px;margin-top:12px">
                        <span class="mono" style="font-size:27px;font-weight:800;letter-spacing:-.03em" data-fit="${i}">${c[2]}</span>
                        <span style="font-size:11.5px;color:var(--muted);margin-right:auto">% skill fit</span>
                        <span class="tag ${c[3] === 'High' ? '' : 'ghost'}" style="font-size:10.5px;padding:2px 7px">${ico('checkCircle', 10)} ${c[3]}</span>
                      </div>
                      <div class="bar-track" style="height:5px;margin-top:8px"><div class="bar-fill" data-fitbar="${i}" style="transform:scaleX(0)"></div></div>
                      <div style="display:flex;align-items:center;gap:10px;margin-top:9px;font-size:11px;color:var(--muted)">
                        <span style="display:flex;align-items:center;gap:4px">${ico('user', 11)} ${c[4]}</span>
                        <span style="display:flex;align-items:center;gap:4px">${ico('file', 11)} ${c[5]} reviewed projects</span>
                      </div>
                      <div style="display:flex;gap:5px;flex-wrap:wrap;margin-top:9px">
                        <span class="tag" style="font-size:10.5px;padding:2px 7px">${ico('check', 9)} React Proficient</span>
                        <span class="tag" style="font-size:10.5px;padding:2px 7px">TypeScript Competent</span>
                      </div>
                      <div style="display:flex;align-items:center;justify-content:space-between;margin-top:11px;padding-top:10px;border-top:1px solid rgba(30,41,59,.08)">
                        <span style="font-size:11.5px;font-weight:600;color:var(--green);display:flex;align-items:center;gap:5px">See evidence ${ico('arrowUR', 11)}</span>
                        <span style="font-size:11px;color:var(--muted)">${c[6]}</span>
                      </div>
                    </div>`).join('')}
                </div>
              </div>

              <!-- 4. REQUESTS -->
              <div class="ps" data-ps="3" style="padding:24px 34px">
                <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Requests</div>
                <div style="font-size:14px;color:var(--muted);margin-top:5px">Review access requests while keeping each student in control of their data.</div>

                <div style="display:flex;align-items:center;gap:12px;margin-top:16px;padding:13px 18px;border-radius:11px;background:#FDF8F1;border:1px solid rgba(214,168,79,.28)">
                  ${ico('lock', 17, '#B8862B')}
                  <div style="flex:1">
                    <div style="font-size:14.5px;font-weight:700">Consent stays in the student's hands.</div>
                    <div style="font-size:12.5px;color:var(--muted);margin-top:2px">Each student chooses what to share and for how long.</div>
                  </div>
                  <span style="font-size:12px;color:#8A5F10;font-weight:600">Sample data</span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(2,180px) 1fr;gap:14px;margin-top:16px;align-items:start">
                  <div class="card-lite" style="padding:14px 18px">
                    <div style="font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)">Pending responses</div>
                    <div class="mono" style="font-size:30px;font-weight:800;margin-top:4px" data-cnt="1">1</div>
                  </div>
                  <div class="card-lite" style="padding:14px 18px">
                    <div style="font-size:11px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)">Accepted</div>
                    <div class="mono" style="font-size:30px;font-weight:800;margin-top:4px" data-cnt="1">1</div>
                  </div>
                  <div style="display:flex;justify-content:flex-end;align-items:center">
                    <span class="tag" style="gap:8px;padding:9px 15px;font-size:13px">${ico('lock', 14)} No data is revealed before consent</span>
                  </div>
                </div>

                <div style="display:flex;align-items:center;gap:6px;margin-top:18px">
                  ${[['Pending', '1', true], ['Accepted', '1', false], ['Declined', '1', false], ['Closed', '1', false]].map(t => `
                    <span class="tag ${t[2] ? '' : 'ghost'}" style="font-size:12.5px;padding:6px 13px;gap:6px">${t[0]} <span class="mono" style="opacity:.65">${t[1]}</span></span>`).join('')}
                </div>

                <div style="margin-top:16px">
                  <div style="font-size:11.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)">Request history</div>
                  <div style="font-size:22px;font-weight:700;letter-spacing:-.02em;margin-top:3px">Pending requests <span style="font-size:14px;font-weight:600;color:var(--muted)">1</span></div>
                </div>

                <div class="card-lite" style="margin-top:12px;padding:18px 22px">
                  <div style="display:flex;align-items:flex-start;justify-content:space-between">
                    <div style="display:flex;align-items:center;gap:11px">
                      <span style="width:34px;height:34px;border-radius:50%;background:#F0F4F2;display:flex;align-items:center;justify-content:center;color:#94A3B8">${ico('user', 17)}</span>
                      <div>
                        <div style="font-size:16px;font-weight:700">Candidate K7F2</div>
                        <div style="font-size:12px;color:var(--muted)">Front-end Developer (React)</div>
                      </div>
                    </div>
                    <span class="tag amber" style="font-size:12px;padding:5px 12px">${ico('clock', 12)} Waiting for the student</span>
                  </div>
                  <div style="display:grid;grid-template-columns:1.4fr 1fr 1fr;gap:12px;margin-top:14px">
                    ${[['Requested information', 'Profile · Scorecard'], ['Access duration', '30 days'], ['Request sent', 'Today']].map(r => `
                      <div style="background:#F7FAF8;border:1px solid rgba(30,41,59,.07);border-radius:9px;padding:10px 13px">
                        <div style="font-size:10.5px;font-weight:700;letter-spacing:.08em;text-transform:uppercase;color:var(--muted)">${r[0]}</div>
                        <div style="font-size:14px;font-weight:700;margin-top:3px">${r[1]}</div>
                      </div>`).join('')}
                  </div>
                  <div style="display:flex;align-items:center;justify-content:space-between;margin-top:13px;padding-top:12px;border-top:1px solid rgba(30,41,59,.07)">
                    <span style="font-size:12.5px;color:var(--muted);display:flex;align-items:center;gap:7px">${ico('lock', 13, '#B8862B')} No candidate data is shared in this state</span>
                    <span style="font-size:12.5px;font-weight:700;color:var(--green);display:flex;align-items:center;gap:6px">View details ${ico('arrow', 12)}</span>
                  </div>
                </div>
              </div>

              <!-- 5. PIPELINE -->
              <div class="ps" data-ps="4" style="padding:24px 34px">
                <div style="display:flex;align-items:flex-end;justify-content:space-between">
                  <div>
                    <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Pipeline</div>
                    <div style="font-size:14px;color:var(--muted);margin-top:5px">Track each match as it moves through your hiring process. Later-stage notes are private to your team.</div>
                  </div>
                  <span class="tag ghost" style="padding:8px 14px;font-size:12.5px">${ico('refresh', 13)} Reset board</span>
                </div>

                <div style="display:flex;align-items:center;gap:11px;margin-top:14px;padding:11px 18px;border-radius:10px;background:#F6F8F7;border:1px solid rgba(30,41,59,.08)">
                  ${ico('layers', 16, '#657186')}
                  <div style="flex:1;font-size:12.5px;color:var(--muted)"><b style="color:var(--ink)">Keep the process moving.</b> Drag cards between stages or use the stage menu. Updates here are internal notes only.</div>
                  <span class="tag ghost" style="font-size:11.5px">Sample data</span>
                </div>

                <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:12px;margin-top:16px">
                  ${[['Matched', 12, '#0B7F49', ['T9R4', '66', 'Medium', 'Tier 3 · University'], ['P2W5', '62', 'Medium', 'Tier 3 · University']],
                     ['Requested', 1, '#EA6A15', ['K7F2', '86', 'High', 'Tier 2 · University']],
                     ['Accepted', 1, '#0B7F49', ['M3Q8', '81', 'High', 'Tier 2 · University']],
                     ['Interviewing', 0, '#657186', []],
                     ['Offer / Closed', 0, '#657186', []]].map((col, ci) => `
                    <div data-col="${ci}">
                      <div class="col-head"><span style="display:flex;align-items:center;gap:7px"><span class="dot" style="background:${col[2]}"></span>${col[0]}</span><span class="mono" style="opacity:.7">${col[1]}</span></div>
                      ${col[3].length ? col[3].map(c => `
                        <div class="cand-card" style="margin-bottom:9px;padding:12px 13px">
                          <div style="display:flex;align-items:flex-start;justify-content:space-between">
                            <div style="display:flex;align-items:center;gap:7px">
                              <span style="width:24px;height:24px;border-radius:50%;background:#F0F4F2;display:flex;align-items:center;justify-content:center;color:#94A3B8">${ico('user', 13)}</span>
                              <div><div style="font-size:12.5px;font-weight:700">Candidate</div><div style="font-size:10.5px;color:var(--muted)">${c[0]}</div></div>
                            </div>
                          </div>
                          <div style="display:flex;align-items:center;gap:5px;margin-top:8px;font-size:10.5px;color:var(--muted)"><span class="mono" style="font-weight:800;font-size:13px;color:var(--ink)">${c[1]}%</span> skill fit · ${c[2]}</div>
                          <div style="margin-top:8px;padding:5px 8px;border-radius:7px;border:1px solid rgba(30,41,59,.1);font-size:10.5px;display:flex;align-items:center;justify-content:space-between;background:#FBFCFB">Stage ${ico('chevron', 9, '#94A3B8')}</div>
                        </div>`).join('') : `
                        <div style="border:1.5px dashed rgba(30,41,59,.14);border-radius:10px;height:110px;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:6px;color:#B6C2CC">
                          ${ico('chevron', 15)}<span style="font-size:11px;color:var(--muted)">Drop a match here</span>
                        </div>`}
                    </div>`).join('')}
                </div>
              </div>

            </div>
          </div>
        </div></div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        plane: q('[data-plane]'), rail: q('[data-rail]'), rail2: q('[data-rail2]'),
        screens: [...root.querySelectorAll('[data-ps]')],
        typed: q('[data-typed]'), req: [...root.querySelectorAll('[data-req]')],
        cand: [...root.querySelectorAll('[data-cand]')], fit: [...root.querySelectorAll('[data-fit]')],
        fitbar: [...root.querySelectorAll('[data-fitbar]')], cols: [...root.querySelectorAll('[data-col]')],
        kpi: [...root.querySelectorAll('[data-kpi]')],
      };
      const FULL = 'Front-end Developer (React)';

      this.frame = (t, lt, D) => {
        const inP = S(t, 119.30, 120.6, ez.outQuart);
        put(el.plane, { o: S(t, 119.30, 120.1), ry: lerp(-19, 0, inP), rx: lerp(9, 0, inP), rz: lerp(-1.6, 0, inP), z: lerp(-140, 0, inP), s: lerp(0.9, 1, inP), y: lerp(50, 0, inP) });
        put(el.rail, { o: S(t, 119.4, 120.05), x: lerp(-16, 0, S(t, 119.4, 120.2, ez.outCubic)) });
        put(el.rail2, { o: S(t, 119.55, 120.2) });
        el.kpi.forEach((c, i) => { const p = S(t, 120.3 + i * 0.1, 121.1 + i * 0.1, ez.outCubic); put(c, { o: p, y: lerp(24, 0, p) }); });

        const s0 = 1 - S(t, 122.75, 123.45, ez.inOutCubic);
        put(el.screens[0], { o: s0, x: lerp(0, -70, S(t, 122.75, 123.5, ez.inCubic)) });
        const s1i = S(t, 122.8, 123.55, ez.outCubic), s1o = 1 - S(t, 127.05, 127.75, ez.inOutCubic);
        put(el.screens[1], { o: s1i * s1o, x: lerp(70, 0, s1i) });
        const s2i = S(t, 127.10, 127.85, ez.outCubic), s2o = 1 - S(t, 139.10, 139.85, ez.inOutCubic);
        put(el.screens[2], { o: s2i * s2o, x: lerp(70, 0, s2i) + lerp(0, -70, s2o < 1 ? 1 - s2o : 0) });
        const s3i = S(t, 139.15, 139.95, ez.outCubic), s3o = 1 - S(t, 149.50, 150.25, ez.inOutCubic);
        put(el.screens[3], { o: s3i * s3o, x: lerp(70, 0, s3i) + lerp(0, -70, s3o < 1 ? 1 - s3o : 0) });
        const s4i = S(t, 149.55, 150.35, ez.outCubic);
        put(el.screens[4], { o: s4i, x: lerp(70, 0, s4i) });

        // job title type-on 123.0-127.0
        if (el.typed) { const p = S(t, 123.0, 126.4, ez.linear); el.typed.firstChild.nodeValue = FULL.slice(0, Math.round(FULL.length * p)); }
        // required skill chips 126.0-131.0
        el.req.forEach((c, i) => { const p = S(t, 126.10 + i * 0.62, 126.8 + i * 0.62, ez.outCubic); put(c, { o: p, s: lerp(0.9, 1, p), y: lerp(10, 0, p) }); });

        // candidate cards 130.9-141.8
        el.cand.forEach((c, i) => {
          const p = S(t, 130.95 + i * 0.19, 131.75 + i * 0.19, ez.outCubic);
          put(c, { o: p, y: lerp(28, 0, p), s: lerp(0.97, 1, p), blur: lerp(6, 0, p) });
          const bp = S(t, 131.4 + i * 0.19, 132.4 + i * 0.19, ez.outCubic);
          if (el.fitbar[i]) el.fitbar[i].style.transform = `scaleX(${(bp * CAND[i][2] / 100).toFixed(4)})`;
          if (el.fit[i]) el.fit[i].textContent = Math.round(CAND[i][2] * bp);
        });
        // highlight K7F2 during 137.6-143
        if (el.cand[0]) {
          const hl = S(t, 137.5, 138.2, ez.outCubic) * (1 - S(t, 143.2, 143.9, ez.inOutCubic));
          el.cand[0].style.boxShadow = `0 0 0 ${(3 * hl).toFixed(1)}px rgba(8,122,85,${(0.16 * hl).toFixed(2)}), 0 ${(14 * hl).toFixed(0)}px 34px rgba(8,122,85,${(0.16 * hl).toFixed(2)})`;
        }
        // pipeline columns 150.5-155
        el.cols.forEach((c, i) => { const p = S(t, 150.55 + i * 0.12, 151.35 + i * 0.12, ez.outCubic); put(c, { o: p, y: lerp(26, 0, p) }); });
      };
    }
  });

  /* =======================================================================
     SCENE 06 — UNIVERSITY PORTAL  (157.005 -> 188.304)
     ======================================================================= */
  SCENES.push({
    id: 'scene_06', portal: 'University portal',
    build(root) {
      root.classList.add('bg-paper');
      const nav = [{ label: 'Overview', icon: 'home' }, { label: 'Students', icon: 'users' },
        { label: 'Roster', icon: 'list' }, { label: 'Placements', icon: 'flag' }, { label: 'Skills demand', icon: 'chart' }];
      root.innerHTML = toprail('06', 'University portal · the TPO', 'aptohire-university.vercel.app', 'LIVE PROTOTYPE') + `
        <div class="iso-rig" style="top:96px"><div class="iso-plane" data-plane style="width:1700px;height:840px">
          <div class="portal-window" style="width:1700px;height:840px;grid-template-columns:236px 1fr" data-pw>
            ${sidebar({ role: 'uni', nav, active: 'Overview' })}
            <div class="portal-main">

              <!-- 1. OVERVIEW -->
              <div class="ps" data-ps="0" style="padding:22px 30px">
                <div class="hero-band green" style="padding:26px 30px;display:flex;align-items:center;justify-content:space-between;overflow:hidden">
                  <div style="position:absolute;right:-60px;top:-70px;width:340px;height:340px;border-radius:50%;background:rgba(255,255,255,.05)"></div>
                  <div style="position:relative">
                    <div style="display:flex;align-items:center;gap:8px;font-size:11.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.62);margin-bottom:14px">${ico('sparkle', 12)} Your university in focus · Jaipur, Rajasthan</div>
                    <div style="font-size:40px;font-weight:800;letter-spacing:-.035em;line-height:1.1">Aravalli Institute of Technology</div>
                    <div style="font-size:15.5px;color:rgba(255,255,255,.78);margin-top:10px">A clear view of student progress, verified skills, and employer demand.</div>
                    <div style="display:flex;gap:11px;margin-top:18px">
                      <span style="padding:10px 19px;border-radius:9px;background:#F2C879;color:#3D2A06;font-size:13.5px;font-weight:700;display:flex;align-items:center;gap:7px">Explore students ${ico('arrow', 13)}</span>
                      <span style="padding:10px 18px;border-radius:9px;border:1px solid rgba(255,255,255,.28);color:#fff;font-size:13.5px;font-weight:600;display:flex;align-items:center;gap:7px">${ico('download', 13)} Upload roster</span>
                    </div>
                  </div>
                  <div style="width:288px;background:#fff;border-radius:14px;padding:18px 20px;box-shadow:0 20px 44px rgba(0,0,0,.24);position:relative">
                    <div style="display:flex;align-items:center;justify-content:space-between">
                      <span style="font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted);display:flex;align-items:center;gap:6px">${ico('chart', 12)} Verified skill momentum</span>
                      <span style="font-size:9.5px;font-weight:700;color:var(--green);display:flex;align-items:center;gap:4px"><span style="width:5px;height:5px;border-radius:50%;background:var(--green)"></span>LIVE</span>
                    </div>
                    <div style="display:flex;align-items:baseline;gap:3px;margin-top:10px">
                      <span class="mono" style="font-size:44px;font-weight:800;letter-spacing:-.045em;color:var(--ink)" data-pct>0</span>
                      <span class="mono" style="font-size:22px;font-weight:800;color:var(--ink)">%</span>
                    </div>
                    <div style="font-size:11.5px;color:var(--muted);margin-top:4px">of your roster has at least one verified skill</div>
                    <div class="bar-track" style="margin-top:12px;height:6px"><div class="bar-fill" data-pctbar style="transform:scaleX(0)"></div></div>
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-top:8px;font-size:11px;color:var(--muted)"><span><b class="mono" style="color:var(--ink)">19</b> verified</span><span><b class="mono" style="color:var(--ink)">90</b> students</span></div>
                  </div>
                </div>

                <div class="card-lite" style="margin-top:16px;display:grid;grid-template-columns:repeat(4,1fr);padding:0;overflow:hidden">
                  ${[['Skills verified', '19', 'Students with verified skills', 'checkCircle'], ['Recent engagement', '31', 'Active this month', 'trendUp'],
                     ['Assessment activity', '46', 'Projects reviewed', 'file'], ['Your community', '90', 'Students on your roster', 'users']].map((k, i) => `
                    <div style="padding:18px 22px;${i ? 'border-left:1px solid rgba(30,41,59,.08)' : ''}" data-stat="${i}">
                      <div style="display:flex;align-items:center;gap:7px;font-size:10.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)">${ico(k[3], 12)} ${k[0]}</div>
                      <div class="mono" style="font-size:32px;font-weight:800;letter-spacing:-.04em;margin-top:6px">${k[1]}</div>
                      <div style="font-size:11.5px;color:var(--muted);margin-top:2px">${k[2]}</div>
                    </div>`).join('')}
                </div>

                <div style="margin-top:18px;font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)">From roster to verified proof</div>
                <div style="font-size:23px;font-weight:700;letter-spacing:-.02em;margin-top:3px">Activation funnel</div>
                <div class="card-lite" style="margin-top:12px;padding:20px 24px">
                  ${[['Invited to roster', 90, 100], ['Account claimed', 64, 71], ['First project submitted', 41, 46], ['Skill verified', 19, 21]].map((f, i) => `
                    <div style="display:flex;align-items:center;gap:16px;margin-bottom:${i === 3 ? 0 : 15}px" data-funnel="${i}">
                      <div style="width:210px;font-size:13.5px;font-weight:600;color:var(--ink)">${f[0]}</div>
                      <div class="bar-track" style="flex:1;height:22px;border-radius:7px;background:#F0F4F2"><div data-fbar="${i}" style="height:100%;width:0;border-radius:7px;background:linear-gradient(90deg,#0B7F49,#34D399);display:flex;align-items:center;justify-content:flex-end;padding-right:9px;overflow:hidden"><span class="mono" data-fnum="${i}" style="font-size:12px;font-weight:700;color:#fff;opacity:0">${f[1]}</span></div></div>
                      <div class="mono" style="width:44px;text-align:right;font-size:12.5px;color:var(--muted)">${f[2]}%</div>
                    </div>`).join('')}
                </div>
              </div>

              <!-- 2. PLACEMENTS -->
              <div class="ps" data-ps="1" style="padding:22px 34px">
                <div style="display:flex;align-items:flex-end;justify-content:space-between">
                  <div>
                    <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Placements</div>
                    <div style="font-size:14px;color:var(--muted);margin-top:5px">Track student outcomes with context. Unknown is a valid status — not a negative result.</div>
                  </div>
                  <span class="tag ghost" style="padding:8px 14px;font-size:12.5px">${ico('download', 13)} Export CSV</span>
                </div>

                <div class="card-lite" style="margin-top:16px;padding:20px 24px">
                  <div style="font-size:10.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)">Outcomes at a glance</div>
                  <div style="font-size:26px;font-weight:700;letter-spacing:-.025em;margin-top:4px">A clearer view of what comes next.</div>
                  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-top:16px">
                    ${[['Placed', '18', 'Recorded as placed', '#0B7F49', 'checkCircle'], ['Not placed', '11', 'Known outcome, still searching', '#C98A2E', 'ban'],
                       ['Unknown', '61', 'Awaiting an outcome update', '#657186', 'clock'], ['Placement rate', '62%', 'Of students with known outcomes', '#0B7F49', 'chart']].map((o, i) => `
                      <div style="border:1px solid ${i === 3 ? '#0B7F49' : 'rgba(30,41,59,.09)'};${i === 3 ? 'box-shadow:0 0 0 2px rgba(8,122,85,.1);' : ''}border-radius:12px;padding:14px 16px;position:relative;overflow:hidden" data-place="${i}">
                        <div style="display:flex;align-items:center;gap:6px;font-size:10.5px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)">${ico(o[4], 11)} ${o[0]}</div>
                        <div class="mono" style="font-size:32px;font-weight:800;letter-spacing:-.04em;margin-top:7px;color:${i === 3 ? 'var(--green)' : 'var(--ink)'}" data-pnum="${i}">${o[1]}</div>
                        <div style="font-size:11px;color:var(--muted);margin-top:3px;line-height:1.35">${o[2]}</div>
                      </div>`).join('')}
                  </div>
                  <div style="display:flex;align-items:center;gap:14px;margin-top:16px">
                    <div style="width:150px"><div style="font-size:11px;color:var(--muted)">Outcomes recorded</div><div style="font-size:13px;font-weight:700;margin-top:2px"><span class="mono">29</span> of 90</div></div>
                    <div class="bar-track" style="flex:1;height:8px"><div class="bar-fill" data-outbar style="transform:scaleX(0)"></div></div>
                    <div style="display:flex;align-items:center;gap:7px;font-size:11.5px;color:var(--muted);background:#F6FAF7;border:1px solid rgba(8,122,85,.14);padding:7px 12px;border-radius:8px">${ico('lock', 12)} Unknown never counts as "not placed"</div>
                  </div>
                </div>

                <div class="card-lite" style="margin-top:14px;padding:0;overflow:hidden">
                  <div style="padding:16px 22px 12px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-size:10.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)">Student outcomes</div>
                      <div style="font-size:19px;font-weight:700;letter-spacing:-.02em;margin-top:2px">Placement roster</div>
                    </div>
                    <span class="tag ghost" style="font-size:11.5px">90 shown</span>
                  </div>
                  <table class="dtable" style="font-size:13px">
                    <thead><tr><th style="padding-left:22px">Student</th><th>Lifecycle</th><th>Program / year</th><th>Outcome</th><th>Organization</th><th>Role</th></tr></thead>
                    <tbody>
                      ${[['Aman Verma', 'Not registered yet', 'Incoming', 'Computer Science / 1', 'Unknown', '—', '—'],
                         ['Ajay Bhatia', 'AptoHire account claimed', 'Enrolled', 'Computer Science / 1', 'Unknown', '—', '—'],
                         ['Aarav Sharma', 'AptoHire account claimed', 'Enrolled', 'Computer Science / 2', 'Placed', 'Northwind Labs', 'Front-end intern']].map((r, i) => `
                        <tr data-prow="${i}">
                          <td style="padding-left:22px"><div style="font-weight:700">${r[0]}</div><div style="font-size:10.5px;color:var(--muted)">${r[1]}</div></td>
                          <td><span class="tag ${i ? '' : 'ghost'}" style="font-size:10.5px;padding:2px 8px">${r[2]}</span></td>
                          <td>${r[3]}</td>
                          <td>${r[4] === 'Placed' ? `<span class="tag" style="font-size:10.5px;padding:2px 8px">${ico('check', 9)} Placed</span>` : `<span class="tag ghost" style="font-size:10.5px;padding:2px 8px">Unknown</span>`}</td>
                          <td>${r[5]}</td>
                          <td>${r[6]}</td>
                        </tr>`).join('')}
                    </tbody>
                  </table>
                </div>
              </div>

              <!-- 3. SKILLS DEMAND -->
              <div class="ps" data-ps="2" style="padding:22px 34px">
                <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Skills demand</div>
                <div style="font-size:14px;color:var(--muted);margin-top:5px">Understand the skills your students can prove — and the capabilities employers are asking for.</div>

                <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:16px">
                  ${[['Skills tracked', '10'], ['Verified student-skill records', '98'], ['Open skill requirements', '99'], ['Jobs with unmatched demand', '3']].map((k, i) => `
                    <div class="card-lite" style="padding:13px 16px;display:flex;align-items:center;gap:12px" data-sd="${i}">
                      <span style="width:32px;height:32px;border-radius:9px;background:var(--mint);display:flex;align-items:center;justify-content:center;color:var(--green)">${ico(['chart', 'users', 'briefcase', 'zap'][i], 16)}</span>
                      <div><div class="mono" style="font-size:24px;font-weight:800;letter-spacing:-.03em">${k[1]}</div><div style="font-size:10.5px;color:var(--muted)">${k[0]}</div></div>
                    </div>`).join('')}
                </div>

                <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px">
                  ${[['Supply vs demand', 'Verified skills vs employer needs', '#0B7F49'], ['Unmatched demand', 'Where demand outpaces supply', '#C98A2E'], ['Curriculum gaps', 'Signals to inform learning plans', '#B4483C']].map((t, i) => `
                    <div style="border:1px solid rgba(30,41,59,.09);border-radius:11px;padding:11px 15px;background:#fff;display:flex;align-items:center;gap:11px" data-gapcard="${i}">
                      <span style="width:26px;height:26px;border-radius:8px;background:${t[2]}14;color:${t[2]};display:flex;align-items:center;justify-content:center">${ico(['checkCircle', 'zap', 'flag'][i], 14)}</span>
                      <div><div style="font-size:12.5px;font-weight:700">${t[0]}</div><div style="font-size:10.5px;color:var(--muted)">${t[1]}</div></div>
                    </div>`).join('')}
                </div>

                <div class="card-lite" style="margin-top:14px;padding:0;overflow:hidden">
                  <div style="padding:16px 22px 10px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="font-size:10.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--muted)">Verified capability</div>
                      <div style="font-size:19px;font-weight:700;letter-spacing:-.02em;margin-top:2px">Supply by skill</div>
                      <div style="font-size:11.5px;color:var(--muted);margin-top:2px">Only verified results are counted. Pending human reviews are excluded.</div>
                    </div>
                    <span class="tag ghost" style="font-size:11.5px">10 skills</span>
                  </div>
                  <table class="dtable" style="font-size:13px">
                    <thead><tr><th style="padding-left:22px">Skill</th><th>Family</th><th>Verified students</th><th>Assessed</th><th>Average score</th><th>Open jobs</th></tr></thead>
                    <tbody>
                      ${[['Node.js', 'Backend', 4, 13, '64 · Competent', 18, true],
                         ['JavaScript', 'Web development', 18, 34, '69 · Competent', 15, false],
                         ['React', 'Web development', 14, 29, '74 · Proficient', 12, false],
                         ['TypeScript', 'Web development', 11, 22, '70 · Competent', 9, false]].map((r, i) => `
                        <tr data-srow="${i}" style="${r[6] ? 'background:#FEF8EC' : ''}">
                          <td style="padding-left:22px;font-weight:700">${r[0]}${r[6] ? ' <span class="tag amber" style="font-size:9.5px;padding:1px 6px;margin-left:6px">Gap</span>' : ''}</td>
                          <td style="color:var(--muted)">${r[1]}</td>
                          <td class="mono">${r[2]}</td>
                          <td class="mono" style="color:var(--muted)">${r[3]}</td>
                          <td>${r[4]}</td>
                          <td><span class="mono" style="font-weight:700;color:${r[6] ? '#B4483C' : 'var(--ink)'}">${r[5]}</span></td>
                        </tr>`).join('')}
                    </tbody>
                  </table>
                  <div style="display:flex;align-items:center;gap:10px;padding:12px 22px;background:#FDF8F1;border-top:1px solid rgba(214,168,79,.24);font-size:12px;color:#8A5F10">
                    ${ico('zap', 14)} <b>Curriculum gap:</b> 4 students verified in Node.js against 18 open employer requirements. Next.js shows the same pattern.
                  </div>
                </div>
              </div>

            </div>
          </div>
        </div></div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        plane: q('[data-plane]'), rail: q('[data-rail]'), rail2: q('[data-rail2]'),
        screens: [...root.querySelectorAll('[data-ps]')],
        pct: q('[data-pct]'), pctbar: q('[data-pctbar]'),
        stat: [...root.querySelectorAll('[data-stat]')], fbar: [...root.querySelectorAll('[data-fbar]')], funnel: [...root.querySelectorAll('[data-funnel]')],
        place: [...root.querySelectorAll('[data-place]')], outbar: q('[data-outbar]'), prow: [...root.querySelectorAll('[data-prow]')],
        sd: [...root.querySelectorAll('[data-sd]')], gapcard: [...root.querySelectorAll('[data-gapcard]')], srow: [...root.querySelectorAll('[data-srow]')],
      };
      this.frame = (t, lt, D) => {
        const inP = S(t, 157.00, 158.3, ez.outQuart);
        put(el.plane, { o: S(t, 157.00, 157.8), ry: lerp(-19, 0, inP), rx: lerp(9, 0, inP), rz: lerp(-1.6, 0, inP), z: lerp(-140, 0, inP), s: lerp(0.9, 1, inP), y: lerp(50, 0, inP) });
        put(el.rail, { o: S(t, 157.1, 157.75), x: lerp(-16, 0, S(t, 157.1, 157.9, ez.outCubic)) });
        put(el.rail2, { o: S(t, 157.25, 157.9) });

        const s0 = 1 - S(t, 168.55, 169.25, ez.inOutCubic);
        put(el.screens[0], { o: s0, x: lerp(0, -70, S(t, 168.55, 169.3, ez.inCubic)) });
        const s1i = S(t, 168.6, 169.35, ez.outCubic), s1o = 1 - S(t, 176.60, 177.35, ez.inOutCubic);
        put(el.screens[1], { o: s1i * s1o, x: lerp(70, 0, s1i) + lerp(0, -70, s1o < 1 ? 1 - s1o : 0) });
        const s2i = S(t, 176.65, 177.45, ez.outCubic);
        put(el.screens[2], { o: s2i, x: lerp(70, 0, s2i) });

        // overview numbers 159.2-162.6
        if (el.pct) { const p = S(t, 159.20, 161.6, ez.outCubic); el.pct.textContent = Math.round(21 * p); }
        if (el.pctbar) { const p = S(t, 159.3, 161.8, ez.outCubic); el.pctbar.style.transform = `scaleX(${(p * 0.21).toFixed(4)})`; }
        el.stat.forEach((c, i) => { const p = S(t, 157.9 + i * 0.09, 158.6 + i * 0.09, ez.outCubic); put(c, { o: p, y: lerp(14, 0, p) }); });
        el.fbar.forEach((b, i) => { const p = S(t, 160.4 + i * 0.22, 161.3 + i * 0.22, ez.outCubic); b.style.width = ([90, 64, 41, 19][i] * p).toFixed(1) + '%'; });
        root.querySelectorAll('[data-fnum]').forEach((n, i) => { n.style.opacity = S(t, 160.9 + i * 0.22, 161.5 + i * 0.22).toFixed(2); });
        el.funnel.forEach((f, i) => { const p = S(t, 160.3 + i * 0.22, 160.9 + i * 0.22, ez.outCubic); put(f, { o: 0.25 + 0.75 * p }); });

        // placements 168.8-176.4
        el.place.forEach((c, i) => { const p = S(t, 168.90 + i * 0.14, 169.7 + i * 0.14, ez.outCubic); put(c, { o: p, y: lerp(18, 0, p), s: lerp(0.97, 1, p) }); });
        if (el.outbar) { const p = S(t, 170.2, 172.2, ez.outCubic); el.outbar.style.transform = `scaleX(${(p * 29 / 90).toFixed(4)})`; }
        el.prow.forEach((r, i) => { const p = S(t, 171.2 + i * 0.16, 171.9 + i * 0.16, ez.outCubic); put(r, { o: 0.2 + 0.8 * p }); });

        // skills 176.9-186.4
        el.sd.forEach((c, i) => { const p = S(t, 176.95 + i * 0.09, 177.7 + i * 0.09, ez.outCubic); put(c, { o: p, y: lerp(16, 0, p) }); });
        el.gapcard.forEach((c, i) => { const p = S(t, 177.5 + i * 0.12, 178.2 + i * 0.12, ez.outCubic); put(c, { o: p, y: lerp(12, 0, p) }); });
        el.srow.forEach((r, i) => { const p = S(t, 178.2 + i * 0.14, 178.9 + i * 0.14, ez.outCubic); put(r, { o: 0.2 + 0.8 * p }); });
      };
    }
  });

  /* =======================================================================
     SCENE 07 — ADMIN CONSOLE  (188.304 -> 217.732)
     ======================================================================= */
  SCENES.push({
    id: 'scene_07', portal: 'Admin console · governance',
    build(root) {
      root.classList.add('bg-navy');
      root.innerHTML = `
        <div style="position:absolute;inset:0;background:radial-gradient(1000px 640px at 26% 22%, rgba(8,122,85,.22), transparent 68%)"></div>

        ${toprail('07', 'Admin console · governance', 'aptohire-admin.vercel.app', 'MFA VERIFIED')
          .replace('background:rgba(255,255,255,.7)', 'background:rgba(23,32,51,.55)')
          .replace(/color:var\(--muted\)/g, 'color:#94A3B8')}

        <div class="iso-rig" style="top:96px"><div class="iso-plane" data-plane style="width:1700px;height:840px">
          <div class="portal-window" style="width:1700px;height:840px;grid-template-columns:236px 1fr" data-pw>
            ${sidebar({
              role: 'admin', tint: 'admin-tint', active: 'Dashboard',
              nav: [{ label: 'Dashboard', icon: 'grid' }, { label: 'Approvals', icon: 'checkCircle', badge: '4' },
                { label: 'Reviews', icon: 'target', badge: '5' }, { label: 'Tickets & appeals', icon: 'flag', badge: '3' },
                { label: 'Audit log', icon: 'book' }],
              footer: `<div style="margin-top:18px;padding:12px 14px;border-radius:10px;background:var(--green);color:#fff">
                <div style="display:flex;align-items:center;gap:7px;font-size:11.5px;font-weight:700">${ico('shield', 13)} Protected workspace</div>
                <div style="font-size:10.5px;color:rgba(255,255,255,.72);margin-top:3px">Role + MFA checks active</div></div>`
            })}
            <div class="portal-main">

              <!-- 1. DASHBOARD -->
              <div class="ps" data-ps="0" style="padding:20px 30px">
                <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px">
                  <div style="display:flex;align-items:center;gap:8px;font-size:10.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:var(--green)"><span style="width:6px;height:6px;border-radius:50%;background:var(--green)"></span>AptoHire admin workspace</div>
                  <span class="tag ghost" style="font-size:11.5px">${ico('refresh', 12)} Refresh data</span>
                </div>
                <div style="font-size:34px;font-weight:800;letter-spacing:-.035em">Dashboard</div>
                <div style="font-size:13.5px;color:var(--muted);margin-top:4px">A calm overview of the queues, decisions, and safeguards that need your attention.</div>

                <div class="hero-band green" style="margin-top:16px;padding:24px 28px;background:linear-gradient(110deg,#084C35 0%,#087A55 60%,#0B9266 100%)">
                  <div style="position:absolute;right:40px;top:50%;transform:translateY(-50%);width:180px;height:180px;border-radius:50%;border:1px solid rgba(255,255,255,.16);display:flex;align-items:center;justify-content:center">
                    <div style="width:110px;height:110px;border-radius:50%;border:1px solid rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;background:rgba(255,255,255,.07);color:#fff">${ico('grid', 34)}</div>
                  </div>
                  <div style="position:relative">
                    <div style="font-size:11px;font-weight:700;letter-spacing:.14em;text-transform:uppercase;color:rgba(255,255,255,.6);margin-bottom:12px">Admin workspace · sample mode</div>
                    <div style="font-size:38px;font-weight:800;letter-spacing:-.035em;line-height:1.12">Make every review count.</div>
                    <div style="font-size:14.5px;color:rgba(255,255,255,.8);margin-top:10px;max-width:560px;line-height:1.5">See the work that needs a human decision, move it into the right queue, and keep safety controls in view.</div>
                    <div style="display:flex;align-items:center;gap:16px;margin-top:18px">
                      <span style="padding:10px 18px;border-radius:9px;background:#fff;color:var(--green);font-size:13.5px;font-weight:700;display:flex;align-items:center;gap:7px">Go to human reviews ${ico('arrow', 13)}</span>
                      <span style="display:flex;align-items:center;gap:6px;font-size:12px;color:rgba(255,255,255,.7)">${ico('checkCircle', 12)} Authenticated · Admin role verified · MFA complete</span>
                    </div>
                  </div>
                </div>

                <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:14px">
                  ${[['Approvals', '4', 'Applications awaiting a decision', 'checkCircle', '#0B7F49'], ['Human reviews', '5', '2 overdue blind reviews', 'target', '#C98A2E'],
                     ['Appeals', '3', 'Appeals in the review workflow', 'flag', '#657186'], ['Run issues', '5', 'Failed or timed-out agent runs', 'zap', '#C2544A']].map((k, i) => `
                    <div class="card-lite" style="padding:14px 17px;position:relative;overflow:hidden" data-akpi="${i}">
                      <div style="display:flex;align-items:center;gap:7px;font-size:10.5px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)">${ico(k[3], 12, k[4])} ${k[0]}</div>
                      <div class="mono" style="font-size:32px;font-weight:800;letter-spacing:-.04em;margin-top:7px">${k[1]}</div>
                      <div style="font-size:11px;color:var(--muted);margin-top:2px;line-height:1.35">${k[2]}</div>
                    </div>`).join('')}
                </div>

                <div style="display:grid;grid-template-columns:1.45fr 1fr;gap:14px;margin-top:14px">
                  <div class="card-lite" style="padding:16px 20px">
                    <div style="display:flex;align-items:center;justify-content:space-between">
                      <div>
                        <div style="font-size:10.5px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)">Queue overview</div>
                        <div style="font-size:18px;font-weight:700;letter-spacing:-.02em;margin-top:2px">Work that needs attention</div>
                      </div>
                      <span class="tag ghost" style="font-size:11px">All</span>
                    </div>
                    ${[['Approvals', 'Applications awaiting a decision', 4, '#0B7F49'], ['Human reviews', '2 overdue blind reviews', 5, '#C98A2E'],
                       ['Appeals', 'Appeals in the review workflow', 3, '#657186'], ['Run issues', 'Failed or timed-out agent runs', 5, '#C2544A']].map((q, i) => `
                      <div style="display:flex;align-items:center;gap:12px;padding:10px 0;border-top:1px solid rgba(30,41,59,.07)" data-qrow="${i}">
                        <span style="width:28px;height:28px;border-radius:8px;background:${q[3]}14;color:${q[3]};display:flex;align-items:center;justify-content:center">${ico(['checkCircle', 'target', 'flag', 'zap'][i], 14)}</span>
                        <div style="flex:1;min-width:0">
                          <div style="font-size:13px;font-weight:700">${q[0]}</div>
                          <div style="height:4px;border-radius:4px;background:#F0F4F2;margin-top:5px;overflow:hidden"><div data-qbar="${i}" style="height:100%;width:0;background:${q[3]};border-radius:4px"></div></div>
                        </div>
                        <span class="mono" style="font-size:15px;font-weight:800">${q[2]}</span>
                      </div>`).join('')}
                  </div>
                  <div class="card-lite" style="padding:16px 20px">
                    <div style="display:flex;align-items:center;justify-content:space-between">
                      <div style="font-size:10.5px;font-weight:700;letter-spacing:.11em;text-transform:uppercase;color:var(--muted)">System health</div>
                      <span style="color:#B6C2CC">${ico('gauge', 14)}</span>
                    </div>
                    <div style="font-size:18px;font-weight:700;letter-spacing:-.02em;margin-top:2px">Controls at a glance</div>
                    ${[['AI processing', 'Current workspace policy', 'Available'], ['Agent mode', 'Controls how new runs are handled', 'mock'], ['Review settings', 'Borderline band 40–60', 'Open']].map((r, i) => `
                      <div style="display:flex;align-items:center;justify-content:space-between;padding:11px 0;border-top:1px solid rgba(30,41,59,.07)" data-hrow="${i}">
                        <div><div style="font-size:12.5px;font-weight:700">${r[0]}</div><div style="font-size:10.5px;color:var(--muted);margin-top:1px">${r[1]}</div></div>
                        <span class="tag ghost" style="font-size:10.5px;padding:3px 9px">${r[2]}</span>
                      </div>`).join('')}
                  </div>
                </div>
              </div>

              <!-- 2. APPROVALS -->
              <div class="ps" data-ps="1" style="padding:22px 32px">
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div>
                    <div style="font-size:32px;font-weight:800;letter-spacing:-.035em">Approvals</div>
                    <div style="font-size:13.5px;color:var(--muted);margin-top:4px">Review university and organization applications before access is granted.</div>
                  </div>
                  <span class="tag ghost" style="padding:8px 14px;font-size:12.5px">${ico('refresh', 13)} Refresh</span>
                </div>
                <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-top:14px">
                  ${[['Pending applications', '4'], ['Approved', '2'], ['Rejected', '1'], ['Queue data', 'Sample']].map((k, i) => `
                    <div class="card-lite" style="padding:13px 17px" data-apk="${i}">
                      <div style="font-size:10.5px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)">${k[0]}</div>
                      <div class="mono" style="font-size:26px;font-weight:800;letter-spacing:-.035em;margin-top:4px">${k[1]}</div>
                    </div>`).join('')}
                </div>
                <div style="display:grid;grid-template-columns:1fr 1.45fr;gap:14px;margin-top:14px">
                  <div>
                    <div style="display:flex;gap:8px;margin-bottom:10px"><span class="tag" style="font-size:11.5px;padding:4px 11px">Universities</span><span class="tag ghost" style="font-size:11.5px;padding:4px 11px">Organizations</span></div>
                    ${[['Uni C', 'AH-7K2Q9F', 'Tier 3 · Jaipur, Rajasthan', '16h ago · 6 waiting', true],
                       ['Riverbend College', 'AH-9P3L1C', 'Tier 2 · Ajmer, Rajasthan', '1d ago', false]].map((a, i) => `
                      <div class="cand-card ${i === 0 ? 'sel' : ''}" style="margin-bottom:10px;padding:14px 16px" data-appr="${i}">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between">
                          <div>
                            <div style="font-size:15.5px;font-weight:700">${a[0]}</div>
                            <div style="font-family:var(--mono);font-size:11.5px;color:var(--muted);margin-top:2px">${a[1]}</div>
                            <div style="font-size:12px;color:var(--muted);margin-top:5px">${a[2]}</div>
                            <div style="font-size:11px;color:#B6C2CC;margin-top:4px">${a[3]}</div>
                          </div>
                          <span class="tag amber" style="font-size:10.5px;padding:2px 8px">pending</span>
                        </div>
                      </div>`).join('')}
                  </div>
                  <div class="card-lite" style="padding:16px 20px">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between">
                      <div>
                        <div style="font-family:var(--mono);font-size:11px;color:var(--muted)">AH-7K2Q9F</div>
                        <div style="font-size:24px;font-weight:800;letter-spacing:-.03em;margin-top:2px">Uni C</div>
                        <div style="font-size:12px;color:var(--muted);margin-top:2px">Tier 3 · Jaipur, Rajasthan</div>
                      </div>
                      <span class="tag amber" style="font-size:11px;padding:3px 10px">pending</span>
                    </div>
                    <div style="height:1px;background:rgba(30,41,59,.08);margin:13px 0"></div>
                    <div style="font-size:13.5px;font-weight:700;margin-bottom:9px">Application</div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:11px 18px;font-size:12px">
                      ${[['Contact', 'Mira Shah, Registrar'], ['Email', 'mira@unic.example'], ['Phone', '+91 141 555 0101'], ['Submitted', '29 Oct 2026'],
                         ['Campus city', 'Jaipur, Rajasthan'], ['Accreditation', 'Sample regional accreditation'], ['Institution type', 'Public'], ['Roster waiting', '6']].map(r => `
                        <div><div style="font-size:10px;font-weight:700;letter-spacing:.07em;text-transform:uppercase;color:var(--muted)">${r[0]}</div><div style="font-weight:600;margin-top:2px;color:${r[0] === 'Email' ? 'var(--green)' : 'var(--ink)'}">${r[1]}</div></div>`).join('')}
                    </div>
                    <div style="height:1px;background:rgba(30,41,59,.08);margin:13px 0"></div>
                    <div style="font-size:12.5px;font-weight:700;margin-bottom:8px">Checks to consider</div>
                    <div style="display:flex;flex-direction:column;gap:7px">
                      ${['Institutional registration verified', 'Accreditation record on file', 'Roster provenance review'].map((c, i) => `
                        <div style="display:flex;align-items:center;gap:8px;font-size:12px;color:var(--muted)" data-check="${i}">${ico('checkCircle', 13, '#0B7F49')} ${c}</div>`).join('')}
                    </div>
                    <div style="display:flex;gap:10px;margin-top:15px">
                      <span style="flex:1;padding:10px;border-radius:8px;background:var(--green);color:#fff;font-size:13px;font-weight:700;text-align:center">Approve</span>
                      <span style="padding:10px 18px;border-radius:8px;border:1px solid rgba(30,41,59,.14);font-size:13px;font-weight:600;color:var(--muted)">Reject</span>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 3. REVIEWS -->
              <div class="ps" data-ps="2" style="padding:20px 30px">
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div>
                    <div style="font-size:32px;font-weight:800;letter-spacing:-.035em">Reviews</div>
                    <div style="font-size:13.5px;color:var(--muted);margin-top:4px">Blind review of borderline results. Results stay private until a human decides.</div>
                  </div>
                  <div style="display:flex;gap:7px"><span class="tag" style="font-size:11.5px;padding:4px 11px">Pending</span><span class="tag ghost" style="font-size:11.5px;padding:4px 11px">Decided</span></div>
                </div>
                <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:11px;margin-top:13px">
                  ${[['Waiting for review', '5'], ['Overdue', '2'], ['Borderline range', '40–60'], ['Pass mark', '>50']].map((k, i) => `
                    <div class="card-lite" style="padding:12px 16px" data-rkpi="${i}">
                      <div style="font-size:10.5px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted)">${k[0]}</div>
                      <div class="mono" style="font-size:26px;font-weight:800;letter-spacing:-.035em;margin-top:4px">${k[1]}</div>
                    </div>`).join('')}
                </div>
                <div style="display:grid;grid-template-columns:1fr 1.5fr;gap:14px;margin-top:13px">
                  <div style="display:flex;flex-direction:column;gap:8px">
                    ${[['SUB-J9K8', 'Inventory workflow redesign', 'Product management · 56 / 100', 'overdue', false],
                       ['SUB-A1B2', 'Interactive product catalogue', 'React · 52 / 100', 'overdue', true],
                       ['SUB-E5F6', 'Appointment booking API', 'Backend · 59 / 100', 'under review', false],
                       ['SUB-C3D4', 'Retail demand forecast', 'Data analysis · 48 / 100', 'under review', false]].map((r, i) => `
                      <div class="cand-card ${r[4] ? 'sel' : ''}" style="padding:12px 14px" data-rrow="${i}">
                        <div style="display:flex;align-items:flex-start;justify-content:space-between">
                          <div style="font-family:var(--mono);font-size:11.5px;font-weight:700">${r[0]}</div>
                          <span class="tag ${r[3] === 'overdue' ? 'amber' : 'ghost'}" style="font-size:9.5px;padding:1px 7px">${r[3]}</span>
                        </div>
                        <div style="font-size:12.5px;font-weight:600;margin-top:6px">${r[1]}</div>
                        <div style="font-size:11px;color:var(--muted);margin-top:3px">${r[2]}</div>
                      </div>`).join('')}
                  </div>
                  <div class="card-lite" style="padding:16px 20px">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between">
                      <div>
                        <div style="font-size:19px;font-weight:800;letter-spacing:-.025em">Interactive product catalogue</div>
                        <div style="font-family:var(--mono);font-size:11px;color:var(--muted);margin-top:3px">Submission SUB-A1B2</div>
                      </div>
                      <span class="tag amber" style="font-size:10.5px;padding:2px 8px">${ico('clock', 10)} overdue</span>
                    </div>
                    <div style="margin-top:11px;padding:9px 12px;border-radius:8px;background:#F6FAF7;border:1px solid rgba(8,122,85,.14);font-size:11.5px;color:#3F5A4E">${ico('lock', 12)} Reviews are blind to the student's identity to reduce bias.</div>
                    <div style="display:grid;grid-template-columns:1fr 1fr;gap:11px;margin-top:11px">
                      <div style="border:1px solid rgba(30,41,59,.09);border-radius:10px;padding:12px 14px">
                        <div style="font-size:10px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin-bottom:8px">AI assessment</div>
                        <div style="display:flex;align-items:center;gap:12px">
                          <div style="width:58px;height:58px;border-radius:50%;background:var(--green);color:#fff;display:flex;flex-direction:column;align-items:center;justify-content:center">
                            <span class="mono" style="font-size:21px;font-weight:800;line-height:1" data-ainum>0</span>
                            <span style="font-size:7.5px;letter-spacing:.08em;opacity:.8">/ 100</span>
                          </div>
                          <div>
                            <span class="tag amber" style="font-size:10px;padding:1px 7px">Under review</span>
                            <div style="font-size:11.5px;color:var(--muted);margin-top:6px;display:flex;align-items:center;gap:5px">${ico('checkCircle', 11, '#0B7F49')} Medium confidence</div>
                          </div>
                        </div>
                        <div style="font-size:11.5px;color:var(--muted);margin-top:10px;line-height:1.45">A compact storefront with a clear product browsing flow and responsive layout.</div>
                        <div style="display:flex;align-items:center;gap:8px;margin-top:9px;font-size:11px;font-weight:600"><span>React</span><div class="bar-track" style="flex:1;height:5px"><div data-aibar style="height:100%;width:0;border-radius:5px;background:var(--green)"></div></div><span class="mono">52 / 100</span></div>
                      </div>
                      <div style="border:1px solid rgba(30,41,59,.09);border-radius:10px;padding:12px 14px">
                        <div style="font-size:10px;font-weight:700;letter-spacing:.09em;text-transform:uppercase;color:var(--muted);margin-bottom:8px">Evidence</div>
                        <div style="font-size:11.5px;font-weight:600">Interactive product catalogue</div>
                        <div style="font-size:10.5px;color:var(--muted);margin-top:2px">Submitted 26 Oct 2026 · Sample evidence excerpt</div>
                        <div style="margin-top:8px;font-family:var(--mono);font-size:10px;line-height:1.65;background:#FDF8EC;border:1px solid rgba(214,168,79,.28);border-radius:7px;padding:8px 10px;color:#5A4718">
                          <div style="color:#9A6B16">src/cart.tsx · lines 14–38</div>
                          <div>const addItem = (item) =&gt; {</div>
                          <div>&nbsp;&nbsp;setItems((current) =&gt; [...current, item]);</div>
                          <div>};</div>
                        </div>
                        <div style="font-size:10.5px;color:var(--muted);margin-top:8px;line-height:1.4">The interface covers the primary path. Component boundaries and loading states need a closer human review.</div>
                      </div>
                    </div>
                    <div style="display:flex;align-items:center;justify-content:space-between;margin-top:12px;padding-top:11px;border-top:1px solid rgba(30,41,59,.08)">
                      <span style="font-size:11.5px;color:var(--muted)">New score <b class="mono" style="color:var(--ink)">52 → 55</b> · Competent · Verified. It becomes visible to organizations only after you confirm.</span>
                      <div style="display:flex;gap:8px;flex:none">
                        <span class="tag ghost" style="font-size:11.5px;padding:5px 12px">${ico('gauge', 11)} Adjust score</span>
                        <span style="padding:6px 14px;border-radius:7px;background:var(--green);color:#fff;font-size:11.5px;font-weight:700" data-confirm>Confirm score</span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <!-- 4. AUDIT LOG -->
              <div class="ps" data-ps="3" style="padding:22px 32px">
                <div style="display:flex;align-items:center;justify-content:space-between">
                  <div>
                    <div style="font-size:32px;font-weight:800;letter-spacing:-.035em">Audit log</div>
                    <div style="font-size:13.5px;color:var(--muted);margin-top:4px">Append-only record of consequential actions and sensitive reads.</div>
                  </div>
                  <span class="tag ghost" style="padding:8px 14px;font-size:12.5px">${ico('download', 13)} Export CSV</span>
                </div>
                <div style="display:flex;align-items:center;gap:10px;margin-top:14px;padding:11px 16px;border-radius:9px;background:#F6FAF7;border:1px solid rgba(8,122,85,.16);font-size:12.5px;color:#3F5A4E">
                  ${ico('lock', 14)} This log is read-only. No entry can be edited or deleted. Sample entries are fictional.
                </div>
                <div class="card-lite" style="margin-top:13px;padding:0;overflow:hidden">
                  <table class="dtable" style="font-size:12.5px">
                    <thead><tr><th style="padding-left:20px">Time</th><th>Actor</th><th>Action</th><th>Target</th><th>Details</th></tr></thead>
                    <tbody>
                      ${[['30 Oct 2026, 7:51 am', 'Admin1', 'Review decision', 'audit · SUB-HIST-01', 'Sample event: score confirmed'],
                         ['29 Oct 2026, 6:51 pm', 'Reviewer 2', 'Ticket decision', 'ticket · TKT-101', 'Sample event: appeal upheld'],
                         ['29 Oct 2026, 4:51 am', 'Admin1', 'Configuration change', 'app_config · PASS_MARK', 'Sample event: policy updated'],
                         ['28 Oct 2026, 10:51 am', 'Admin1', 'Approval', 'university · AH-1B2A3C', 'Sample event: approved'],
                         ['27 Oct 2026, 9:12 am', 'Reviewer 1', 'Review decision', 'audit · SUB-A1B2', 'Sample event: score confirmed']].map((r, i) => `
                        <tr data-arow="${i}">
                          <td style="padding-left:20px;font-family:var(--mono);font-size:11px;color:var(--muted)">${r[0]}</td>
                          <td><div style="font-weight:700;font-size:12px">${r[1]}</div><div style="font-size:10px;color:var(--muted)">admin</div></td>
                          <td><span class="tag ghost" style="font-size:10.5px;padding:2px 8px">${r[2]}</span></td>
                          <td style="font-family:var(--mono);font-size:11px">${r[3]}</td>
                          <td style="color:var(--muted)">${r[4]}</td>
                        </tr>`).join('')}
                    </tbody>
                  </table>
                </div>
                <div style="margin-top:12px;display:flex;align-items:center;gap:9px;font-size:11.5px;color:var(--muted)">${ico('checkCircle', 13, '#0B7F49')} Showing 5 filtered events · newest first · chain verified</div>
              </div>

            </div>
          </div>
        </div></div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        plane: q('[data-plane]'), rail: q('[data-rail]'), rail2: q('[data-rail2]'),
        screens: [...root.querySelectorAll('[data-ps]')],
        akpi: [...root.querySelectorAll('[data-akpi]')], qrow: [...root.querySelectorAll('[data-qrow]')],
        qbar: [...root.querySelectorAll('[data-qbar]')], hrow: [...root.querySelectorAll('[data-hrow]')],
        apk: [...root.querySelectorAll('[data-apk]')], appr: [...root.querySelectorAll('[data-appr]')], check: [...root.querySelectorAll('[data-check]')],
        rkpi: [...root.querySelectorAll('[data-rkpi]')], rrow: [...root.querySelectorAll('[data-rrow]')],
        ainum: q('[data-ainum]'), aibar: q('[data-aibar]'), confirm: q('[data-confirm]'), arow: [...root.querySelectorAll('[data-arow]')],
      };
      this.frame = (t, lt, D) => {
        const inP = S(t, 188.30, 189.6, ez.outQuart);
        put(el.plane, { o: S(t, 188.30, 189.1), ry: lerp(-19, 0, inP), rx: lerp(9, 0, inP), rz: lerp(-1.6, 0, inP), z: lerp(-140, 0, inP), s: lerp(0.9, 1, inP), y: lerp(50, 0, inP) });
        put(el.rail, { o: S(t, 188.4, 189.05), x: lerp(-16, 0, S(t, 188.4, 189.2, ez.outCubic)) });
        put(el.rail2, { o: S(t, 188.55, 189.2) });

        const s0 = 1 - S(t, 193.35, 194.05, ez.inOutCubic);
        put(el.screens[0], { o: s0, x: lerp(0, -70, S(t, 193.35, 194.1, ez.inCubic)) });
        const s1i = S(t, 193.40, 194.15, ez.outCubic), s1o = 1 - S(t, 197.60, 198.35, ez.inOutCubic);
        put(el.screens[1], { o: s1i * s1o, x: lerp(70, 0, s1i) + lerp(0, -70, s1o < 1 ? 1 - s1o : 0) });
        const s2i = S(t, 197.65, 198.45, ez.outCubic), s2o = 1 - S(t, 212.30, 213.05, ez.inOutCubic);
        put(el.screens[2], { o: s2i * s2o, x: lerp(70, 0, s2i) + lerp(0, -70, s2o < 1 ? 1 - s2o : 0) });
        const s3i = S(t, 212.35, 213.15, ez.outCubic);
        put(el.screens[3], { o: s3i, x: lerp(70, 0, s3i) });

        el.akpi.forEach((c, i) => { const p = S(t, 189.2 + i * 0.09, 189.95 + i * 0.09, ez.outCubic); put(c, { o: p, y: lerp(16, 0, p) }); });
        el.qrow.forEach((r, i) => { const p = S(t, 190.0 + i * 0.12, 190.7 + i * 0.12, ez.outCubic); put(r, { o: 0.25 + 0.75 * p }); });
        el.qbar.forEach((b, i) => { const p = S(t, 190.0 + i * 0.12, 191.1 + i * 0.12, ez.outCubic); b.style.width = ([4, 5, 3, 5][i] / 5 * 100 * p).toFixed(1) + '%'; });
        el.hrow.forEach((r, i) => { const p = S(t, 190.5 + i * 0.12, 191.2 + i * 0.12, ez.outCubic); put(r, { o: 0.25 + 0.75 * p }); });

        el.apk.forEach((c, i) => { const p = S(t, 194.1 + i * 0.09, 194.8 + i * 0.09, ez.outCubic); put(c, { o: p, y: lerp(14, 0, p) }); });
        el.appr.forEach((c, i) => { const p = S(t, 194.5 + i * 0.16, 195.3 + i * 0.16, ez.outCubic); put(c, { o: p, x: lerp(24, 0, p) }); });
        el.check.forEach((c, i) => { const p = S(t, 195.4 + i * 0.3, 196.0 + i * 0.3, ez.outCubic); put(c, { o: 0.15 + 0.85 * p, x: lerp(-10, 0, p) }); });

        el.rkpi.forEach((c, i) => { const p = S(t, 198.3 + i * 0.08, 199.0 + i * 0.08, ez.outCubic); put(c, { o: p, y: lerp(14, 0, p) }); });
        el.rrow.forEach((c, i) => { const p = S(t, 198.6 + i * 0.12, 199.4 + i * 0.12, ez.outCubic); put(c, { o: p, x: lerp(22, 0, p) }); });
        if (el.ainum) { const p = S(t, 199.9, 201.6, ez.outCubic); el.ainum.textContent = Math.round(52 * p); }
        if (el.aibar) { const p = S(t, 200.0, 201.8, ez.outCubic); el.aibar.style.width = (52 * p).toFixed(1) + '%'; }
        if (el.confirm) {
          const p = S(t, 212.0, 212.6, ez.outCubic);
          el.confirm.style.boxShadow = p > 0.05 ? `0 0 0 ${(4 * p).toFixed(1)}px rgba(214,168,79,${(0.35 * p).toFixed(2)})` : 'none';
        }
        el.arow.forEach((r, i) => { const p = S(t, 212.7 + i * 0.16, 213.4 + i * 0.16, ez.outCubic); put(r, { o: 0.15 + 0.85 * p, x: lerp(-14, 0, p) }); });
      };
    }
  });
})();
