/* =========================================================================
   AptoHire Film — Scenes 1-4
   ========================================================================= */
(function () {
  'use strict';
  const { ez, S, lerp, clamp, put, enter, exit, inout, stagger, wordsHTML, applyWords, trim, ico } = AH;
  const SCENES = window.SCENES = [];

  /* ---------- shared: portal chrome ---------- */
  function sidebar(o) {
    const items = o.nav.map(n => `
      <div class="nav-item ${n.label === o.active ? 'active' : ''}">
        <span style="display:flex;align-items:center;gap:10px">${ico(n.icon, 18)}${n.label}</span>
        ${n.badge ? `<span class="nav-badge">${n.badge}</span>` : ''}
      </div>`).join('');
    return `
    <div class="portal-sidebar ${o.tint || ''}">
      <div class="brand-lockup">
        <img class="brand-logo" src="assets/lockup_dark.webp" alt="AptoHire">
        <span class="role-pill">${o.role}</span>
      </div>
      ${items}
      ${o.footer ? `<div style="margin-top:auto">${o.footer}</div>` : ''}
    </div>`;
  }

  /* =======================================================================
     SCENE 01 — THE HOOK  (0.000 -> 26.541)
     ======================================================================= */
  SCENES.push({
    id: 'scene_01', portal: 'AptoHire',
    build(root) {
      root.classList.add('bg-black');
      root.innerHTML = `
        <div class="broll" data-plate="a" style="opacity:0"><img src="assets/broll_student_cold.webp" alt=""></div>
        <div class="broll" data-plate="b" style="opacity:0"><img src="assets/broll_recruiter.webp" alt=""></div>
        <div class="broll-veil"></div>

        <div class="st-a" style="position:absolute;left:152px;bottom:196px;z-index:8;max-width:1240px;opacity:0">
          <div class="micro c-gold" data-eyebrow style="margin-bottom:26px;opacity:0">Every year · millions of graduates</div>
          <div class="display-l" style="color:#fff;text-shadow:0 8px 46px rgba(0,0,0,.8)">
            <div data-line="0" style="opacity:.42">${wordsHTML('Imagine spending years learning,')}</div>
            <div data-line="1" style="opacity:.42">${wordsHTML('building projects, earning certificates,')}</div>
            <div data-line="2" style="opacity:.42">${wordsHTML('and developing your skills,')}</div>
          </div>
          <div class="display-m" style="color:#7FE6BE;margin-top:34px;text-shadow:0 8px 46px rgba(0,0,0,.85)">
            <div data-line="3">${wordsHTML('only to be rejected because your resume')}</div>
            <div data-line="4">${wordsHTML('does not tell the whole story.')}</div>
          </div>
        </div>

        <div class="st-b" style="position:absolute;left:152px;bottom:196px;z-index:8;max-width:1180px;opacity:0">
          <div class="micro c-gold" data-eyebrow style="margin-bottom:26px;opacity:0">The other side of the desk</div>
          <div class="display-l" style="color:#fff;text-shadow:0 8px 46px rgba(0,0,0,.85)">
            <div data-line="0">${wordsHTML('Now imagine being a recruiter.')}</div>
          </div>
          <div class="display-m" style="color:#E8EDF3;margin-top:30px;opacity:.92">
            <div data-line="1">${wordsHTML('Hundreds of applications. Endless resumes.')}</div>
            <div data-line="2" style="margin-top:12px">${wordsHTML('And one difficult question —')}</div>
          </div>
          <div class="display-m c-gold" style="margin-top:16px">
            <div data-line="3">${wordsHTML('who can actually do the job?')}</div>
          </div>
        </div>

        <div class="st-c" style="position:absolute;inset:0;z-index:9;display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;padding:0 170px;opacity:0">
          <div class="micro c-gold" style="margin-bottom:30px;opacity:.9">The real problem</div>
          <div class="display-l" style="color:#F4F7F5;max-width:1500px;text-shadow:0 10px 60px rgba(0,0,0,.9)">
            <span data-line="0">${wordsHTML('The problem is not always a lack of talent.')}</span>
          </div>
          <div class="display-l" style="margin-top:40px;color:#fff">
            <span data-line="1" class="gold-rule" style="--rule-w:100%;color:#F2C879">${wordsHTML('Sometimes, it is a lack of visibility.')}</span>
          </div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        pa: q('[data-plate="a"]'), pb: q('[data-plate="b"]'),
        ia: q('[data-plate="a"] img'), ib: q('[data-plate="b"] img'),
        stA: q('.st-a'), stB: q('.st-b'), stC: q('.st-c'),
        eyA: q('.st-a [data-eyebrow]'), eyB: q('.st-b [data-eyebrow]'),
        rule: q('.st-c .gold-rule'),
      };
      // word groups must be scoped per statement (all three reuse data-line indices)
      const LA = n => el.stA.querySelectorAll(`[data-line="${n}"] .kw`);
      const LB = n => el.stB.querySelectorAll(`[data-line="${n}"] .kw`);
      const LC = n => el.stC.querySelectorAll(`[data-line="${n}"] .kw`);

      this.frame = (t, lt, D) => {
        // ---- B-roll plate A: 0.15 -> 10.9 (slow push in) ----
        const aIn = S(t, 0.10, 1.5, ez.outCubic);
        const aOut = 1 - S(t, 10.15, 11.0, ez.inOutCubic);
        put(el.pa, { o: aIn * aOut });
        const pushA = lerp(1.085, 1.0, S(t, 0.0, 11.2, ez.linear));
        put(el.ia, { s: pushA, x: lerp(0, -18, S(t, 0, 11.2, ez.linear)) });

        // ---- plate B: 10.15 -> 19.4 ----
        const bIn = S(t, 10.15, 11.15, ez.inOutCubic);
        const bOut = 1 - S(t, 19.05, 19.95, ez.inOutCubic);
        put(el.pb, { o: bIn * bOut });
        put(el.ib, { s: lerp(1.09, 1.005, S(t, 10.15, 19.9, ez.linear)), x: lerp(14, -8, S(t, 10.15, 19.9, ez.linear)) });

        // ---- statement A ----
        put(el.stA, { o: S(t, 0.45, 0.9) * (1 - S(t, 9.55, 10.15, ez.inCubic)) });
        put(el.eyA, { o: S(t, 0.30, 0.85), x: lerp(-14, 0, S(t, 0.30, 0.9, ez.outCubic)) });
        applyWords(LA(0), stagger(t, 0.60, 0.085, 4, { y: 34, dur: 0.55 }));
        applyWords(LA(1), stagger(t, 3.04, 0.075, 4, { y: 34, dur: 0.55 }));
        applyWords(LA(2), stagger(t, 5.82, 0.085, 4, { y: 34, dur: 0.55 }));
        applyWords(LA(3), stagger(t, 8.26, 0.048, 8, { y: 30, dur: 0.5 }));
        applyWords(LA(4), stagger(t, 9.18, 0.055, 6, { y: 30, dur: 0.5 }));
        // each spoken line is bright while active, then settles back
        const lineOn = t0s => S(t, t0s, t0s + 0.35, ez.outCubic);
        const settle = (tLive, tNext) => (tNext ? lerp(1, 0.30, S(t, tNext - 0.15, tNext + 0.55, ez.inOutCubic)) : 1);
        [[0, 0.60, 3.04], [1, 3.04, 5.82], [2, 5.82, 8.26]].forEach(([i, tLive, tNext]) => {
          const d = el.stA.querySelector(`[data-line="${i}"]`);
          if (d) d.style.opacity = (lineOn(tLive) * settle(tLive, tNext)).toFixed(3);
        });

        // ---- statement B ----
        put(el.stB, { o: S(t, 10.20, 10.75) * (1 - S(t, 19.20, 19.95, ez.inCubic)) });
        put(el.eyB, { o: S(t, 10.20, 10.8), x: lerp(-14, 0, S(t, 10.2, 10.85, ez.outCubic)) });
        applyWords(LB(0), stagger(t, 10.84, 0.07, 5, { y: 34 }));
        applyWords(LB(1), stagger(t, 12.90, 0.055, 6, { y: 28 }));
        applyWords(LB(2), stagger(t, 16.16, 0.055, 5, { y: 28 }));
        applyWords(LB(3), stagger(t, 17.10, 0.07, 6, { y: 28 }));

        // ---- statement C (the thesis) ----
        put(el.stC, { o: S(t, 19.55, 20.1) });
        applyWords(LC(0), stagger(t, 19.98, 0.055, 9, { y: 36, dur: 0.5 }));
        applyWords(LC(1), stagger(t, 22.30, 0.055, 8, { y: 36, dur: 0.5 }));
        if (el.rule) {
          const rw = S(t, 23.55, 24.65, ez.inOutCubic);
          el.rule.style.setProperty('--rule-w', (rw * 100).toFixed(1) + '%');
        }
      };
    }
  });

  /* =======================================================================
     SCENE 02 — THE VISIBILITY GAP  (26.541 -> 57.247)
     ======================================================================= */
  SCENES.push({
    id: 'scene_02', portal: 'Public site · The problem',
    build(root) {
      root.classList.add('bg-paper');
      const stake = (i, icon, who, has, lacks, tone) => `
        <div class="stake card-lite card-pad" data-stake="${i}" style="opacity:0">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:18px">
            <span style="width:42px;height:42px;border-radius:12px;display:flex;align-items:center;justify-content:center;background:${tone};color:var(--green)">${ico(icon, 22)}</span>
            <div style="font-size:15px;font-weight:700;letter-spacing:.06em;text-transform:uppercase;color:var(--muted)">${who}</div>
          </div>
          <div style="font-size:26px;font-weight:700;letter-spacing:-.02em;line-height:1.25;margin-bottom:10px">${has}</div>
          <div style="display:flex;align-items:flex-start;gap:10px;font-size:19px;color:#B4483C;line-height:1.4">
            <span style="flex:none;margin-top:2px">${ico('ban', 19, '#C2544A')}</span><span>${lacks}</span>
          </div>
        </div>`;

      let wallCards = '';
      for (let i = 0; i < 20; i++) {
        wallCards += `<div class="wallcard" style="opacity:0">
          <div style="width:26px;height:26px;border-radius:50%;background:#E2E8E4;flex:none"></div>
          <div style="flex:1">
            <div style="height:8px;width:${55 + (i % 5) * 8}%;border-radius:4px;background:#DCE3DE"></div>
            <div style="height:6px;width:${30 + (i % 3) * 9}%;border-radius:3px;background:#EBEFEC;margin-top:6px"></div>
          </div>
        </div>`;
      }

      root.innerHTML = `
        <div style="position:absolute;left:0;right:0;top:0;height:340px;background:radial-gradient(900px 340px at 30% 0%, rgba(8,122,85,.07), transparent 70%)"></div>

        <div class="sh" style="position:absolute;left:130px;top:104px;z-index:20;opacity:0">
          <div class="kicker" style="display:flex;align-items:center;gap:14px;margin-bottom:18px">
            <span class="n" style="font-family:var(--mono);font-size:13px;font-weight:600;letter-spacing:.14em;padding:5px 11px;border-radius:6px;background:var(--green);color:#fff">02</span>
            <span style="font-size:13px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--muted)">The visibility gap</span>
          </div>
          <div class="display-m" style="max-width:1200px">
            <span data-h="0">${wordsHTML('A resume is only a snapshot.')}</span>
          </div>
          <div class="subhead c-muted" style="margin-top:16px;max-width:1120px" data-sub>
            It rarely reveals how someone solves problems, or what they have actually built.
          </div>
        </div>

        <div class="band" style="position:absolute;left:130px;right:130px;top:700px;z-index:19;opacity:0">
          <div style="height:1px;background:rgba(30,41,59,.10)"></div>
          <div style="display:flex;align-items:center;justify-content:space-between;gap:30px;margin-top:22px">
            <div style="display:flex;align-items:center;gap:16px">
              <span style="color:#B4483C">${ico('ban', 22)}</span>
              <div style="font-size:25px;font-weight:600;letter-spacing:-.015em;color:#3F5A4E">Hiring still runs on <b style="color:var(--ink)">documents</b>, not on <b style="color:var(--green)">demonstrated ability</b>.</div>
            </div>
            <div style="display:flex;gap:10px;flex:none">
              <span class="tag ghost" style="font-size:12.5px;padding:7px 13px">1 page</span>
              <span class="tag ghost" style="font-size:12.5px;padding:7px 13px">0 proof</span>
              <span class="tag ghost" style="font-size:12.5px;padding:7px 13px">300 applications</span>
            </div>
          </div>
        </div>

        <div class="stakes" style="position:absolute;left:130px;right:130px;top:430px;display:grid;grid-template-columns:repeat(3,1fr);gap:30px;z-index:20">
          ${stake(0, 'user', 'The student', 'Has real, working skills.', 'No credible way to prove them at scale.', '#EAF5EF')}
          ${stake(1, 'building', 'The university', 'Runs strong programs.', 'No visibility into learner skill outcomes.', '#EAF5EF')}
          ${stake(2, 'briefcase', 'The employer', 'Receives hundreds of applications.', 'Walls of identical profiles, no real proof.', '#EAF5EF')}
        </div>

        <div class="wall" style="position:absolute;left:130px;right:130px;top:392px;display:grid;grid-template-columns:repeat(5,1fr);gap:16px;z-index:22;opacity:0">
          ${wallCards}
        </div>
        <div class="wall-label" style="position:absolute;left:130px;top:340px;z-index:23;display:flex;align-items:center;gap:12px;opacity:0">
          <span class="tag amber">${ico('filter', 15)} Keyword filter</span>
          <span style="font-size:20px;font-weight:600;color:#B4483C">Identical on paper. Indistinguishable in practice.</span>
        </div>

        <div class="gapwrap" style="position:absolute;inset:0;z-index:24;opacity:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
          <div class="micro c-muted" style="margin-bottom:20px">Three challenges · one underlying gap</div>
          <div class="display-m" style="text-align:center;max-width:1280px;line-height:1.24">
            <div data-g="0">${wordsHTML('The gap between')} <span class="c-green" data-g="1">${wordsHTML('having skills')}</span></div>
            <div style="margin-top:8px"><span data-g="2">${wordsHTML('and being')}</span> <span class="c-gold" data-g="3" style="color:#B8862B">${wordsHTML('recognized for them.')}</span></div>
          </div>
          <div class="chain" style="position:relative;margin-top:82px;display:flex;align-items:center;justify-content:center;opacity:0" data-chain>
            <div data-half-l style="display:flex;align-items:center;gap:14px;padding:20px 32px 20px 28px;border-radius:999px;border:3px solid #0B7F49;background:rgba(8,122,85,.07)">
              <span style="color:#0B7F49">${ico('check', 22)}</span>
              <span style="font-size:23px;font-weight:800;letter-spacing:-.02em;color:#0B7F49">SKILLS EXIST</span>
            </div>
            <div data-gap style="width:0;height:2px;background:repeating-linear-gradient(90deg,#D6A84F 0 8px,transparent 8px 16px)"></div>
            <div data-half-r style="display:flex;align-items:center;gap:14px;padding:20px 28px 20px 32px;border-radius:999px;border:3px solid #C9A227;background:rgba(214,168,79,.12)">
              <span style="font-size:23px;font-weight:800;letter-spacing:-.02em;color:#9A6B16">RECOGNITION</span>
              <span style="color:#C9A227">${ico('ban', 22)}</span>
            </div>
            <div style="position:absolute;left:50%;top:calc(100% + 16px);transform:translateX(-50%);padding:7px 15px;border-radius:999px;background:#fff;border:1.5px solid rgba(214,168,79,.55);font-family:var(--mono);font-size:11.5px;letter-spacing:.12em;text-transform:uppercase;color:#9A6B16;box-shadow:0 12px 28px rgba(214,168,79,.24);white-space:nowrap" data-break>no shared proof</div>
          </div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        sh: q('.sh'), sub: q('[data-sub]'), band: q('.band'),
        stakes: [...root.querySelectorAll('[data-stake]')],
        wall: q('.wall'), wallLabel: q('.wall-label'), wallCards: [...root.querySelectorAll('.wallcard')],
        gapwrap: q('.gapwrap'), chain: q('[data-chain]'),
        la: q('[data-half-l]'), lb: q('[data-half-r]'), gap: q('[data-gap]'), brk: q('[data-break]'),
      };

      this.frame = (t, lt, D) => {
        // header 26.9 -> 38.9
        const hIn = S(t, 27.00, 27.6), hOut = 1 - S(t, 38.60, 39.3, ez.inCubic);
        put(el.sh, { o: hIn * hOut });
        applyWords(root.querySelectorAll('[data-h="0"] .kw'), stagger(t, 27.04, 0.10, 5, { y: 30 }));
        put(el.sub, Object.assign({}, enter(t, 27.85, 0.6, { y: 18, blur: 4 }), { o: S(t, 27.85, 28.5) * hOut }));

        // stakeholder cards: enter early, then spotlighted as the VO names each of the three
        const SPOT = [38.76, 41.74, 44.64];
        el.stakes.forEach((c, i) => {
          const p = S(t, 27.95 + i * 0.16, 28.75 + i * 0.16, ez.outCubic);
          const fade = 1 - S(t, 45.05 + i * 0.06, 45.8, ez.inCubic);
          const lit = S(t, SPOT[i], SPOT[i] + 0.5, ez.outCubic);
          const anyLit = S(t, SPOT[0] - 0.2, SPOT[0] + 0.3);
          const dim = 1 - 0.62 * anyLit * (1 - lit);
          const lift = lit * 10;
          put(c, { o: p * fade * dim, y: lerp(46, 0, p) - lift, s: lerp(0.975, 1, p) * (1 + lit * 0.018), blur: lerp(8, 0, p) });
          c.style.boxShadow = lit > 0.02
            ? `0 ${(18 + 14 * lit).toFixed(0)}px ${(40 + 22 * lit).toFixed(0)}px rgba(8,122,85,${(0.10 + 0.16 * lit).toFixed(2)}), 0 0 0 ${(2.5 * lit).toFixed(1)}px rgba(8,122,85,${(0.24 * lit).toFixed(2)})`
            : '';
        });

        // bottom band supports the header beat
        put(el.band, { o: S(t, 29.4, 30.2) * (1 - S(t, 37.9, 38.6, ez.inCubic)), y: lerp(18, 0, S(t, 29.4, 30.3, ez.outCubic)) });

        // wall of identical profiles 45.0 -> 49.6
        const wIn = S(t, 45.05, 46.05, ez.outCubic), wOut = 1 - S(t, 48.75, 49.6, ez.inCubic);
        put(el.wall, { o: wIn * wOut });
        put(el.wallLabel, { o: S(t, 45.4, 46.2) * wOut, y: lerp(-14, 0, S(t, 45.4, 46.2, ez.outCubic)) });
        el.wallCards.forEach((c, i) => {
          const d = (i % 5) * 0.035 + Math.floor(i / 5) * 0.05;
          const p = S(t, 45.1 + d, 45.75 + d, ez.outCubic);
          put(c, { o: p * 0.94, y: lerp(-22, 0, p), s: lerp(0.96, 1, p) });
        });

        // gap + chain 49.5 -> 57.2
        put(el.gapwrap, { o: S(t, 49.35, 49.95) });
        ['0', '1', '2', '3'].forEach((k, i) => {
          const t0 = [49.50, 50.30, 52.22, 53.30][i];
          applyWords(root.querySelectorAll(`[data-g="${k}"] .kw`), stagger(t, t0, 0.075, 4, { y: 30 }));
        });
        put(el.chain, { o: S(t, 50.6, 51.4), y: lerp(18, 0, S(t, 50.6, 51.5, ez.outCubic)) });

        // the two halves pull apart at 55.3 as the VO lands "recognized for them"
        const brk = S(t, 55.30, 56.40, ez.inOutCubic);
        el.gap.style.width = (brk * 210).toFixed(1) + 'px';
        put(el.la, { x: -brk * 104, rz: -brk * 1.6 });
        put(el.lb, { x: brk * 104, rz: brk * 1.6 });
        el.brk.style.opacity = (S(t, 51.0, 51.7) * (1 - brk * 0.8)).toFixed(3);
        el.brk.style.transform = `translateX(-50%) translateY(${(-brk * 10).toFixed(1)}px)`;
      };
    }
  });

  /* =======================================================================
     SCENE 03 — INTRODUCING APTOHIRE  (57.247 -> 85.050)
     ======================================================================= */
  SCENES.push({
    id: 'scene_03', portal: 'AptoHire · Platform',
    build(root) {
      root.classList.add('bg-navy');
      root.innerHTML = `
        <div style="position:absolute;inset:0;background:radial-gradient(760px 500px at 50% 44%, rgba(8,122,85,.28), transparent 72%)"></div>
        <div style="position:absolute;inset:0;background:radial-gradient(1200px 800px at 82% 8%, rgba(214,168,79,.10), transparent 66%)"></div>

        <!-- Logo lock at 58.00 -->
        <div class="lockup" style="position:absolute;left:0;right:0;top:150px;display:flex;flex-direction:column;align-items:center;z-index:30;opacity:1">
          <div style="display:flex;align-items:center;justify-content:center" data-wordrow>
            <img data-locklogo src="assets/lockup_light.webp" alt="AptoHire"
                 style="width:1000px;display:block;filter:drop-shadow(0 24px 60px rgba(10,207,131,.28))">
          </div>
          <div style="margin-top:28px;font-size:30px;font-weight:600;letter-spacing:.02em;color:#6EE7B7;opacity:0" data-tag>
            Prove Skills. Match Potential. Get Hired.
          </div>
          <div style="margin-top:16px;font-size:17px;font-family:var(--mono);letter-spacing:.12em;text-transform:uppercase;color:rgba(255,255,255,.42);opacity:0" data-sub>
            Skills-first hiring infrastructure · Oct 2026
          </div>
        </div>

        <!-- the question: one stage, centred on the same optical centre as the logo -->
        <div class="q3" style="position:absolute;left:0;right:0;top:556px;z-index:31;opacity:0">
          <div style="max-width:1400px;margin:0 auto;text-align:center">
            <div style="font-size:72px;font-weight:800;letter-spacing:-.035em;line-height:1.16;color:#fff">What if hiring</div>
            <div style="font-size:72px;font-weight:800;letter-spacing:-.035em;line-height:1.16;color:#6EE7B7">looked beyond the resume?</div>
          </div>
        </div>

        <!-- positioning line + portals -->
        <div class="p3" style="position:absolute;left:0;right:0;top:118px;z-index:32;text-align:center;opacity:0">
          <div class="display-m" style="color:#fff;max-width:1240px;margin:0 auto">
            <span data-pl>${wordsHTML('A skills-first hiring platform.')}</span>
          </div>
          <div class="subhead" style="color:#94A3B8;margin-top:18px;opacity:0" data-pl2>
            Connecting demonstrated ability with meaningful opportunity.
          </div>
        </div>

        <div class="portals3" style="position:absolute;left:0;right:0;top:452px;display:flex;justify-content:center;gap:34px;z-index:33">
          ${[['user', 'Student', 'Proves skills'], ['briefcase', 'Organization', 'Hires on proof'], ['building', 'University', 'Tracks outcomes'], ['shield', 'Admin', 'Governs trust']].map((p, i) => `
            <div class="pcard" data-pc="${i}" style="opacity:0;width:356px;padding:30px 26px;border-radius:20px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.13);text-align:left">
              <div style="width:52px;height:52px;border-radius:14px;background:rgba(10,207,131,.14);border:1px solid rgba(10,207,131,.3);display:flex;align-items:center;justify-content:center;color:#6EE7B7;margin-bottom:22px">${ico(p[0], 26)}</div>
              <div style="font-size:26px;font-weight:700;color:#fff;letter-spacing:-.02em">${p[1]}</div>
              <div style="font-size:17px;color:#94A3B8;margin-top:6px">${p[2]}</div>
            </div>`).join('')}
        </div>

        <!-- live portals strip (2.5D) -->
        <div class="strip3" style="position:absolute;left:0;right:0;top:706px;display:flex;justify-content:center;gap:26px;z-index:33;perspective:2000px">
          ${[['student_home.webp', 'Student', 'aptohire-student'], ['org_candidates.webp', 'Organization', 'aptohire-organization'], ['uni_overview.webp', 'University', 'aptohire-university'], ['admin_dashboard.webp', 'Admin', 'aptohire-admin']].map((p2, i) => `
            <div data-strip="${i}" style="opacity:0;width:318px;border-radius:12px;overflow:hidden;border:1px solid rgba(255,255,255,.16);box-shadow:0 26px 60px rgba(0,0,0,.5);background:#0B111C;transform-style:preserve-3d">
              <div style="display:flex;align-items:center;gap:6px;padding:7px 11px;background:rgba(255,255,255,.05);border-bottom:1px solid rgba(255,255,255,.1)">
                <span style="width:5px;height:5px;border-radius:50%;background:#6EE7B7"></span>
                <span style="font-family:var(--mono);font-size:9.5px;letter-spacing:.06em;color:rgba(255,255,255,.55)">${p2[2]}.vercel.app</span>
                <span style="margin-left:auto;font-size:8.5px;font-weight:700;letter-spacing:.08em;color:#6EE7B7">${p2[1].toUpperCase()}</span>
              </div>
              <div style="height:176px;overflow:hidden"><img src="assets/${p2[0]}" style="width:100%;display:block;margin-top:-4px"></div>
            </div>`).join('')}
        </div>

        <!-- verifiable credential proof -->
        <div class="proof3" style="position:absolute;left:0;right:0;top:330px;display:flex;justify-content:center;z-index:34;opacity:0">
          <div style="width:1080px;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.14);border-radius:22px;padding:34px 40px;display:grid;grid-template-columns:1fr 1fr;gap:40px;align-items:center">
            <div>
              <div class="micro" style="color:#6EE7B7;margin-bottom:16px">Cryptographic proof protocol</div>
              <div style="font-size:40px;font-weight:800;color:#fff;letter-spacing:-.03em;line-height:1.12">Every project becomes a<br><span style="color:#6EE7B7">verifiable credential.</span></div>
              <div style="font-size:18px;color:#94A3B8;margin-top:16px;line-height:1.5">Scored against a public rubric, linked to the exact source file and demo timestamp. Anyone can inspect it. Nothing can be edited after the fact.</div>
              <div style="margin-top:22px;display:flex;align-items:center;gap:10px;font-family:var(--mono);font-size:13px;color:#6EE7B7;background:rgba(10,207,131,.10);border:1px solid rgba(10,207,131,.28);padding:10px 14px;border-radius:9px;width:fit-content">
                ${ico('lock', 15)} sha256 · 9f2c…7a41 · tamper-evident
              </div>
            </div>
            <div style="background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.12);border-radius:16px;padding:22px 24px">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
                <div style="font-size:13px;font-family:var(--mono);letter-spacing:.1em;text-transform:uppercase;color:#94A3B8">Sample scorecard</div>
                <span style="font-size:12px;font-weight:700;color:#6EE7B7;background:rgba(10,207,131,.14);border:1px solid rgba(10,207,131,.3);padding:4px 10px;border-radius:999px">VERIFIED</span>
              </div>
              <div style="display:flex;align-items:center;gap:18px">
                <div class="ring" style="width:96px;height:96px">
                  <svg width="96" height="96"><circle cx="48" cy="48" r="41" stroke="rgba(255,255,255,.14)" stroke-width="7" fill="none"/>
                    <circle data-ring cx="48" cy="48" r="41" stroke="#0ACF83" stroke-width="7" fill="none" stroke-linecap="round" stroke-dasharray="258" stroke-dashoffset="258"/></svg>
                  <div class="val" style="color:#fff"><b style="font-size:32px" data-num>0</b></div>
                </div>
                <div>
                  <div style="font-size:24px;font-weight:700;color:#fff">React · Proficient</div>
                  <div style="font-size:15px;color:#94A3B8;margin-top:4px">Exceeds the 50-point benchmark</div>
                </div>
              </div>
              <div style="margin-top:18px;display:flex;flex-direction:column;gap:9px">
                ${[['Correctness', 74], ['Code quality', 66], ['Communication', 78]].map(r => `
                  <div style="display:flex;align-items:center;gap:12px">
                    <div style="width:104px;font-size:13px;color:#94A3B8">${r[0]}</div>
                    <div style="flex:1;height:5px;border-radius:5px;background:rgba(255,255,255,.13);overflow:hidden"><div class="bfill" style="height:100%;width:0;background:#6EE7B7;border-radius:5px"></div></div>
                    <div class="mono" style="font-size:13px;color:#fff;width:22px;text-align:right">${r[1]}</div>
                  </div>`).join('')}
              </div>
            </div>
          </div>
        </div>

        <!-- blind until consent -->
        <div class="consent3" style="position:absolute;left:0;right:0;top:400px;display:flex;justify-content:center;gap:44px;align-items:center;z-index:35;opacity:0">
          <div style="width:520px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.14);border-radius:20px;padding:30px 32px">
            <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:22px">
              <div style="display:flex;align-items:center;gap:12px">
                <div style="width:44px;height:44px;border-radius:50%;background:rgba(255,255,255,.09);display:flex;align-items:center;justify-content:center;color:#94A3B8">${ico('eyeOff', 22)}</div>
                <div>
                  <div style="font-size:22px;font-weight:700;color:#fff">Candidate K7F2</div>
                  <div style="font-size:14px;color:#94A3B8">Tier 2 · University</div>
                </div>
              </div>
              <div style="font-family:var(--mono);font-size:26px;font-weight:700;color:#6EE7B7">86%</div>
            </div>
            <div style="height:1px;background:rgba(255,255,255,.1);margin-bottom:20px"></div>
            ${['Name', 'Photo', 'College', 'Contact'].map((l, i) => `
              <div style="display:flex;align-items:center;justify-content:space-between;padding:11px 0">
                <span style="font-size:16px;color:#94A3B8">${l}</span>
                <span style="display:flex;align-items:center;gap:9px;font-size:15px;color:rgba(255,255,255,.72)">
                  <span data-bar style="display:block;width:120px;height:9px;border-radius:5px;background:rgba(255,255,255,.16)"></span>${ico('lock', 14, '#D6A84F')}
                </span>
              </div>`).join('')}
          </div>
          <div style="display:flex;flex-direction:column;align-items:center;gap:18px">
            <div style="width:78px;height:78px;border-radius:50%;background:rgba(214,168,79,.14);border:2px solid #D6A84F;display:flex;align-items:center;justify-content:center;color:#F2C879;box-shadow:0 0 50px rgba(214,168,79,.4)">${ico('lock', 34)}</div>
            <div style="font-size:17px;font-weight:700;color:#F2C879;letter-spacing:.04em;text-transform:uppercase">Consent</div>
            <div style="font-size:15px;color:#94A3B8;text-align:center;max-width:230px;line-height:1.45">Identity is released only by the student, only for a scoped window.</div>
          </div>
        </div>

        <!-- triad -->
        <div class="triad" style="position:absolute;left:0;right:0;top:0;bottom:0;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:26px;z-index:36;opacity:0">
          <div style="font-size:58px;font-weight:800;letter-spacing:-.035em;color:#fff;text-align:center" data-tri="0">Make skills visible.</div>
          <div style="font-size:58px;font-weight:800;letter-spacing:-.035em;color:#6EE7B7;text-align:center" data-tri="1">Make talent discoverable.</div>
          <div style="font-size:58px;font-weight:800;letter-spacing:-.035em;color:#F2C879;text-align:center" data-tri="2">Hire for what you can do.</div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        lockup: q('.lockup'), logo: q('[data-locklogo]'), wordmark: q('[data-wordrow]'),
        tag: q('[data-tag]'), sub: q('[data-sub]'),
        q3: q('.q3'), p3: q('.p3'), pl: q('[data-pl]'), pl2: q('[data-pl2]'),
        pcs: [...root.querySelectorAll('[data-pc]')],
        proof: q('.proof3'), ring: q('[data-ring]'), num: q('[data-num]'), bf: [...root.querySelectorAll('.bfill')],
        consent: q('.consent3'), bars: [...root.querySelectorAll('[data-bar]')],
        triad: q('.triad'), tr: [0, 1, 2].map(i => q(`[data-tri="${i}"]`)),
        strip: [...root.querySelectorAll('[data-strip]')],
      };
      this.frame = (t, lt, D) => {
        // ----- Logo lock 58.00 : holds through the spoken question, then clears -----
        const lockOut = 1 - S(t, 61.50, 62.25, ez.inCubic);
        put(el.lockup, { o: lockOut, y: lerp(0, -46, S(t, 61.50, 62.25, ez.inCubic)), blur: lerp(0, 10, S(t, 61.50, 62.25, ez.inCubic)) });
        // ---- logo lock at 58.00 : the real brand lockup resolves out of a bloom ----
        const lk = S(t, 58.00, 59.25, ez.outQuart);
        put(el.logo, { o: S(t, 58.00, 58.62), s: lerp(0.90, 1, lk), blur: lerp(18, 0, lk) });
        put(el.tag, { o: S(t, 58.72, 59.5), y: lerp(14, 0, S(t, 58.72, 59.55, ez.outCubic)) });
        put(el.sub, { o: S(t, 59.15, 59.9) });

        // ----- The question 58.9 -> 61.2 -----
        // One uninterrupted stage: it rises under the logo while the VO asks it,
        // then clears BEFORE the positioning line arrives. No overlap, no re-entrance.
        put(el.q3, {
          o: S(t, 58.95, 59.72) * (1 - S(t, 61.15, 61.70, ez.inCubic)),
          y: lerp(18, 0, S(t, 58.95, 59.80, ez.outCubic)),
          blur: lerp(9, 0, S(t, 58.95, 59.85, ez.outCubic)),
        });

        // ----- positioning + 4 portals 61.6 -> 68.2 -----
        const p3o = S(t, 62.30, 62.95) * (1 - S(t, 67.85, 68.55, ez.inCubic));
        put(el.p3, { o: p3o, y: lerp(26, 0, S(t, 62.30, 63.05, ez.outCubic)) });
        applyWords(el.pl.querySelectorAll('.kw'), stagger(t, 62.36, 0.09, 5, { y: 28 }));
        put(el.pl2, { o: S(t, 62.95, 63.60), y: lerp(14, 0, S(t, 62.95, 63.65, ez.outCubic)) });
        el.pcs.forEach((c, i) => {
          const p = S(t, 63.30 + i * 0.16, 64.20 + i * 0.16, ez.outCubic);
          put(c, { o: p * p3o, y: lerp(60, 0, p), s: lerp(0.93, 1, p), ry: lerp(16, 0, p), blur: lerp(8, 0, p) });
        });

        // ----- live portals strip 64.1 -> 68.2 -----
        el.strip.forEach((c, i) => {
          const p = S(t, 64.05 + i * 0.11, 64.95 + i * 0.11, ez.outCubic);
          put(c, { o: p * p3o, y: lerp(54, 0, p), ry: lerp(24, 0, p), rz: lerp(-2, 0, p), s: lerp(0.93, 1, p) });
        });

        // ----- verifiable credential 68.1 -> 74.7 -----
        const pr = S(t, 68.10, 68.95, ez.outCubic) * (1 - S(t, 74.35, 75.05, ez.inCubic));
        put(el.proof, { o: pr, y: lerp(40, 0, S(t, 68.1, 69.0, ez.outCubic)) });
        if (el.ring) {
          const rp = S(t, 69.0, 71.9, ez.outCubic);
          el.ring.style.strokeDashoffset = (258 * (1 - 0.72 * rp)).toFixed(1);
          el.num.textContent = Math.round(72 * rp);
        }
        el.bf.forEach((b, i) => {
          const p = S(t, 70.3 + i * 0.55, 71.3 + i * 0.55, ez.outCubic);
          b.style.width = ([74, 66, 78][i] * p).toFixed(1) + '%';
        });

        // ----- blind until consent 74.7 -> 79.9 -----
        const co = S(t, 74.60, 75.35, ez.outCubic) * (1 - S(t, 79.35, 80.05, ez.inCubic));
        put(el.consent, { o: co, y: lerp(34, 0, S(t, 74.6, 75.45, ez.outCubic)) });
        el.bars.forEach((b, i) => {
          const p = S(t, 75.5 + i * 0.18, 76.2 + i * 0.18, ez.outCubic);
          b.style.width = (120 * (1 - p * 0.94)).toFixed(1) + 'px';
        });

        // ----- triad 79.9 -> 85.0 -----
        put(el.triad, { o: S(t, 80.00, 80.55) });
        el.tr.forEach((d, i) => {
          const t0 = [79.94, 81.14, 82.10][i];
          const p = S(t, t0, t0 + 0.62, ez.outCubic);
          put(d, { o: p, x: lerp(-46, 0, p), blur: lerp(10, 0, p) });
        });
      };
    }
  });

  /* =======================================================================
     SCENE 04 — STUDENT PORTAL  (85.050 -> 119.294)
     ======================================================================= */
  SCENES.push({
    id: 'scene_04', portal: 'Student portal',
    build(root) {
      root.classList.add('bg-paper');
      const nav = [
        { label: 'Home', icon: 'home' }, { label: 'Projects', icon: 'list' },
        { label: 'Scorecard', icon: 'target' }, { label: 'Sharing', icon: 'users', badge: '' },
        { label: 'Resume', icon: 'file' }, { label: 'Profile', icon: 'user' },
      ];
      root.innerHTML = `
        <div class="toprail" style="position:absolute;left:0;right:0;top:0;height:96px;display:flex;align-items:center;justify-content:space-between;padding:0 44px;z-index:25;border-bottom:1px solid rgba(30,41,59,.07);background:rgba(255,255,255,.7)">
          <div style="display:flex;align-items:center;gap:14px;opacity:0" data-rail>
            <span style="font-family:var(--mono);font-size:12px;font-weight:700;letter-spacing:.14em;padding:5px 11px;border-radius:6px;background:var(--green);color:#fff">04</span>
            <span style="font-size:13px;font-weight:700;letter-spacing:.16em;text-transform:uppercase;color:var(--muted)">Student portal · the learner</span>
          </div>
          <div style="display:flex;align-items:center;gap:10px;opacity:0" data-rail2>
            <span style="display:flex;align-items:center;gap:7px;font-family:var(--mono);font-size:12.5px;color:var(--muted)">${ico('globe', 14)} aptohire-student.vercel.app</span>
            <span style="font-size:11px;font-weight:700;letter-spacing:.08em;padding:4px 9px;border-radius:999px;background:var(--mint);color:var(--green);border:1px solid rgba(8,122,85,.2)">LIVE PROTOTYPE</span>
          </div>
        </div>

        <div class="iso-rig" style="top:96px">
          <div class="iso-plane" data-plane style="width:1700px;height:840px">
            <div class="portal-window" style="width:1700px;height:840px;grid-template-columns:236px 1fr" data-pw>
              ${sidebar({ role: 'student', nav, active: 'Home' })}
              <div class="portal-main">

                <!-- ---- 1. HOME ---- -->
                <div class="ps" data-ps="0" style="padding:28px 36px">
                  <div class="hero-band mint" style="padding:26px 30px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div style="display:flex;align-items:center;gap:10px;margin-bottom:12px">
                        <span class="tag">${ico('shield', 13)} Verified via Roster</span>
                        <span class="tag ghost">${ico('building', 13)} Uni A (Apex Institute of Technology)</span>
                      </div>
                      <div style="font-size:40px;font-weight:800;letter-spacing:-.035em">Welcome back, Aarav.</div>
                      <div style="font-size:17px;color:var(--muted);margin-top:8px">Here is your current skill status and opportunities</div>
                    </div>
                    <div style="display:flex;gap:12px">
                      <span class="tag ghost" style="padding:12px 18px;font-size:15px">${ico('link', 16)} Share Proof Link</span>
                      <span style="padding:12px 20px;border-radius:10px;background:var(--amber-cta);color:#fff;font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px">${ico('sparkle', 16)} Get a project</span>
                    </div>
                  </div>

                  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-top:20px">
                    ${[['Verified skills', '2', 'Active', 'Pass mark: 50+'], ['Proof index', '65', 'Proficient', 'Industry ready'],
                       ['Projects', '1', 'Total briefs', 'View briefs'], ['Employer access', '1', 'Waiting', 'Blind by default']].map((k, i) => `
                      <div class="card-lite" style="padding:18px 20px" data-kpi="${i}">
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:8px">
                          <span style="font-size:11.5px;font-weight:700;letter-spacing:.1em;text-transform:uppercase;color:var(--muted)">${k[0]}</span>
                          ${ico(['target', 'trendUp', 'file', 'lock'][i], 15, '#94A3B8')}
                        </div>
                        <div style="display:flex;align-items:baseline;gap:10px">
                          <span style="font-size:34px;font-weight:800;letter-spacing:-.04em" class="mono">${k[1]}</span>
                          <span style="font-size:13px;font-weight:600;color:var(--green)">${k[2]}</span>
                        </div>
                        <div style="font-size:12.5px;color:var(--muted);margin-top:6px">${k[3]}</div>
                      </div>`).join('')}
                  </div>

                  <div class="card-lite" style="margin-top:20px;padding:22px 26px;display:flex;align-items:center;justify-content:space-between">
                    <div>
                      <div class="micro c-green" style="margin-bottom:8px">${ico('sparkle', 13)} What to do next</div>
                      <div style="font-size:23px;font-weight:700;letter-spacing:-.02em">Your score is ready for Accessible Filterable Product Catalog</div>
                      <div style="font-size:15px;color:var(--muted);margin-top:6px">Review your rubric scores, Proof Ring, and cryptographic verification evidence.</div>
                    </div>
                    <span style="padding:12px 22px;border-radius:10px;background:var(--green);color:#fff;font-size:15px;font-weight:700;display:flex;align-items:center;gap:8px;flex:none">View scorecard ${ico('arrow', 15)}</span>
                  </div>

                  <div style="margin-top:22px;font-size:24px;font-weight:700;letter-spacing:-.02em">Your skills &amp; credentials</div>
                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:16px;margin-top:12px">
                    ${[['React', 'Web / Frontend', 72, 'Proficient', '#0B7F49'], ['TypeScript', 'Web / Frontend', 58, 'Competent', '#0B7F49']].map((s, i) => `
                      <div class="card-lite" style="padding:20px 22px" data-skill="${i}">
                        <div style="display:flex;align-items:center;justify-content:space-between">
                          <div style="display:flex;align-items:center;gap:14px">
                            <div class="ring" style="width:58px;height:58px">
                              <svg width="58" height="58"><circle cx="29" cy="29" r="24" stroke="#E6ECE8" stroke-width="5" fill="none"/>
                              <circle cx="29" cy="29" r="24" stroke="${s[4]}" stroke-width="5" fill="none" stroke-linecap="round" stroke-dasharray="151" stroke-dashoffset="${151 - 151 * s[2] / 100}"/></svg>
                              <div class="val" style="color:var(--ink)"><b style="font-size:19px">${s[2]}</b></div>
                            </div>
                            <div>
                              <div style="font-size:21px;font-weight:700">${s[0]}</div>
                              <div style="font-size:13.5px;color:var(--muted)">${s[1]}</div>
                            </div>
                          </div>
                          <span class="tag">${s[3]}</span>
                        </div>
                        <div style="display:flex;align-items:center;gap:12px;margin-top:14px">
                          <span style="font-size:12px;color:var(--muted);width:70px">Proof score</span>
                          <div class="bar-track" style="flex:1"><div class="bar-fill" style="transform:scaleX(${s[2] / 100})"></div></div>
                          <span class="mono" style="font-size:12.5px;font-weight:700">${s[2]} / 100</span>
                        </div>
                        <div style="display:flex;align-items:center;justify-content:space-between;margin-top:12px;padding-top:11px;border-top:1px solid rgba(30,41,59,.07)">
                          <span style="font-size:12px;color:var(--green);font-weight:600;display:flex;align-items:center;gap:5px">${ico('lock', 11)} Verify</span>
                          <span style="font-size:12px;color:var(--green);font-weight:600;display:flex;align-items:center;gap:5px">View scorecard ${ico('arrow', 11)}</span>
                        </div>
                      </div>`).join('')}
                  </div>

                  <div style="display:flex;align-items:center;justify-content:space-between;margin-top:20px">
                    <div style="font-size:20px;font-weight:700;letter-spacing:-.02em;display:flex;align-items:center;gap:9px">${ico('users', 19)} Pending employer access requests</div>
                    <span style="font-size:12.5px;color:var(--green);font-weight:600">View in Sharing</span>
                  </div>
                  <div class="card-lite" data-pending style="margin-top:10px;padding:16px 22px;display:flex;align-items:center;justify-content:space-between">
                    <div style="display:flex;align-items:center;gap:13px">
                      <span style="width:38px;height:38px;border-radius:10px;background:var(--mint);display:flex;align-items:center;justify-content:center;color:var(--green)">${ico('building', 19)}</span>
                      <div>
                        <div style="font-size:16px;font-weight:700">Northwind Labs</div>
                        <div style="font-size:12.5px;color:var(--muted);margin-top:2px">Front-end Developer (React) · Profile · Scorecard · 30 days</div>
                      </div>
                    </div>
                    <div style="display:flex;align-items:center;gap:12px">
                      <span class="tag amber" style="font-size:12px;padding:5px 12px">${ico('clock', 11)} Awaiting your decision</span>
                      <span style="padding:8px 16px;border-radius:8px;background:var(--green);color:#fff;font-size:12.5px;font-weight:700">Review request</span>
                    </div>
                  </div>
                </div>

                <!-- ---- 2. SUBMIT PROJECT ---- -->
                <div class="ps" data-ps="1" style="padding:26px 36px">
                  <div style="display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted);margin-bottom:14px">${ico('arrow', 14)} Back to projects</div>
                  <div style="font-size:38px;font-weight:800;letter-spacing:-.035em">Submit project</div>
                  <div style="font-size:15.5px;color:var(--muted);margin-top:6px;padding-bottom:16px;border-bottom:1px solid rgba(30,41,59,.08)">Submit your deliverables, code repositories, and demo video for rubric scoring</div>

                  <div style="display:grid;grid-template-columns:1fr 1fr;gap:20px;margin-top:18px">
                    <div class="card-lite" style="padding:22px 24px">
                      <div style="font-size:19px;font-weight:700;margin-bottom:14px">Project overview</div>
                      <div style="font-size:13px;font-weight:600;color:var(--muted);margin-bottom:7px">Project title <span class="c-green">*</span></div>
                      <div style="border:1px solid rgba(30,41,59,.14);border-radius:9px;padding:11px 14px;font-size:14.5px;color:var(--ink)" data-typed>Accessible Filterable Product Catalog<span class="caret" style="display:inline-block;width:1.5px;height:16px;background:var(--green);vertical-align:-3px;margin-left:2px"></span></div>
                      <div style="font-size:13px;font-weight:600;color:var(--muted);margin:16px 0 8px">Description</div>
                      <div style="border:1px solid rgba(30,41,59,.14);border-radius:9px;padding:11px 14px;font-size:13.5px;color:var(--muted);line-height:1.5;min-height:74px">Explain what the project accomplishes, key features, and performance considerations…</div>
                      <div style="font-size:13px;font-weight:600;color:var(--muted);margin:18px 0 10px">Skills claimed <span class="c-green">*</span></div>
                      <div style="display:flex;flex-wrap:wrap;gap:8px">
                        ${['Accessibility', 'API Integration', 'Auth', 'Communication', 'Financial modelling', 'HTML / CSS', 'JavaScript', 'Market analysis', 'ML basics', 'Node.js', 'Project planning', 'Python', 'React', 'REST design', 'SQL', 'Testing', 'TypeScript'].map((s, i) => `
                          <span class="chipx" data-chip="${i}" style="font-size:12.5px;font-weight:600;padding:5px 11px;border-radius:999px;border:1px solid ${i === 12 || i === 16 ? 'var(--green)' : 'rgba(30,41,59,.16)'};background:${i === 12 || i === 16 ? 'var(--green)' : '#fff'};color:${i === 12 || i === 16 ? '#fff' : 'var(--ink)'}">${s}</span>`).join('')}
                      </div>
                    </div>

                    <div style="display:flex;flex-direction:column;gap:18px">
                      <div class="card-lite" style="padding:22px 24px;border-color:rgba(8,122,85,.35);background:linear-gradient(160deg,#F4FBF7,#fff)">
                        <div style="display:flex;align-items:center;justify-content:space-between">
                          <div style="display:flex;align-items:center;gap:10px;font-size:19px;font-weight:700;color:var(--green)">${ico('video', 20)} Mandatory 3-minute demo video</div>
                          <span style="font-family:var(--mono);font-size:11.5px;color:var(--muted)">Max 3:10 · ≤ 50 MB</span>
                        </div>
                        <div style="font-size:13.5px;color:var(--muted);margin-top:8px">Walk through your code and live application. Video must be 3:10 or shorter.</div>
                        <div style="margin-top:14px;border:2px dashed rgba(8,122,85,.32);border-radius:12px;background:#fff;padding:22px;display:flex;align-items:center;gap:16px">
                          <div style="width:52px;height:52px;border-radius:12px;background:var(--mint);display:flex;align-items:center;justify-content:center;color:var(--green)">${ico('play', 24)}</div>
                          <div style="flex:1">
                            <div style="font-size:15px;font-weight:700">aarav-walkthrough.mp4</div>
                            <div style="font-size:12.5px;color:var(--muted);margin-top:3px;font-family:var(--mono)" data-upload>uploading · 0%</div>
                          </div>
                          <div style="width:104px;height:6px;border-radius:6px;background:#EAF5EF;overflow:hidden"><div data-uprog style="height:100%;width:0;background:var(--green)"></div></div>
                        </div>
                        <div style="margin-top:12px;display:flex;align-items:center;gap:8px;font-size:12.5px;color:var(--muted)">${ico('clock', 13)} 02:47 · 41.2 MB · 1080p</div>
                      </div>

                      <div class="card-lite" style="padding:20px 24px">
                        <div style="display:flex;align-items:center;gap:9px;font-size:16px;font-weight:700;margin-bottom:10px">${ico('sparkle', 17, '#B8862B')} AI-use disclosure</div>
                        <div style="font-size:13.5px;color:var(--muted);line-height:1.5">Disclosing AI assistance is never penalised. We score what you built and how you explain it.</div>
                        <div style="margin-top:12px;display:flex;gap:8px">
                          <span class="tag" style="background:var(--green);color:#fff;border-color:var(--green)">${ico('check', 13)} Copilot used</span>
                          <span class="tag ghost">Declared</span>
                        </div>
                      </div>

                      <div class="card-lite" style="padding:18px 24px;display:flex;align-items:center;gap:12px;background:#F8FAF9">
                        <span style="width:34px;height:34px;border-radius:50%;background:var(--mint);display:flex;align-items:center;justify-content:center;color:var(--green)">${ico('database', 17)}</span>
                        <div>
                          <div style="font-size:14.5px;font-weight:700">GitHub repository connected</div>
                          <div style="font-family:var(--mono);font-size:12px;color:var(--muted);margin-top:3px">github.com/aarav/catalog · 34 commits</div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- ---- 3. SCORECARD ---- -->
                <div class="ps" data-ps="2" style="padding:24px 40px">
                  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
                    <div style="display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted)">${ico('arrow', 14)} Back to scorecard <span style="opacity:.4">·</span> Scorecard <span style="opacity:.4">·</span> <b style="color:var(--ink)">React</b></div>
                    <div style="display:flex;gap:10px">
                      <span class="tag ghost" style="padding:9px 15px;font-size:13.5px">${ico('download', 14)} Download resume</span>
                      <span style="padding:9px 17px;border-radius:8px;background:var(--amber-cta);color:#fff;font-size:13.5px;font-weight:700">+ Get next project</span>
                    </div>
                  </div>

                  <div class="card-lite" style="padding:26px 30px;display:flex;align-items:center;gap:38px;background:linear-gradient(120deg,#F7FCF9,#FDF8F1)">
                    <div class="ring" style="width:186px;height:186px;flex:none">
                      <svg width="186" height="186">
                        <circle cx="93" cy="93" r="80" stroke="#E6ECE8" stroke-width="12" fill="none"/>
                        <circle data-bigring cx="93" cy="93" r="80" stroke="url(#rg1)" stroke-width="12" fill="none" stroke-linecap="round" stroke-dasharray="503" stroke-dashoffset="503"/>
                        <defs><linearGradient id="rg1" x1="0" y1="1" x2="1" y2="0"><stop offset="0" stop-color="#0B7F49"/><stop offset="1" stop-color="#6EE7B7"/></linearGradient></defs>
                      </svg>
                      <div class="val"><b data-bignum style="font-size:60px">0</b><i>Proficient</i></div>
                    </div>
                    <div style="flex:1">
                      <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
                        <span class="tag">${ico('checkCircle', 14)} Proficient</span>
                        <span style="font-size:13px;color:var(--muted)">Reviewed 19 Oct 2026 · Confidence high</span>
                      </div>
                      <div style="font-size:40px;font-weight:800;letter-spacing:-.035em">Proficient React developer</div>
                      <div style="margin-top:12px;font-size:15.5px;color:var(--muted);font-style:italic;border-left:3px solid var(--green);padding-left:14px;line-height:1.5">“Verified competency demonstrated in React with evaluated code implementation, architectural patterns, and practical execution.”</div>
                    </div>
                  </div>

                  <div style="display:flex;align-items:center;justify-content:space-between;margin:22px 0 10px">
                    <div>
                      <div style="font-size:25px;font-weight:700;letter-spacing:-.02em">Evidence trail</div>
                      <div style="font-size:13.5px;color:var(--muted);margin-top:3px">Every rubric score is linked to verified code snippets, demo timestamps, and live links.</div>
                    </div>
                    <span class="tag gold">${ico('lock', 13)} Immutable after review</span>
                  </div>

                  <div class="card-lite" style="padding:4px 26px" data-evid>
                    ${[['Technical Competency & Syntax', '30%', 72, 'Demonstrated deep practical proficiency against technical benchmarks.'],
                       ['Optimization & Architecture', '30%', 70, 'Engineered clean modular abstractions with measured performance metrics.'],
                       ['System Reliability', '20%', 73, 'Validated against edge cases and system fault conditions.'],
                       ['Technical Communication', '20%', 72, 'Clear, structured explanation of trade-offs and edge cases.']].map((r, i) => `
                      <div style="display:flex;align-items:center;gap:18px;padding:13px 0;border-top:${i ? '1px solid rgba(30,41,59,.07)' : 'none'}" data-erow="${i}">
                        <div style="width:300px">
                          <div style="font-size:15.5px;font-weight:700">${r[0]} <span style="font-size:12px;font-weight:600;color:var(--muted)">${r[1]}</span></div>
                          <div style="font-size:12.5px;color:var(--muted);margin-top:3px">${r[3]}</div>
                        </div>
                        <div class="bar-track" style="flex:1"><div class="bar-fill" data-ebar="${i}" style="transform:scaleX(0)"></div></div>
                        <span class="mono" style="font-size:16px;font-weight:800;width:34px;text-align:right">${r[2]}</span>
                        <span class="tag ghost" style="font-size:12px">${ico('code', 12)} src/</span>
                        <span class="tag ghost" style="font-size:12px">${ico('video', 12)} ${['0:12', '0:38', '1:03', '1:39'][i]}</span>
                      </div>`).join('')}
                  </div>
                </div>

                <!-- ---- 4. RESUME / QR ---- -->
                <div class="ps" data-ps="3" style="padding:24px 40px">
                  <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px">
                    <div style="display:flex;align-items:center;gap:10px;font-size:13px;color:var(--muted)">${ico('arrow', 14)} Back to scorecard</div>
                    <div style="display:flex;gap:10px"><span class="tag ghost" style="padding:9px 15px;font-size:13.5px">${ico('file', 14)} Print</span>
                    <span style="padding:9px 17px;border-radius:8px;background:var(--green);color:#fff;font-size:13.5px;font-weight:700;display:flex;align-items:center;gap:7px">${ico('download', 14)} Download PDF</span></div>
                  </div>

                  <div class="card-lite" style="padding:30px 36px;margin-top:6px">
                    <div style="display:flex;align-items:flex-start;justify-content:space-between">
                      <div>
                        <div style="font-size:40px;font-weight:800;letter-spacing:-.035em">Aarav Sharma</div>
                        <div style="font-size:17px;color:var(--muted);margin-top:6px">Front-end engineer focused on React &amp; TypeScript performance</div>
                        <div style="display:flex;align-items:center;gap:12px;margin-top:14px">
                          <span style="font-family:var(--mono);font-size:12.5px;background:var(--mint);color:var(--green);padding:6px 12px;border-radius:7px;font-weight:600">AptoHire ID: APT-8924-ARV</span>
                          <span style="font-size:13.5px;color:var(--muted)">Bengaluru, India</span>
                        </div>
                      </div>
                      <div style="text-align:center">
                        <div style="width:126px;height:126px;border-radius:10px;border:1px solid rgba(30,41,59,.12);padding:8px;background:#fff" data-qr>
                          <svg viewBox="0 0 25 25" width="110" height="110" shape-rendering="crispEdges" data-qrsvg></svg>
                        </div>
                        <div style="font-size:11.5px;color:var(--muted);margin-top:7px">Scan to verify</div>
                      </div>
                    </div>

                    <div style="height:1px;background:rgba(30,41,59,.09);margin:22px 0"></div>
                    <div style="display:grid;grid-template-columns:1.1fr 1fr;gap:34px">
                      <div>
                        <div style="font-size:16px;font-weight:700;margin-bottom:10px">Verified skills</div>
                        ${[['React', 'Proficient', 72], ['TypeScript', 'Competent', 58]].map(s => `
                          <div style="display:flex;align-items:center;justify-content:space-between;padding:11px 14px;border:1px solid rgba(30,41,59,.1);border-radius:10px;margin-bottom:10px">
                            <div><div style="font-size:14.5px;font-weight:700">${s[0]}</div><div style="font-size:12px;color:var(--muted)">Web / Frontend</div></div>
                            <div style="display:flex;align-items:center;gap:12px"><span class="tag">${ico('check', 12)} ${s[1]}</span><span class="mono" style="font-size:15px;font-weight:800">${s[2]}<span style="font-size:11px;color:var(--muted)">/100</span></span></div>
                          </div>`).join('')}
                      </div>
                      <div>
                        <div style="font-size:16px;font-weight:700;margin-bottom:10px">Verification</div>
                        <div style="font-family:var(--mono);font-size:11.5px;color:var(--muted);line-height:1.7;background:#F8FAF9;border:1px solid rgba(30,41,59,.09);border-radius:10px;padding:14px 16px">
                          <div>url · aptohire.vercel.app/verify/</div>
                          <div style="color:var(--green);font-weight:600">APT-8924-ARV</div>
                          <div style="margin-top:8px">sha256 · 4d81…c9f2</div>
                          <div>rubric · v2.3 · public</div>
                          <div style="color:var(--green);font-weight:600;margin-top:8px">✓ signature valid</div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div style="margin-top:16px;display:flex;align-items:center;gap:10px;font-size:14px;color:var(--muted)">
                    ${ico('globe', 15)} Portable for life — the credential never expires, and the student holds the key.
                  </div>
                </div>

              </div>
            </div>
          </div>
        </div>
      `;
      const q = s => root.querySelector(s);
      const el = {
        plane: q('[data-plane]'), pw: q('[data-pw]'), rail: q('[data-rail]'), rail2: q('[data-rail2]'),
        screens: [...root.querySelectorAll('[data-ps]')],
        typed: q('[data-typed]'), uprog: q('[data-uprog]'), upload: q('[data-upload]'),
        bigring: q('[data-bigring]'), bignum: q('[data-bignum]'),
        ebar: [...root.querySelectorAll('[data-ebar]')], erow: [...root.querySelectorAll('[data-erow]')],
        qrsvg: q('[data-qrsvg]'), chips: [...root.querySelectorAll('[data-chip]')],
        kpi: [...root.querySelectorAll('[data-kpi]')], skill: [...root.querySelectorAll('[data-skill]')],
      };

      // deterministic pseudo-QR (23x23 modules) — stylised, not a real encoder
      (function buildQR() {
        let seed = 20261019, out = '';
        const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
        const N = 23, cell = 1;
        const finder = (x, y) => out += `<rect x="${x}" y="${y}" width="7" height="7" fill="#0F172A"/><rect x="${x + 1}" y="${y + 1}" width="5" height="5" fill="#fff"/><rect x="${x + 2}" y="${y + 2}" width="3" height="3" fill="#0F172A"/>`;
        out += `<rect width="23" height="23" fill="#fff"/>`;
        for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) {
          const inFinder = (x < 8 && y < 8) || (x > N - 9 && y < 8) || (x < 8 && y > N - 9);
          if (!inFinder && rnd() > 0.52) out += `<rect x="${x}" y="${y}" width="${cell}" height="${cell}" fill="#0F172A"/>`;
        }
        finder(0, 0); finder(N - 7, 0); finder(0, N - 7);
        el.qrsvg.innerHTML = out;
      })();

      const FULL = 'Accessible Filterable Product Catalog';

      this.frame = (t, lt, D) => {
        // portal rig: 2.5D entrance at 85.0
        const inP = S(t, 85.02, 86.35, ez.outQuart);
        put(el.plane, {
          o: lerp(0, 1, S(t, 85.02, 85.9)),
          ry: lerp(-19, 0, inP), rx: lerp(9, 0, inP), rz: lerp(-1.6, 0, inP),
          z: lerp(-140, 0, inP), s: lerp(0.9, 1, inP), y: lerp(50, 0, inP),
        });
        put(el.rail, { o: S(t, 85.15, 85.8), x: lerp(-16, 0, S(t, 85.15, 85.9, ez.outCubic)) });
        put(el.rail2, { o: S(t, 85.3, 85.95) });

        // KPI + skill cards stagger
        el.kpi.forEach((c, i) => { const p = S(t, 86.0 + i * 0.1, 86.75 + i * 0.1, ez.outCubic); put(c, { o: p, y: lerp(24, 0, p), blur: lerp(6, 0, p) }); });
        el.skill.forEach((c, i) => { const p = S(t, 88.6 + i * 0.12, 89.4 + i * 0.12, ez.outCubic); put(c, { o: p, y: lerp(22, 0, p) }); });

        // screen 0 (home) visible 85 -> 90.4
        const s0 = 1 - S(t, 90.30, 90.95, ez.inOutCubic);
        put(el.screens[0], { o: s0, x: lerp(0, -70, S(t, 90.30, 91.0, ez.inCubic)) });
        // screen 1 (submit) 90.4 -> 102.3
        const s1i = S(t, 90.35, 91.05, ez.outCubic), s1o = 1 - S(t, 102.10, 102.8, ez.inOutCubic);
        put(el.screens[1], { o: s1i * s1o, x: lerp(70, 0, s1i) + lerp(0, -70, 1 - s1o) });
        // screen 2 (scorecard) 102.3 -> 113.3
        const s2i = S(t, 102.15, 102.9, ez.outCubic), s2o = 1 - S(t, 113.10, 113.9, ez.inOutCubic);
        put(el.screens[2], { o: s2i * s2o, x: lerp(70, 0, s2i) });
        // screen 3 (resume) 113.3 -> 119.29
        const s3i = S(t, 113.15, 113.95, ez.outCubic);
        put(el.screens[3], { o: s3i, x: lerp(70, 0, s3i) });

        // type-on project title 90.6-93.3
        if (el.typed) {
          const p = S(t, 90.65, 93.2, ez.linear);
          const n = Math.round(FULL.length * p);
          el.typed.firstChild.nodeValue = FULL.slice(0, n);
        }
        // upload progress 96.3-98.4
        if (el.uprog) {
          const p = S(t, 96.30, 98.35, ez.outCubic);
          el.uprog.style.width = (p * 100).toFixed(1) + '%';
          el.upload.textContent = p < 1 ? `uploading · ${Math.round(p * 100)}%` : 'verified · 02:47 / 03:10';
        }
        // chips activate during 92.4-94.4
        el.chips.forEach((c, i) => {
          if (i === 12 || i === 16) return;
          const p = S(t, 93.9 + i * 0.045, 94.35 + i * 0.045, ez.outBackSoft);
          const on = i % 3 === 1;
          c.style.transform = `scale(${(1 + (on ? 0.10 : 0) * p).toFixed(3)})`;
          if (on) { c.style.borderColor = 'rgba(8,122,85,.45)'; c.style.background = '#EAF5EF'; }
        });

        // scorecard ring 104.4-106.4 -> 72
        if (el.bigring) {
          const p = S(t, 104.45, 106.4, ez.outCubic);
          el.bigring.style.strokeDashoffset = (503 * (1 - 0.72 * p)).toFixed(1);
          el.bignum.textContent = Math.round(72 * p);
        }
        // evidence bars + rows 106.0-111.7
        el.ebar.forEach((b, i) => {
          const p = S(t, 106.10 + i * 0.62, 107.0 + i * 0.62, ez.outCubic);
          b.style.transform = `scaleX(${(p * [72, 70, 73, 72][i] / 100).toFixed(4)})`;
        });
        el.erow.forEach((r, i) => {
          const p = S(t, 105.9 + i * 0.16, 106.45 + i * 0.16, ez.outCubic);
          put(r, { o: 0.35 + 0.65 * p });
        });
        // QR reveal 115.4-117.4
        if (el.qrsvg) el.qrsvg.style.opacity = S(t, 115.40, 116.3).toFixed(3);
      };
    }
  });
})();
