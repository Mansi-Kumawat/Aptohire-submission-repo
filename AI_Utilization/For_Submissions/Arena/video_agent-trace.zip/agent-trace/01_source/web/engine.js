/* =========================================================================
   AptoHire Film — playback engine
   Deterministic: window.__seekTo(t) fully reconstructs the frame at time t.
   ========================================================================= */
(function () {
  'use strict';
  const { S, put, ez, ico } = AH;
  const TL = window.TL, CAPS = window.CAPTIONS, SCENES = window.SCENES;
  const TOTAL = TL.total_duration;
  const params = new URLSearchParams(location.search);
  const RENDER = params.get('render') === '1';
  const AUTO = params.get('autoplay') === '1';

  const stage = document.getElementById('stage-viewport');
  const capBar = document.getElementById('caption-bar');
  const pill = document.getElementById('stage-portal-pill');
  const actBar = document.querySelector('#stage-act .bar i');
  const actLbl = document.querySelector('#stage-act .lbl');
  const wipe = document.getElementById('scene-wipe');
  const audioEl = document.getElementById('master-audio');

  if (RENDER) document.body.classList.add('render-mode');

  // ---------------- build scenes ----------------
  const starts = TL.scenes.map(s => s.t_start);
  TL.scenes.forEach((sd, i) => {
    if (!SCENES[i]) { console.warn('missing scene', i); return; }
    const root = document.createElement('div');
    root.className = 'scene';
    root.id = sd.id;
    stage.insertBefore(root, document.getElementById('scene-wipe'));
    SCENES[i].root = root;
    SCENES[i].data = sd;
    SCENES[i].build(root);
  });

  // ---------------- port pill / act label ----------------
  function sceneAt(t) {
    let k = 0;
    for (let i = 0; i < starts.length; i++) if (t >= starts[i] - 0.0001) k = i;
    return k;
  }
  let curScene = -1, curPill = '';
  function setScene(i) {
    if (i === curScene) return;
    if (curScene >= 0) SCENES[curScene].root.classList.remove('active');
    curScene = i;
    SCENES[i].root.classList.add('active');
  }
  const ACT_LABEL = ['Act I · Hook', 'Act I · Problem', 'Act II · Solution', 'Act II · Walkthrough',
    'Act II · Walkthrough', 'Act II · Walkthrough', 'Act II · Governance', 'Act III · Philosophy',
    'Act IV · Build', 'Act IV · Architecture', 'Act V · Opportunity', 'Act V · Model', 'Act V · Close'];

  // ---------------- captions ----------------
  let capEl = capBar.firstElementChild || capBar;
  if (!capEl || capEl === capBar) { capEl = document.createElement('span'); capBar.appendChild(capEl); }
  let lastCap = null;
  function setCaption(t) {
    let txt = '';
    for (const sc of TL.scenes) {
      if (t < sc.t_start || t > sc.t_end) continue;
      const cues = CAPS[sc.id] || [];
      for (const c of cues) if (t >= c.s && t <= c.e + 0.001) { txt = c.t; break; }
      break;
    }
    if (txt !== lastCap) {
      lastCap = txt;
      if (txt) capEl.textContent = txt;      // never clear while fading out
      capBar.style.opacity = txt ? '1' : '0';
    }
  }

  // ---------------- signature vertical wipe ----------------
  function setWipe(t, i) {
    if (i === 0) { wipe.style.transform = 'translateY(1120px)'; return; }
    const b = starts[i];
    const inP = S(t, b - 0.52, b + 0.10, ez.inOutCubic);
    const outP = S(t, b + 0.06, b + 0.66, ez.inOutCubic);
    const y = inP < 1 ? 1080 * (1 - inP) : -1080 * outP;
    wipe.style.transform = `translateY(${y.toFixed(1)}px)`;
  }

  // ---------------- master frame ----------------
  // renderAt(): pure drawing for an absolute time (never touches transport state)
  function renderAt(tt) {
    const t = Math.max(0, Math.min(TOTAL, tt));
    const i = sceneAt(t);
    const sd = TL.scenes[i];
    const lt = t - sd.t_start;
    setScene(i);

    // all scenes: hide inactive instantly (display:none), active stays
    SCENES[i].frame(t, lt, sd.duration);
    setWipe(t, i);
    setCaption(t);

    // portal scenes carry their own live-URL rail, so the global pill would collide
    const noPill = ['scene_01', 'scene_04', 'scene_05', 'scene_06', 'scene_07', 'scene_09', 'scene_13'];
    if (pill) {
      const hide = noPill.indexOf(sd.id) >= 0;
      const dark = ['scene_03', 'scene_10'].indexOf(sd.id) >= 0;
      pill.classList.toggle('dark', dark);
      const lbl = pill.querySelector('.lbl');
      if (lbl) lbl.textContent = SCENES[i].portal;
      pill.style.display = hide ? 'none' : 'inline-flex';
    }
    const actEl = document.getElementById('stage-act');
    if (actEl) actEl.style.display = (sd.id === 'scene_04' || sd.id === 'scene_05' || sd.id === 'scene_06' || sd.id === 'scene_07' || sd.id === 'scene_09' || sd.id === 'scene_13') ? 'none' : 'flex';
    if (actBar) actBar.style.transform = `scaleX(${(t / TOTAL).toFixed(4)})`;
    if (actLbl) actLbl.textContent = ACT_LABEL[i] || '';
    return t;
  }

  // External scrub entry point: moves the transport (and the audio clock) as well.
  window.__seekTo = function (tt) {
    const v = Math.max(0, Math.min(TOTAL, tt));
    t = v;
    if (audioEl && !audioEl.paused && Math.abs(audioEl.currentTime - v) > 0.25) audioEl.currentTime = v;
    renderAt(v);
    return v;
  };

  // ---------------- transport ----------------
  let t = 0, playing = false, last = 0, raf = null, userAudio = false;

  function tick(now) {
    if (!playing) return;
    const dt = Math.min(0.12, (now - last) / 1000);
    last = now;
    if (!userAudio && audioEl) {
      // audio is the master clock once it is actually progressing
      const at = audioEl.currentTime;
      if (!audioEl.paused) t = at;
      else t += dt;
    } else t += dt;
    if (t >= TOTAL) { t = TOTAL; renderAt(t); playing = false; syncUI(); return; }
    renderAt(t);
    raf = requestAnimationFrame(tick);
  }
  function render() { renderAt(t); updateFill(); }

  function play() {
    if (playing) return;
    // single-file builds: audio lives in a JS variable so no path is ever resolved
    if (audioEl && !audioEl.getAttribute('src') && window.AUDIO_URI) audioEl.src = window.AUDIO_URI;
    playing = true; last = performance.now();
    if (audioEl) {
      if (Math.abs(audioEl.currentTime - t) > 0.22) audioEl.currentTime = t;
      const p = audioEl.play();
      if (p && p.catch) p.catch(() => { userAudio = true; });
    }
    raf = requestAnimationFrame(tick);
    syncUI();
  }
  function pause() {
    playing = false;
    if (raf) cancelAnimationFrame(raf);
    if (audioEl) audioEl.pause();
    syncUI();
  }
  function seek(v) {
    t = Math.max(0, Math.min(TOTAL, v));
    if (audioEl && !audioEl.paused) audioEl.currentTime = t;
    renderAt(t); updateFill(); syncUI();
  }

  // ---------------- studio UI ----------------
  const fill = document.getElementById('timeline-fill');
  const trackEl = document.getElementById('timeline-track');
  const playBtn = document.getElementById('btn-play');
  const timeLbl = document.getElementById('time-label');
  const chapLbl = document.getElementById('chapter-label');
  function fmt(s) {
    s = Math.max(0, s);
    return `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
  }
  function updateFill() {
    if (fill) fill.style.width = (t / TOTAL * 100).toFixed(3) + '%';
    if (timeLbl) timeLbl.textContent = `${fmt(t)} / ${fmt(TOTAL)}`;
    if (chapLbl) {
      const i = sceneAt(t);
      chapLbl.textContent = `${String(i + 1).padStart(2, '0')} · ${TL.scenes[i].title}`;
      document.querySelectorAll('.jump-btn').forEach(b => b.classList.toggle('active', +b.dataset.scene === i));
    }
  }
  function syncUI() {
    if (playBtn) playBtn.innerHTML = playing ? '❚❚ Pause' : '▶ Play';
    updateFill();
  }
  if (trackEl) {
    trackEl.addEventListener('pointerdown', e => {
      const r = trackEl.getBoundingClientRect();
      seek((e.clientX - r.left) / r.width * TOTAL);
    });
    // scene ticks
    TL.scenes.forEach((s, i) => {
      if (i === 0) return;
      const d = document.createElement('div');
      d.className = 'scene-tick';
      d.style.left = (s.t_start / TOTAL * 100).toFixed(3) + '%';
      trackEl.appendChild(d);
    });
  }
  if (playBtn) playBtn.onclick = () => playing ? pause() : play();
  document.querySelectorAll('.jump-btn').forEach(b => {
    b.onclick = () => {
      const idx = +b.dataset.scene;
      seek(TL.scenes[idx].t_start + 0.05);
      if (!playing) play();
      if (document.body.classList.contains('inspector-open')) closeInspector();
    };
  });

  const gate = document.getElementById('autoplay-gate');
  if (gate) {
    if (RENDER) gate.remove();
    else {
      gate.onclick = () => { gate.classList.add('hidden'); play(); };
      if (AUTO) { /* still needs a gesture for audio; keep the gate visible */ }
    }
  }

  // keyboard
  window.addEventListener('keydown', e => {
    if (e.target.tagName === 'INPUT') return;
    if (e.code === 'Space') { e.preventDefault(); playing ? pause() : play(); }
    else if (e.code === 'ArrowRight') { e.preventDefault(); seek(t + (e.shiftKey ? 5 : 1)); }
    else if (e.code === 'ArrowLeft') { e.preventDefault(); seek(t - (e.shiftKey ? 5 : 1)); }
    else if (e.code === 'Home') { seek(0); }
    else if (e.code === 'KeyC') { document.body.classList.toggle('captions-off'); }
    else if (e.code === 'KeyF') { document.documentElement.requestFullscreen && document.documentElement.requestFullscreen(); }
    else if (e.code === 'KeyI') { toggleInspector(); }
  });

  // ---------------- Portal Inspector ----------------
  const modal = document.getElementById('inspector-modal');
  const inspNav = document.getElementById('inspector-nav');
  const inspView = document.getElementById('inspector-view');
  const GROUP = { public: 'Public site', student: 'Student portal', organization: 'Organization portal', university: 'University portal', admin: 'Admin console' };
  function buildInspector() {
    if (!inspNav) return;
    const groups = {};
    window.INSPECTOR.forEach((s, i) => { (groups[s.portal] = groups[s.portal] || []).push(i); });
    let html = '';
    Object.keys(groups).forEach(p => {
      html += `<div style="font-size:10.5px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#64748B;padding:14px 12px 6px">${GROUP[p] || p}</div>`;
      groups[p].forEach(i => {
        const s = window.INSPECTOR[i];
        html += `<button class="insp-item" data-i="${i}">${s.label}</button>`;
      });
    });
    inspNav.innerHTML = html;
    inspNav.querySelectorAll('.insp-item').forEach(b => { b.onclick = () => showInsp(+b.dataset.i); });
  }
  function showInsp(i) {
    const s = window.INSPECTOR[i];
    if (!s) return;
    inspNav.querySelectorAll('.insp-item').forEach(b => b.classList.toggle('active', +b.dataset.i === i));
    inspView.innerHTML = `
      <div style="display:flex;align-items:center;justify-content:space-between;gap:16px">
        <div>
          <div style="font-size:11px;font-weight:700;letter-spacing:.12em;text-transform:uppercase;color:#6EE7B7">${GROUP[s.portal] || s.portal}</div>
          <div style="font-size:22px;font-weight:700;letter-spacing:-.02em;margin-top:5px">${s.label}</div>
        </div>
        <a href="${s.url}" target="_blank" rel="noopener" style="flex:none;display:inline-flex;align-items:center;gap:7px;padding:9px 15px;border-radius:8px;background:#087A55;color:#fff;font-size:12.5px;font-weight:600;text-decoration:none">Open live portal ↗</a>
      </div>
      <div style="font-family:var(--mono);font-size:11.5px;color:#64748B">${s.url}</div>
      <img src="${(window.ASSET_URI && window.ASSET_URI[s.file]) || ('assets/' + s.file)}" alt="${s.label}">
      <div style="font-size:12px;color:#64748B;line-height:1.5">Captured live from the deployed prototype · 1440×810 · October 2026 · sample data, fictional institutions.</div>`;
  }
  function openInspector() { modal.classList.add('open'); document.body.classList.add('inspector-open'); pause(); showInsp(0); }
  function closeInspector() { modal.classList.remove('open'); document.body.classList.remove('inspector-open'); }
  function toggleInspector() { modal.classList.contains('open') ? closeInspector() : openInspector(); }
  if (modal) {
    modal.addEventListener('click', e => { if (e.target === modal) closeInspector(); });
    document.querySelectorAll('[data-open-inspector]').forEach(b => b.onclick = openInspector);
    const cl = document.getElementById('inspector-close');
    if (cl) cl.onclick = closeInspector;
  }
  buildInspector();

  // ---------------- fit stage to viewport ----------------
  function fit() {
    if (RENDER) {
      stage.style.transform = 'none';
      var m = document.getElementById('stage-mount');
      if (m) { m.style.inset = '0'; m.style.alignItems = 'flex-start'; m.style.justifyContent = 'flex-start'; }
      return;
    }
    const mount = document.getElementById('stage-mount');
    const availH = (mount ? mount.clientHeight : window.innerHeight) - 24;
    const availW = (mount ? mount.clientWidth : window.innerWidth) - 32;
    const s = Math.max(0.12, Math.min(availW / 1920, availH / 1080));
    stage.style.transform = `scale(${s})`;
    stage.style.width = '1920px';
    stage.style.height = '1080px';
    stage.style.margin = '0';
    // centre the scaled 1920x1080 box inside the mount
    stage.style.position = 'absolute';
    stage.style.left = '50%';
    stage.style.top = '50%';
    stage.style.transformOrigin = 'center center';
    stage.style.transform = `translate(-50%,-50%) scale(${s})`;
  }
  window.addEventListener('resize', fit);
  fit();

  // ---------------- public API for headless rendering ----------------
  window.__film = { seek, play, pause, get t() { return t; }, total: TOTAL, sceneAt };

  // ---------------- boot ----------------
  t = 0; renderAt(0); updateFill();
  if (!RENDER) document.body.classList.add('studio');
  if (params.get('t')) seek(parseFloat(params.get('t')) || 0);
  if (params.get('captions') === '0') document.body.classList.add('captions-off');
  if (RENDER) { document.body.classList.remove('studio'); fit(); }
  window.__ready = true;
})();
