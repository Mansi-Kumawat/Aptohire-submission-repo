import os, json
import numpy as np
from scipy.io import wavfile

SR=44100
WAV_DIR="project/audio_wav"

def load_wav(name):
    sr,d = wavfile.read(os.path.join(WAV_DIR, name+".wav"))
    x = d.astype(np.float32)/32768.0
    idx=np.where(np.abs(x)>0.0025)[0]
    s=max(0,idx[0]-int(0.05*SR)); e=min(len(x),idx[-1]+int(0.08*SR))
    return x[s:e], s/SR

def split_at_best_pause(x, target_ratio):
    win=int(0.025*SR); n_win=len(x)//win
    rms=np.array([np.sqrt(np.mean(x[i*win:(i+1)*win]**2)) for i in range(n_win)])
    kernel=np.ones(9)/9.0
    s_rms=np.convolve(rms,kernel,mode="same")
    best=-1e9; best_idx=int(n_win*target_ratio)
    lo=int(n_win*max(0.25,target_ratio-0.16)); hi=int(n_win*min(0.75,target_ratio+0.16))
    for i in range(lo,hi):
        sc=-s_rms[i]-abs((i/n_win)-target_ratio)*0.04
        if sc>best: best=sc; best_idx=i
    return best_idx*win/SR

for name, ratio in [("vo_08_09_why_build",180/412.0),("vo_10_11_arch_market",180/387.0),("vo_12_13_roadmap_close",173/358.0)]:
    x, lead = load_wav(name)
    cut = split_at_best_pause(x, ratio)
    print(name, "lead_trim=%.3f"%lead, "cut_in_trimmed=%.3f"%cut, "dur=%.3f"%(len(x)/SR))
