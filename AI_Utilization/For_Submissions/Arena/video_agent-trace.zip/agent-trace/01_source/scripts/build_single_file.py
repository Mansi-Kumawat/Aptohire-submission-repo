import os, re, base64, subprocess, json

WEB = "project/web"
OUT = "project/AptoHire_Interactive_Film.html"

html = open(os.path.join(WEB, "index.html"), encoding="utf-8").read()
fonts = open(os.path.join(WEB, "fonts.css"), encoding="utf-8").read()
styles = open(os.path.join(WEB, "styles.css"), encoding="utf-8").read()
film  = open(os.path.join(WEB, "film.css"), encoding="utf-8").read()
data  = open(os.path.join(WEB, "data.js"), encoding="utf-8").read()
core  = open(os.path.join(WEB, "core.js"), encoding="utf-8").read()
sa    = open(os.path.join(WEB, "scenes_a.js"), encoding="utf-8").read()
sb    = open(os.path.join(WEB, "scenes_b.js"), encoding="utf-8").read()
sc    = open(os.path.join(WEB, "scenes_c.js"), encoding="utf-8").read()
eng   = open(os.path.join(WEB, "engine.js"), encoding="utf-8").read()

# ---- 1. re-encode the soundtrack a little lighter for the single-file build ----
tmp_mp3 = "/tmp/film_audio.m4a"
subprocess.run(["ffmpeg", "-y", "-v", "error", "-i", os.path.join(WEB, "assets/master_soundtrack.mp3"),
                "-c:a", "aac", "-b:a", "128k", "-ac", "2", tmp_mp3], check=True)
audio_b64 = base64.b64encode(open(tmp_mp3, "rb").read()).decode()
print("audio", round(len(audio_b64) / 1e6, 2), "MB base64")

# ---- 2. inline every image asset as a data URI ----
assets = {}
for f in sorted(os.listdir(os.path.join(WEB, "assets"))):
    if f.endswith(".webp"):
        raw = open(os.path.join(WEB, "assets", f), "rb").read()
        assets[f] = "data:image/webp;base64," + base64.b64encode(raw).decode()
print("images", len(assets), "total", round(sum(len(v) for v in assets.values()) / 1e6, 2), "MB")

def inline_assets(text):
    for name, uri in assets.items():
        text = text.replace(f"assets/{name}", uri)
    return text

def patch_dynamic_imgs(text):
    # 'assets/${p2[0]}' inside template literals -> resolved from the URI map at runtime
    text = text.replace('src="assets/${p2[0]}"', 'src="${(window.ASSET_URI && window.ASSET_URI[p2[0]]) || (\'assets/\' + p2[0])}"')
    return text

asset_uri_js = ("window.ASSET_URI = " + json.dumps(assets) + ";\n"
                "window.AUDIO_URI = " + json.dumps("data:audio/mp4;base64," + audio_b64) + ";\n")
scripts = "\n".join([asset_uri_js, data, core, sa, sb, sc, eng])
scripts = patch_dynamic_imgs(inline_assets(scripts))

# ---- 3. assemble ----
body = html

# strip external css/js links & scripts, we inject inline
body = re.sub(r'<audio id="master-audio"[^>]*></audio>\s*', "", body)
body = re.sub(r'<link rel="stylesheet"[^>]*>\s*', "", body)
body = re.sub(r'<script src="[^"]+"></script>\s*', "", body)

# single-file: no external MP4 to download yet
body = body.replace(
    '<a class="action-btn" id="btn-mp4" href="AptoHire_Walkthrough_Motion_Video.mp4" download>⤓ Download MP4</a>',
    '<button class="action-btn" data-open-inspector>▤ All 22 screens</button>')

# the inspector thumbs are file references inside JS -> inline them (already done in scripts)

body = body.replace("</head>", f"""<style>
{fonts}
</style>
<style>
{styles}
</style>
<style>
{film}
</style>
<style>
  /* single-file build: no filesystem, no network */
  body {{ background: #070A10; }}
  #stage-mount {{ background: #070A10; }}
</style>
</head>""")

body = body.replace("</body>", f"""<audio id="master-audio" preload="auto"></audio>
<script>
{scripts}
</script>
</body>""")

# remove the now-duplicated audio tag from the original markup (empty one)
body = body.replace('<audio id="master-audio" src="" preload="auto"></audio>', "")

body = patch_dynamic_imgs(inline_assets(body))
open(OUT, "w", encoding="utf-8").write(body)
print("wrote", OUT, round(os.path.getsize(OUT) / 1e6, 2), "MB")
