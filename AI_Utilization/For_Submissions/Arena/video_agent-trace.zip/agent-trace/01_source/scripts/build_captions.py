import json, re

wt  = json.load(open("project/audio/word_timing.json"))
tl  = json.load(open("project/timeline.json"))

LEAD = {"vo_01_hook":0.050,"vo_02_problem":0.050,"vo_03_intro":0.050,"vo_04_student":0.050,
        "vo_05_organization":0.050,"vo_06_university":0.050,"vo_07_admin":0.050,
        "vo_08_09_why_build":0.066,"vo_10_11_arch_market":0.072,"vo_12_13_roadmap_close":0.063}

ASSIGN = {1:[("vo_01_hook",0,None)],2:[("vo_02_problem",0,None)],3:[("vo_03_intro",0,None)],
  4:[("vo_04_student",0,None)],5:[("vo_05_organization",0,None)],6:[("vo_06_university",0,None)],
  7:[("vo_07_admin",0,None)],8:[("vo_08_09_why_build",0,10.870)],9:[("vo_08_09_why_build",10.870,None)],
  10:[("vo_10_11_arch_market",0,10.795)],11:[("vo_10_11_arch_market",10.795,None)],
  12:[("vo_12_13_roadmap_close",0,12.244)],13:[("vo_12_13_roadmap_close",12.244,None)]}

FIX = {"aptohire":"AptoHire","next.js":"Next.js","node.js":"Node.js","gemini":"Gemini","claude":"Claude",
 "gpt":"GPT","react":"React","typescript":"TypeScript","ai":"AI","qr":"QR","k7f2":"K7F2","arena":"Arena",
 "ai-assisted":"AI-assisted","ai-use":"AI-use","co-founders":"co-founders","front-end":"front-end",
 "multi-factor":"multi-factor","row-level":"row-level","append-only":"append-only","two-week":"two-week",
 "three-minute":"three-minute","30-day":"30-day","skills-first":"skills-first","production-grade":"production-grade"}

def merge(raw):
    """Rejoin ASR fragments: hyphen splits, '45'+',000', 'Apto'+'Hire', 'Chat'+'GPT', '86'+'%'."""
    out=[]
    for s,e,t in raw:
        t=t.strip()
        if not t: continue
        prev = re.sub(r"[^\w]","",out[-1][2]).lower() if out else ""
        if out and (t.startswith("-") or re.fullmatch(r"[,.]\d{3}", t) or t=="%" or re.match(r"^\.[A-Za-z]{2,}", t)):
            out[-1][1]=e; out[-1][2]=out[-1][2]+t
        elif out and prev=="apto" and t.lower().strip(".,")=="hire":
            out[-1][1]=e; out[-1][2]="AptoHire"
        elif out and prev=="chat" and t.lower().strip(".,")=="gpt":
            out[-1][1]=e; out[-1][2]="ChatGPT"+("," if t.endswith(",") else "")
        elif out and prev=="row" and t.lower().strip(".,")=="level":
            out[-1][1]=e; out[-1][2]="row-level"+("," if t.endswith(",") else "")
        else:
            out.append([s,e,t])
    return out

def norm(tok):
    trail=""
    core=tok
    while core and core[-1] in ".,!?;:": trail=core[-1]+trail; core=core[:-1]
    key=core.lower()
    rep=FIX.get(key, core)
    if rep==core and key.endswith("s") and key[:-1] in FIX: rep=FIX[key[:-1]]+"s"
    if rep.lower()=="chatgpt": rep="ChatGPT"
    return rep+trail

# ---------------- DP segmentation ----------------
TARGET=40.0; MAXLEN=52
def segment(toks):
    """toks: [{s,e,t,brk,gap_after}] -> list of index ranges minimising awkwardness."""
    n=len(toks)
    INF=1e15
    best=[INF]*(n+1); back=[-1]*(n+1); best[0]=0.0
    for i in range(n):
        if best[i]>=INF: continue
        ln=0
        for j in range(i,n):
            ln += len(toks[j]["t"].rstrip(".,!?;:")) + (1 if j>i else 0)
            if ln>MAXLEN: break
            dur = toks[j]["e"]-toks[i]["s"]
            if dur>4.4: break
            if j<n-1:
                g=toks[j]["gap_after"]; b=toks[j]["brk"]
                if b in ".!?": cost=0.0
                elif b in ",;:": cost=26.0
                elif g>=0.30: cost=8.0
                elif g>=0.16: cost=45.0
                else: cost=520.0
            else:
                cost=-140.0     # strong reward for ending the clip here
            if dur<0.55: cost+=90.0
            cand = best[i] + ((ln-TARGET)**2)*0.34 + cost
            if cand<best[j+1]:
                best[j+1]=cand; back[j+1]=i
    segs=[]; j=n
    while j>0:
        i=back[j]; segs.append((i,j-1)); j=i
    return list(reversed(segs))

def sentence_cap(txt, prev):
    if not prev: txt = txt[0].upper()+txt[1:]
    return txt

scene_cues={}
for sc in tl["scenes"]:
    idx=sc["index"]; vo_start=sc["vo_start"]; cues=[]
    for clip, s_cut, e_cut in ASSIGN[idx]:
        lead=LEAD[clip]
        raw=[w for w in wt[clip] if w[0]>=s_cut-0.001 and (e_cut is None or w[0]<e_cut-0.001)]
        words=merge(raw)
        toks=[]
        for k,(s,e,t) in enumerate(words):
            nt=norm(t)
            gap = (words[k+1][0]-e) if k+1<len(words) else 9.0
            brk = nt[-1] if nt and nt[-1] in ".,!?;:" else ""
            toks.append({"s":round(s-s_cut+vo_start+lead,3),"e":round(e-s_cut+vo_start+lead,3),
                         "t":nt,"brk":brk,"gap_after":gap})
        if not toks: continue
        for (a,b) in segment(toks):
            parts=[toks[k]["t"] for k in range(a,b+1)]
            txt=" ".join(parts)
            new_sent = (a==0) or (toks[a-1]["brk"] in ".!?")
            if new_sent and txt:
                txt=txt[0].upper()+txt[1:]
            txt=txt.replace("AptoHire Hire","AptoHire").replace("Apto Hire","AptoHire")
            txt=txt.replace("next.js","Next.js").replace("node.js","Node.js")
            txt=re.sub(r"\s+([,.;:!?])",r"\1",txt)
            txt=re.sub(r"\s+"," ",txt).strip()
            txt=txt.replace(" ,",",").replace(" .",".")
            cues.append({"s":toks[a]["s"],"e":round(toks[b]["e"],3),"t":txt})
    for i,c in enumerate(cues):
        if c["e"]-c["s"]<0.85: c["e"]=round(c["s"]+0.85,3)
        if i>0 and c["s"]<=cues[i-1]["e"]:
            mid=(cues[i-1]["e"]+c["s"])/2
            cues[i-1]["e"]=round(mid-0.02,3); c["s"]=round(mid+0.02,3)
    for c in cues:
        c["s"]=max(c["s"],round(sc["t_start"]+0.15,3)); c["e"]=min(c["e"],round(sc["t_end"]-0.08,3))
    scene_cues[sc["id"]]=cues

json.dump(scene_cues, open("project/captions.json","w"), indent=1)
print("cues:",sum(len(v) for v in scene_cues.values()))
for sc in tl["scenes"]:
    print(f"\n--- {sc['id']} {sc['title']} ---")
    for c in scene_cues[sc["id"]]:
        print(f"  [{c['s']:7.2f} -> {c['e']:7.2f}] {len(c['t']):2d} | {c['t']}")

# ---------------- Typography pass: subtitle conventions ----------------
PROPER = {"aptohire":"AptoHire","react":"React","typescript":"TypeScript","next.js":"Next.js",
 "node.js":"Node.js","gemini":"Gemini","claude":"Claude","chatgpt":"ChatGPT","arena":"Arena",
 "ai":"AI","qr":"QR","k7f2":"K7F2","october":"October","indian":"Indian","india":"India",
 "tpo":"TPO","mba":"MBA","ui":"UI","ux":"UX","api":"API","sql":"SQL","saas":"SaaS",
 "bengaluru":"Bengaluru","jaipur":"Jaipur",
 "ai-use":"AI-use","ai-assisted":"AI-assisted","skills-first":"skills-first"}

PHRASE = [("skills first","skills-first"),("production grade","production-grade"),
          ("front end","front-end"),("multi factor","multi-factor"),("append only","append-only"),
          ("row level","row-level"),("ai use","AI-use"),("ai assisted","AI-assisted"),
          ("three minute","three-minute"),("two week","two-week"),("30 day","30-day"),
          ("co founders","co-founders"),("chat gpt","ChatGPT")]

ENDERS = ".!?"

def retype(txt):
    t = txt
    for a,b in PHRASE: t = re.sub(a, b, t, flags=re.I)
    words = [w for w in t.split(" ") if w]
    out = []
    cap_next = True
    for w in words:
        trail = ""
        core = w
        while core and core[-1] in ".,!?;:": trail = core[-1]+trail; core = core[:-1]
        key = core.lower()
        if key in PROPER:
            disp = PROPER[key]
        elif cap_next or (core[:1].isupper() and core.isupper()):
            disp = core[:1].upper()+core[1:]
        else:
            disp = core[:1].lower()+core[1:] if core else core
        out.append(disp+trail)
        cap_next = bool(trail) and trail[-1] in ENDERS
    return " ".join(out)

for sid, cues in scene_cues.items():
    for c in cues:
        c["t"] = retype(c["t"])

json.dump(scene_cues, open("project/captions.json","w"), indent=1)
print("\n\n================ FINAL CAPTIONS ================")
for sc in tl["scenes"]:
    print(f"\n--- {sc['id']} {sc['title']} ---")
    for c in scene_cues[sc["id"]]:
        print(f"  [{c['s']:7.2f} -> {c['e']:7.2f}] {len(c['t']):2d} | {c['t']}")
