import os, json, subprocess
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, lfilter

SR = 44100
WAV_DIR = "project/audio_wav"
OUT_DIR = "project/audio"
os.makedirs(OUT_DIR, exist_ok=True)

def load_wav(name):
    sr, d = wavfile.read(os.path.join(WAV_DIR, f"{name}.wav"))
    assert sr == SR
    x = d.astype(np.float32) / 32768.0
    # Trim leading/trailing near-silence (> -52dB)
    idx = np.where(np.abs(x) > 0.0025)[0]
    if len(idx) > 0:
        s = max(0, idx[0] - int(0.05 * SR))
        e = min(len(x), idx[-1] + int(0.08 * SR))
        x = x[s:e]
    return x

def split_at_best_pause(x, target_ratio):
    win = int(0.025 * SR)
    n_win = len(x) // win
    rms = np.array([np.sqrt(np.mean(x[i*win:(i+1)*win]**2)) for i in range(n_win)])
    # Score silence windows near target_ratio
    best_score = -1e9
    best_idx = int(n_win * target_ratio)
    lo = int(n_win * max(0.25, target_ratio - 0.16))
    hi = int(n_win * min(0.75, target_ratio + 0.16))
    # Smooth rms over 7 windows (~175ms) to find widest quiet gap
    kernel = np.ones(9) / 9.0
    s_rms = np.convolve(rms, kernel, mode="same")
    for i in range(lo, hi):
        dist_pen = abs((i / n_win) - target_ratio) * 0.04
        score = -s_rms[i] - dist_pen
        if score > best_score:
            best_score = score
            best_idx = i
    cut = best_idx * win
    a = x[:cut]
    b = x[cut:]
    # Trim edges cleanly
    for arr_idx, arr in enumerate([a, b]):
        nz = np.where(np.abs(arr) > 0.0025)[0]
        if len(nz) > 0:
            s = max(0, nz[0] - int(0.04 * SR))
            e = min(len(arr), nz[-1] + int(0.06 * SR))
            if arr_idx == 0: a = arr[s:e]
            else: b = arr[s:e]
    return a, b

# 1. Prepare 13 clean per-scene VO arrays
vo_01 = load_wav("vo_01_hook")
vo_02 = load_wav("vo_02_problem")
vo_03 = load_wav("vo_03_intro")
vo_04 = load_wav("vo_04_student")
vo_05 = load_wav("vo_05_organization")
vo_06 = load_wav("vo_06_university")
vo_07 = load_wav("vo_07_admin")
vo_08, vo_09 = split_at_best_pause(load_wav("vo_08_09_why_build"), 180 / 412.0)
vo_10, vo_11 = split_at_best_pause(load_wav("vo_10_11_arch_market"), 180 / 387.0)
vo_12, vo_13 = split_at_best_pause(load_wav("vo_12_13_roadmap_close"), 173 / 358.0)

scene_defs = [
    ("scene_01", "Act I · Hook", "The Hook", "public", vo_01, 0.55, 1.90),
    ("scene_02", "Act I · Problem", "The Visibility Gap", "public", vo_02, 0.45, 1.75),
    ("scene_03", "Act II · Solution", "Introducing AptoHire", "public", vo_03, 0.90, 1.80),
    ("scene_04", "Act II · Walkthrough", "Student Portal Walkthrough", "student", vo_04, 0.45, 1.80),
    ("scene_05", "Act II · Walkthrough", "Organization Portal Walkthrough", "organization", vo_05, 0.45, 1.80),
    ("scene_06", "Act II · Walkthrough", "University TPO Portal Walkthrough", "university", vo_06, 0.45, 1.80),
    ("scene_07", "Act II · Walkthrough", "Admin & Governance Console", "admin", vo_07, 0.45, 1.80),
    ("scene_08", "Act III · Philosophy", "Why AptoHire Is Different", "philosophy", vo_08, 0.45, 2.20),
    ("scene_09", "Act IV · Build Story", "Behind the Build", "build", vo_09, 0.45, 1.65),
    ("scene_10", "Act IV · Architecture", "System Architecture & Locks", "architecture", vo_10, 0.45, 1.85),
    ("scene_11", "Act V · Opportunity", "The Market Opportunity", "market", vo_11, 0.45, 1.75),
    ("scene_12", "Act V · Roadmap", "Business Model & Roadmap", "roadmap", vo_12, 0.45, 1.75),
    ("scene_13", "Act V · Close", "Prove Skills. Get Hired.", "closing", vo_13, 0.50, 4.20),
]

timeline = []
cur_t = 0.0
for idx, (sid, act, title, portal, vo_arr, pre_pad, post_pad) in enumerate(scene_defs, 1):
    vo_dur = len(vo_arr) / SR
    t_start = round(cur_t, 3)
    vo_start = round(cur_t + pre_pad, 3)
    vo_end = round(vo_start + vo_dur, 3)
    t_end = round(vo_end + post_pad, 3)
    timeline.append({
        "index": idx,
        "id": sid,
        "act": act,
        "title": title,
        "portal": portal,
        "t_start": t_start,
        "vo_start": vo_start,
        "vo_end": vo_end,
        "t_end": t_end,
        "duration": round(t_end - t_start, 3),
        "vo_duration": round(vo_dur, 3)
    })
    cur_t = t_end

total_dur = round(cur_t, 3)
total_samples = int(np.ceil(total_dur * SR))
print(f"Total Film Duration: {total_dur:.2f}s ({int(total_dur//60)}:{total_dur%60:05.2f})")
for sc in timeline:
    print(f"  {sc['index']:02d} {sc['id']} [{sc['t_start']:6.2f}s -> {sc['t_end']:6.2f}s] (dur={sc['duration']:5.2f}s, vo={sc['vo_duration']:5.2f}s) {sc['title']}")

with open("project/timeline.json", "w") as f:
    json.dump({"total_duration": total_dur, "scenes": timeline}, f, indent=2)

# 2. Assemble full VO stereo buffer + voice envelope for sidechain ducking
vo_mono = np.zeros(total_samples, dtype=np.float32)
for (_, _, _, _, vo_arr, _, _), sc in zip(scene_defs, timeline):
    s_i = int(sc["vo_start"] * SR)
    # Apply 15ms fade in/out to avoid any zero-crossing click
    fade = min(int(0.015 * SR), len(vo_arr)//4)
    arr = vo_arr.copy()
    arr[:fade] *= np.linspace(0, 1, fade)
    arr[-fade:] *= np.linspace(1, 0, fade)
    vo_mono[s_i:s_i+len(arr)] += arr

# Gentle warm low-shelf boost (~200Hz) on VO per Section 7
b_lp, a_lp = butter(2, 220.0 / (SR / 2), btype="low")
vo_warm = vo_mono + 0.18 * lfilter(b_lp, a_lp, vo_mono)
# Soft saturation / light leveling
vo_warm = np.tanh(vo_warm * 1.18) / 1.12

# Compute smooth VO activity envelope for sidechain ducking (-7dB when speaking)
env_win = int(0.08 * SR)
vo_abs = np.abs(vo_warm)
# Fast attack, smooth 350ms release
duck_env = np.zeros(total_samples, dtype=np.float32)
step = int(0.02 * SR)
cur_env = 0.0
for i in range(0, total_samples, step):
    chunk_rms = np.sqrt(np.mean(vo_abs[i:i+step]**2)) if i+step <= total_samples else 0.0
    target = 1.0 if chunk_rms > 0.012 else 0.0
    alpha = 0.45 if target > cur_env else 0.08
    cur_env = cur_env + alpha * (target - cur_env)
    duck_env[i:i+step] = cur_env

# 3. Synthesize Evolving Musical Score (Section 7 spec: Piano -> Swell -> Pulse -> Thesis -> Tech Pad -> Pulse -> Resolution)
music_L = np.zeros(total_samples, dtype=np.float32)
music_R = np.zeros(total_samples, dtype=np.float32)

def note_freq(midi):
    return 440.0 * (2.0 ** ((midi - 69) / 12.0))

def add_felt_piano(buf_L, buf_R, t0, midi, dur, vel=0.12, pan=0.0):
    s_i = int(t0 * SR)
    if s_i >= total_samples or s_i < 0: return
    n = min(int(dur * SR), total_samples - s_i)
    if n <= 100: return
    t = np.arange(n, dtype=np.float32) / SR
    f = note_freq(midi)
    # Warm felt piano partials with natural decay
    env = (1.0 - np.exp(-t * 95.0)) * (0.68 * np.exp(-t * 1.35) + 0.32 * np.exp(-t * 0.45))
    env[-min(int(0.08*SR), n):] *= np.linspace(1, 0, min(int(0.08*SR), n))
    sig = (
        1.00 * np.sin(2 * np.pi * f * t) +
        0.38 * np.sin(2 * np.pi * 2.001 * f * t) * np.exp(-t * 2.2) +
        0.14 * np.sin(2 * np.pi * 3.003 * f * t) * np.exp(-t * 3.8) +
        0.05 * np.sin(2 * np.pi * 4.006 * f * t) * np.exp(-t * 5.5)
    ) * env * vel
    gL = np.sqrt(0.5 * (1.0 - pan))
    gR = np.sqrt(0.5 * (1.0 + pan))
    buf_L[s_i:s_i+n] += sig * gL
    buf_R[s_i:s_i+n] += sig * gR

def add_warm_pad(buf_L, buf_R, t0, dur, midis, vel=0.055):
    s_i = int(t0 * SR)
    if s_i >= total_samples: return
    n = min(int(dur * SR), total_samples - s_i)
    if n <= 200: return
    t = np.arange(n, dtype=np.float32) / SR
    atk = min(int(0.9 * SR), n // 3)
    rel = min(int(1.2 * SR), n // 3)
    env = np.ones(n, dtype=np.float32)
    if atk > 0: env[:atk] = np.linspace(0, 1, atk) ** 1.5
    if rel > 0: env[-rel:] = np.linspace(1, 0, rel) ** 1.5
    sigL = np.zeros(n, dtype=np.float32)
    sigR = np.zeros(n, dtype=np.float32)
    for idx, m in enumerate(midis):
        f = note_freq(m)
        det = 1.0025 if idx % 2 == 0 else 0.9975
        sigL += (np.sin(2 * np.pi * f * t) + 0.25 * np.sin(2 * np.pi * 2 * f * t)) * vel
        sigR += (np.sin(2 * np.pi * f * det * t + 0.4) + 0.25 * np.sin(2 * np.pi * 2 * f * det * t + 0.4)) * vel
    buf_L[s_i:s_i+n] += sigL * env
    buf_R[s_i:s_i+n] += sigR * env

def add_pulse_pluck(buf_L, buf_R, t0, midi, vel=0.05, pan=0.0):
    s_i = int(t0 * SR)
    if s_i >= total_samples: return
    n = min(int(0.42 * SR), total_samples - s_i)
    if n <= 50: return
    t = np.arange(n, dtype=np.float32) / SR
    f = note_freq(midi)
    env = (1.0 - np.exp(-t * 220.0)) * np.exp(-t * 9.5)
    sig = (np.sin(2 * np.pi * f * t) + 0.45 * np.sin(2 * np.pi * 2 * f * t) * np.exp(-t * 18.0)) * env * vel
    buf_L[s_i:s_i+n] += sig * np.sqrt(0.5 * (1.0 - pan))
    buf_R[s_i:s_i+n] += sig * np.sqrt(0.5 * (1.0 + pan))

sc_map = {s["id"]: s for s in timeline}

# Scene 1: Sparse contemplative low piano & subtle cold string pad, silent fade to black at end
s1 = sc_map["scene_01"]
add_warm_pad(music_L, music_R, s1["t_start"], s1["duration"] - 2.2, [47, 54, 59], vel=0.032) # Bm hollow pad
for bt, m in [(1.2, 59), (4.8, 62), (8.6, 57), (12.8, 54), (17.2, 59), (20.8, 50)]:
    if s1["t_start"] + bt < s1["vo_end"] - 0.5:
        add_felt_piano(music_L, music_R, s1["t_start"] + bt, m, 3.4, vel=0.085, pan=-0.15)

# Scene 2: Minimal felt piano motif (Bm -> G -> D -> A), still no pulse
s2 = sc_map["scene_02"]
chords_s2 = [([47, 54, 62], 66), ([43, 50, 59], 62), ([50, 57, 62], 69), ([45, 52, 57], 64)]
t_cursor = s2["t_start"] + 0.4
idx_c = 0
while t_cursor < s2["t_end"] - 1.5:
    ch, top = chords_s2[idx_c % len(chords_s2)]
    for j, n_m in enumerate(ch):
        add_felt_piano(music_L, music_R, t_cursor + j * 0.12, n_m, 3.6, vel=0.065, pan=-0.2 + 0.2*j)
    add_felt_piano(music_L, music_R, t_cursor + 1.8, top, 2.4, vel=0.075, pan=0.22)
    t_cursor += 3.8
    idx_c += 1

# Scene 3: THE ONE DELIBERATE DYNAMIC SWELL on Logo Lock (s3.t_start + 0.75s), then 96 BPM electronic pulse!
s3 = sc_map["scene_03"]
logo_lock_t = s3["t_start"] + 0.75
# Sub-bass + warm Dmaj9 bloom hit
s_hit = int(logo_lock_t * SR)
n_hit = min(int(3.8 * SR), total_samples - s_hit)
t_h = np.arange(n_hit, dtype=np.float32) / SR
sub_swell = (np.sin(2 * np.pi * note_freq(38) * t_h) * np.exp(-t_h * 1.4) * 0.26 +
             np.sin(2 * np.pi * note_freq(50) * t_h) * np.exp(-t_h * 1.8) * 0.16) * (1.0 - np.exp(-t_h * 45.0))
music_L[s_hit:s_hit+n_hit] += sub_swell
music_R[s_hit:s_hit+n_hit] += sub_swell
for j, m in enumerate([50, 57, 62, 66, 69]): # Dmaj9
    add_felt_piano(music_L, music_R, logo_lock_t + j * 0.05, m, 4.2, vel=0.105, pan=-0.3 + 0.15*j)

# Continuous 96 BPM (beat = 0.625s, 8th = 0.3125s) evolving score from Scene 3 lock through Scene 13!
beat_s = 60.0 / 96.0 # 0.625s
bar_s = beat_s * 4.0 # 2.5s
prog_bright = [
    ([50, 57, 66], [62, 66, 69, 74, 69, 66, 62, 66]), # Dmaj7
    ([45, 52, 61], [61, 64, 69, 73, 69, 64, 61, 64]), # A
    ([47, 54, 62], [62, 66, 69, 73, 69, 66, 62, 66]), # Bm7
    ([43, 50, 59], [59, 62, 67, 71, 67, 62, 59, 62]), # Gmaj7
]
prog_tech = [
    ([47, 54, 61], [61, 66, 69, 66, 61, 66, 69, 66]), # Bm9 dark
    ([43, 50, 57], [57, 62, 66, 62, 57, 62, 66, 62]), # Gmaj9 dark
]

bar_t = logo_lock_t + 1.2
bar_idx = 0
s8 = sc_map["scene_08"]
s9 = sc_map["scene_09"]
s10 = sc_map["scene_10"]
s11 = sc_map["scene_11"]
s13 = sc_map["scene_13"]

while bar_t < s13["vo_end"] - 0.5:
    in_tech = (s9["t_start"] <= bar_t < s11["t_start"])
    in_thesis = (s8["t_start"] <= bar_t < s9["t_start"])
    in_close = (bar_t >= s13["t_start"])

    if in_tech:
        pad_notes, arp_notes = prog_tech[bar_idx % len(prog_tech)]
        add_warm_pad(music_L, music_R, bar_t, bar_s * 1.08, pad_notes, vel=0.048)
        # Subtle sparse technical pulse (quarter notes only)
        for q in range(4):
            add_pulse_pluck(music_L, music_R, bar_t + q * beat_s, arp_notes[q*2], vel=0.026, pan=(-0.25 if q%2==0 else 0.25))
    else:
        pad_notes, arp_notes = prog_bright[bar_idx % len(prog_bright)]
        pad_vel = 0.052 if in_thesis or in_close else 0.042
        add_warm_pad(music_L, music_R, bar_t, bar_s * 1.05, pad_notes, vel=pad_vel)
        # Soft sub-bass heartbeat on beat 1 and beat 3
        add_pulse_pluck(music_L, music_R, bar_t, pad_notes[0] - 12, vel=0.065, pan=0.0)
        add_pulse_pluck(music_L, music_R, bar_t + 2 * beat_s, pad_notes[0] - 12, vel=0.052, pan=0.0)
        # 8th-note electronic pulse arpeggio
        arp_vel = 0.036 if not in_thesis else 0.042
        for e in range(8):
            pan = -0.32 + 0.64 * (e % 2)
            add_pulse_pluck(music_L, music_R, bar_t + e * (beat_s / 2.0), arp_notes[e], vel=arp_vel, pan=pan)
        # Reunite felt piano motif in Scene 8 (thesis) and Scene 13 (closing)!
        if in_thesis or in_close:
            add_felt_piano(music_L, music_R, bar_t, arp_notes[3], 2.2, vel=0.072, pan=-0.18)
            add_felt_piano(music_L, music_R, bar_t + 2 * beat_s, arp_notes[1], 1.8, vel=0.062, pan=0.18)

    bar_t += bar_s
    bar_idx += 1

# Final warm D-major resolution chord right as Scene 13 VO finishes ("Get Hired.")
final_chord_t = s13["vo_end"] - 0.15
for j, m in enumerate([38, 50, 57, 62, 66, 74]):
    add_felt_piano(music_L, music_R, final_chord_t + j * 0.055, m, 3.4, vel=0.088, pan=-0.25 + 0.1*j)

# Apply smooth sidechain ducking (-7.5dB -> linear 0.42x when VO speaks, 1.0x in pauses)
duck_gain = 1.0 - 0.58 * duck_env
music_L *= duck_gain
music_R *= duck_gain

# 4. Build Reusable SFX Library & Place Scene-Synced Cues (Section 7)
sfx_L = np.zeros(total_samples, dtype=np.float32)
sfx_R = np.zeros(total_samples, dtype=np.float32)

def place_sfx(t0, sig, pan=0.0):
    s_i = int(t0 * SR)
    if s_i < 0 or s_i >= total_samples: return
    n = min(len(sig), total_samples - s_i)
    sfx_L[s_i:s_i+n] += sig[:n] * np.sqrt(0.5 * (1.0 - pan))
    sfx_R[s_i:s_i+n] += sig[:n] * np.sqrt(0.5 * (1.0 + pan))

def make_ui_tick():
    t = np.arange(int(0.032 * SR), dtype=np.float32) / SR
    return (np.sin(2 * np.pi * 2400 * t) * np.exp(-t * 190) + 0.5 * np.sin(2 * np.pi * 1450 * t) * np.exp(-t * 140)) * 0.11

def make_verified_chime():
    t = np.arange(int(0.65 * SR), dtype=np.float32) / SR
    n1 = np.sin(2 * np.pi * 880.0 * t) * np.exp(-t * 8.0)
    t2 = np.maximum(0.0, t - 0.085)
    n2 = (t >= 0.085) * (np.sin(2 * np.pi * 1479.98 * t2) + 0.35 * np.sin(2 * np.pi * 2959.96 * t2)) * np.exp(-t2 * 5.5)
    return (n1 * 0.55 + n2 * 0.85) * 0.11

def make_unlock_click():
    t = np.arange(int(0.09 * SR), dtype=np.float32) / SR
    c1 = np.sin(2 * np.pi * 980 * t) * np.exp(-t * 140)
    t2 = np.maximum(0.0, t - 0.032)
    c2 = (t >= 0.032) * np.sin(2 * np.pi * 1960 * t2) * np.exp(-t2 * 120)
    return (c1 * 0.7 + c2 * 0.9) * 0.12

def make_whoosh():
    n = int(0.26 * SR)
    rng = np.random.default_rng(42)
    noise = rng.standard_normal(n).astype(np.float32)
    b, a = butter(2, [280/(SR/2), 1600/(SR/2)], btype="band")
    filt = lfilter(b, a, noise)
    t = np.linspace(0, 1, n, dtype=np.float32)
    env = np.maximum(0.0, np.sin(np.pi * t)) ** 1.8
    return filt * env * 0.075

def make_snap():
    t = np.arange(int(0.14 * SR), dtype=np.float32) / SR
    return (np.sin(2 * np.pi * 620 * t) * np.exp(-t * 55) + 0.6 * np.sin(2 * np.pi * 1890 * t) * np.exp(-t * 95)) * 0.12

def make_word_hit():
    t = np.arange(int(0.28 * SR), dtype=np.float32) / SR
    return (np.sin(2 * np.pi * 110 * (1 + 1.5*np.exp(-t*40)) * t) * np.exp(-t * 14)) * 0.16

tick_wav = make_ui_tick()
chime_wav = make_verified_chime()
unlock_wav = make_unlock_click()
whoosh_wav = make_whoosh()
snap_wav = make_snap()
word_wav = make_word_hit()

# Scene 2: 3 panel entrances + metallic snap on broken-link convergence
place_sfx(s2["t_start"] + 1.2, whoosh_wav, -0.35)
place_sfx(s2["t_start"] + 9.5, whoosh_wav, 0.0)
place_sfx(s2["t_start"] + 17.5, whoosh_wav, 0.35)
place_sfx(s2["vo_end"] - 2.2, snap_wav, 0.0)

# Scene 3: Verified badge chime after logo lock + orbiting UI ticks
place_sfx(logo_lock_t + 1.65, chime_wav, 0.1)
for off in [3.2, 3.6, 4.0]:
    place_sfx(s3["t_start"] + off, tick_wav, -0.2 + 0.1*off)

# Scene 4 (Student): UI ticks on skill chips + Trim-Path connector draws + Verified chime on React 72 + QR
s4 = sc_map["scene_04"]
place_sfx(s4["t_start"] + 0.2, whoosh_wav)
for off in [5.5, 6.2, 16.5, 17.1, 17.7, 18.3]:
    place_sfx(s4["t_start"] + off, tick_wav, 0.15)
place_sfx(s4["t_start"] + 19.2, chime_wav, 0.0)

# Scene 5 (Organization): Tag snaps + ranked list settle whoosh + unlock click + consent chime
s5 = sc_map["scene_05"]
place_sfx(s5["t_start"] + 0.2, whoosh_wav)
for off in [5.8, 6.4, 7.0]:
    place_sfx(s5["t_start"] + off, tick_wav, -0.15)
place_sfx(s5["t_start"] + 12.2, whoosh_wav, 0.1)
place_sfx(s5["t_start"] + 24.5, unlock_wav, 0.0)
place_sfx(s5["t_start"] + 27.5, chime_wav, 0.15)

# Scene 6 (University): Bar chart growth ticks + shimmer
s6 = sc_map["scene_06"]
place_sfx(s6["t_start"] + 0.2, whoosh_wav)
for i in range(5):
    place_sfx(s6["t_start"] + 8.5 + i * 0.22, tick_wav, -0.2 + i*0.1)

# Scene 7 (Admin MFA): MFA tick + confirm review chime + audit tick
s7 = sc_map["scene_07"]
place_sfx(s7["t_start"] + 0.2, whoosh_wav)
for i in range(4):
    place_sfx(s7["t_start"] + 2.2 + i * 0.12, tick_wav, 0.0)
place_sfx(s7["t_start"] + 15.8, chime_wav, 0.1)
place_sfx(s7["t_start"] + 22.0, unlock_wav, -0.1)

# Scene 8 (Why AptoHire): 3 percussive word hits for SKILLS / EVIDENCE / OPPORTUNITY
for off in [0.35, 0.95, 1.55]:
    place_sfx(s8["vo_end"] + off, word_wav, 0.0)
place_sfx(s8["vo_end"] + 0.95, chime_wav, 0.0) # Gold accent on EVIDENCE

# Scene 9 (Behind the Build): 4 tool chip ticks
for i in range(4):
    place_sfx(s9["t_start"] + 6.0 + i * 1.6, tick_wav, -0.25 + i*0.16)

# Scene 10 (Architecture): Unlock clicks as Gold data packets pass each Lock boundary!
for off in [3.2, 5.8, 8.4]:
    if s10["t_start"] + off < s10["t_end"] - 0.5:
        place_sfx(s10["t_start"] + off, unlock_wav, -0.2 + 0.05*off)

# Scene 12 (Roadmap): 3 milestone node pops
s12 = sc_map["scene_12"]
for off in [2.5, 5.6, 8.8]:
    if s12["t_start"] + off < s12["t_end"] - 0.5:
        place_sfx(s12["t_start"] + off, tick_wav, 0.0)

# Mix VO + Music + SFX and export raw WAV, then master to -14 LUFS via FFmpeg!
mix_L = vo_warm * 0.86 + music_L + sfx_L
mix_R = vo_warm * 0.86 + music_R + sfx_R
peak = max(np.max(np.abs(mix_L)), np.max(np.abs(mix_R)), 1e-6)
if peak > 0.96:
    mix_L *= 0.96 / peak
    mix_R *= 0.96 / peak

stereo_i16 = np.clip(np.stack([mix_L, mix_R], axis=1) * 32767.0, -32768, 32767).astype(np.int16)
raw_master = os.path.join(OUT_DIR, "master_raw.wav")
wavfile.write(raw_master, SR, stereo_i16)

lufs_wav = os.path.join(OUT_DIR, "master_soundtrack.wav")
lufs_mp3 = os.path.join(OUT_DIR, "master_soundtrack.mp3")
subprocess.run([
    "ffmpeg", "-y", "-i", raw_master,
    "-af", "loudnorm=I=-14:TP=-1.5:LRA=11",
    "-ar", "44100", "-ac", "2", lufs_wav
], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
subprocess.run([
    "ffmpeg", "-y", "-i", lufs_wav,
    "-codec:a", "libmp3lame", "-b:a", "192k", lufs_mp3
], check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
print("Master soundtrack rendered & normalized to -14 LUFS:", lufs_mp3, os.path.getsize(lufs_mp3), "bytes")
