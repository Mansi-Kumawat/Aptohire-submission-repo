import os, base64, json
from PIL import Image

os.makedirs("project/web/assets", exist_ok=True)

# 1. Optimize B-roll plates to crisp 1600x900 WebP
broll_map = {
    "broll_student_cold": "project/assets/broll_scene01_student_cold.jpg",
    "broll_recruiter": "project/assets/broll_scene01_recruiter.jpg",
    "broll_founders": "project/assets/broll_scene09_founders.jpg",
    "broll_student_warm": "project/assets/broll_scene13_student_warm.jpg",
}

for key, src in broll_map.items():
    im = Image.open(src).convert("RGB").resize((1600, 900), Image.Resampling.LANCZOS)
    im.save(f"project/web/assets/{key}.webp", "WEBP", quality=84)

# 2. Copy/optimize real live portal captures for Portal Inspector & PIP verification
portal_snaps = {
    "public_home": "audit/captures_v2/public_home.png",
    "public_demo": "audit/captures_v2/public_demo.png",
    "public_fairness": "audit/captures_v2/public_fairness.png",
    "student_home": "audit/captures_v2/stu_mock_home.png",
    "student_submit": "audit/captures_v2/student_submissions_new.png",
    "student_scorecard": "audit/captures/student_scorecard_react.png",
    "student_sharing": "audit/captures_v2/stu_sharing.png",
    "student_resume": "audit/captures_v2/stu_mock_resume.png",
    "org_home": "audit/captures_v2/org_unlocked_home.png",
    "org_post_job": "audit/captures_v2/org_unlocked_jobs_new.png",
    "org_candidates": "audit/captures_v2/org_unlocked_candidates.png",
    "org_requests": "audit/captures_v2/org_unlocked_requests.png",
    "org_pipeline": "audit/captures_v2/org_unlocked_pipeline.png",
    "uni_overview": "audit/captures/uni_dashboard.png",
    "uni_skills": "audit/captures_v2/uni_skills.png",
    "uni_placements": "audit/captures_v2/uni_placements.png",
    "admin_mfa": "audit/captures/admin_mfa.png",
    "admin_dashboard": "audit/captures_v2/adm_dashboard.png",
    "admin_approvals": "audit/captures_v2/adm_approvals.png",
    "admin_reviews": "audit/captures_v2/adm_reviews.png",
    "admin_tickets": "audit/captures_v2/adm_tickets_and_appeals.png",
    "admin_audit": "audit/captures_v2/adm_audit_log.png",
}

for key, src in portal_snaps.items():
    im = Image.open(src).convert("RGB").resize((1440, 810), Image.Resampling.LANCZOS)
    im.save(f"project/web/assets/{key}.webp", "WEBP", quality=82)

# Copy master audio to web/assets
import shutil
shutil.copy("project/audio/master_soundtrack.mp3", "project/web/assets/master_soundtrack.mp3")

total_bytes = sum(os.path.getsize(os.path.join("project/web/assets", f)) for f in os.listdir("project/web/assets") if f.endswith(".webp"))
print(f"Prepared {len(broll_map) + len(portal_snaps)} WebP assets ({total_bytes/1024/1024:.2f} MB total) + master_soundtrack.mp3!")
