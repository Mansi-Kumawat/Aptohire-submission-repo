import os, json
from faster_whisper import WhisperModel
WAV_DIR="project/audio_wav"
model = WhisperModel("base.en", device="cpu", compute_type="int8")
out={}
for f in ["vo_08_09_why_build","vo_10_11_arch_market","vo_12_13_roadmap_close"]:
    segs,info = model.transcribe(os.path.join(WAV_DIR,f+".wav"), language="en", word_timestamps=True, beam_size=5)
    words=[]
    for s in segs:
        for w in (s.words or []):
            words.append([round(w.start,3), round(w.end,3), w.word.strip()])
    out[f]=words
    print("="*70); print(f)
    for w in words: print(f"  {w[0]:6.2f} {w[1]:6.2f}  {w[2]}")
json.dump(out, open("project/audio/word_timing.json","w"), indent=1)
