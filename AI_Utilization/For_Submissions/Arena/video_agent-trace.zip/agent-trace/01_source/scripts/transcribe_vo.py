import os, json
from faster_whisper import WhisperModel

WAV_DIR = "project/audio_wav"
files = [
    "vo_01_hook","vo_02_problem","vo_03_intro","vo_04_student","vo_05_organization",
    "vo_06_university","vo_07_admin","vo_08_09_why_build","vo_10_11_arch_market","vo_12_13_roadmap_close"
]
model = WhisperModel("base.en", device="cpu", compute_type="int8")
out = {}
for f in files:
    segs, info = model.transcribe(os.path.join(WAV_DIR, f + ".wav"), language="en", vad_filter=False, beam_size=5)
    rows = []
    for s in segs:
        rows.append({"start": round(s.start,2), "end": round(s.end,2), "text": s.text.strip()})
    out[f] = rows
    print("="*80)
    print(f, "| duration", round(info.duration,2))
    for r in rows:
        print(f"  [{r['start']:6.2f} -> {r['end']:6.2f}] {r['text']}")
json.dump(out, open("project/audio/vo_transcript.json","w"), indent=2)
