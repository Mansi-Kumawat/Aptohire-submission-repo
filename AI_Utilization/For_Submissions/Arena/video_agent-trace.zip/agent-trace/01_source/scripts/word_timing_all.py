import os, json
from faster_whisper import WhisperModel
WAV_DIR="project/audio_wav"
files=["vo_01_hook","vo_02_problem","vo_03_intro","vo_04_student","vo_05_organization",
       "vo_06_university","vo_07_admin","vo_08_09_why_build","vo_10_11_arch_market","vo_12_13_roadmap_close"]
model = WhisperModel("base.en", device="cpu", compute_type="int8")
out={}
for f in files:
    segs,info = model.transcribe(os.path.join(WAV_DIR,f+".wav"), language="en", word_timestamps=True, beam_size=5)
    words=[]
    for s in segs:
        for w in (s.words or []):
            t=w.word.strip()
            if t: words.append([round(w.start,3), round(w.end,3), t])
    out[f]=words
    print(f, len(words))
json.dump(out, open("project/audio/word_timing.json","w"), indent=1)
print("saved")
