# Security review — what was removed and why

This archive was assembled from a working directory that also held live-crawl
artefacts. Everything below was reviewed before packaging.

For the short version, see [SUMMARY.md](SUMMARY.md).

## Redacted

| Item | Where | Action |
|---|---|---|
| Demo admin TOTP secret (`DEMO-ADMIN-…`) | `admin_mfa*.png`, `adm_account_and_security*.png`, `deep_report.json`, `portal_report.json` | **Excluded entirely** — the screen is a 2FA enrolment page, so the secret and its QR sit in the pixels and in the OCR dumps |
| Demo account password | `crawl_spa_nav.py` | Replaced with `os.environ.get("APTOHIRE_DEMO_PASSWORD", "")` |
| Alternate demo password | `crawl_deep.py` | Same env-var substitution |
| Demo-account email addresses | several scripts | Normalised to `@demo.example` placeholders |

## Excluded for size, not secrecy

| Item | Size | Why it's not here |
|---|---|---|
| `master_soundtrack.mp3` | 7.4 MB | Already inside the delivered film |
| `web/assets/*.webp` | 2.1 MB | Derived — `prepare_assets.py` regenerates all 32 |
| `fonts/`, `assets/` | 1.1 MB | Third-party font binaries and generated B-roll plates |
| Full capture sets | 55 MB | 231 screenshots; the 21 the film actually uses are included |

## Deliberately kept

The 21 portal screenshots in `05_portal_screens/` contain demo content that is
**explicitly fictional** — the product itself says so on every page
("All people, universities and organizations shown are fictional", "Demo only ·
No real candidate data"). Candidate IDs like `K7F2` are blind-hiring
placeholders, not identities. They are the visual evidence for the film's
claims, so they belong in a build record.

## Never present in the archive

- No API keys, tokens, `.env` files, or cloud credentials
- No `localStorage` / `sessionStorage` dumps or browser cookie jars
- No real personal data — every name, email and ID in the captures is demo seed data
- No absolute build paths (rewritten to archive-relative on copy)

## If you publish this

The screenshots show a demo deployment. If your production deployment differs,
re-capture before publishing rather than reusing these, and check with whoever
owns the live demo accounts whether the demo credentials should still work.
