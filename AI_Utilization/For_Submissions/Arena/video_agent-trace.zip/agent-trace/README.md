# agent-trace — AptoHire Product Film

A sanitized, reproducible record of how the film was built: the source that
drives it, the render pipeline, the brand assets, the narration takes, and the
portal screenshots the footage is made from.

> **Start with [SUMMARY.md](SUMMARY.md)** if you want the short version:
> what's here, what was stripped, and what to be aware of.
>
> **Nothing here is required to watch the film.** If you only want the finished
> product, use `AptoHire_Film.zip`. This archive is the build log.

---

## What's in the film

| | |
|---|---|
| Runtime | 5:09.73 (309.75 s), 30 fps CFR |
| Master | 1920×1080, H.264 High, ~1.1 Mbps, 42 MB |
| Audio | AAC 192 kbps stereo, −14.4 LUFS integrated |
| Scenes | 13 chapters across 5 acts |
| Narration | 10 recorded takes, 103 timed caption cues |
| Portals | 5 live apps (student / organization / university / admin / public) |

---

## Structure

```
agent-trace/
├── README.md                  this file — what the film is, how to rebuild
├── SUMMARY.md                 read first: what shipped, what was removed
├── MANIFEST.md                every file, with a checksum
├── SECURITY.md                what was redacted or excluded, and why
├── 01_source/                 the film itself (editable)
│   ├── web/                   index.html, core.js, engine.js, scenes_a|b|c.js, film.css …
│   ├── scripts/               the build chain, in order
│   └── data/                  timeline.json, captions.json
├── 02_pipeline/               how frames became an MP4
│   ├── render_mp4.py          deterministic frame capture
│   ├── encode_mp4.sh          x264 + audio mux
│   └── shoot.py               ad-hoc QA screenshots
├── 03_brand/                  logo kit extracted from the supplied JPEG
├── 04_audio/                  10 narration takes + word timings
├── 05_portal_screens/         the 21 screenshots used in the film
└── 06_capture_tooling/        the crawlers that produced them (secrets stripped)
```

---

## Rebuild from scratch

```bash
# 1. assets: portal screenshots → WebP, plus the audio master
python3 01_source/scripts/prepare_assets.py

# 2. audio master (only if you change the narration)
python3 01_source/scripts/build_audio_master.py

# 3. captions from word timings
python3 01_source/scripts/build_captions.py

# 4. bundle the self-contained single file
python3 01_source/scripts/build_single_file.py

# 5. render the MP4
python3 02_pipeline/render_mp4.py     # ~19 min at 1080p/30
sh     02_pipeline/encode_mp4.sh
```

Step 5 is intentionally *not* screen recording. The film exposes a
deterministic clock (`window.__seekTo(t)`), so the renderer seeks to
`t = k/30` for all 9,292 frames and screenshots each one. The result is
exact at 30 fps with no dropped or duplicated frames, and it is reproducible
run to run.

---

## The 13 scenes

| # | in | out | scene |
|---|---|---|---|
| 01 | 0.000 | 26.541 | The hook — skills ignored, resumes trusted |
| 02 | 26.541 | 57.247 | The visibility gap |
| 03 | 57.247 | 85.050 | Introducing AptoHire |
| 04 | 85.050 | 119.294 | Student portal |
| 05 | 119.294 | 157.005 | Organization portal |
| 06 | 157.005 | 188.304 | University portal |
| 07 | 188.304 | 217.733 | Admin portal |
| 08 | 217.733 | 231.183 | Why it's different |
| 09 | 231.183 | 250.785 | Behind the build |
| 10 | 250.785 | 263.819 | Architecture |
| 11 | 263.819 | 278.296 | Market |
| 12 | 278.296 | 292.688 | Model & roadmap |
| 13 | 292.688 | 309.750 | Close |

---

## Two known issues that were fixed

**Logo.** The first cut used a hand-drawn SVG approximation. It was replaced
with the real mark, alpha-extracted from the supplied 1600×893 JPEG and split
into mark / wordmark / lockup at 2× native resolution. See `03_brand/`.

**The 1:01 glitch.** At 61.0–62.0 s three things collided: the question card
faded in and out simultaneously, its per-word stagger began after the fade-out
had already started, and the logo was still lit beneath it. The question also
appeared 2.5 s *after* the narration asks it. Rebuilt as a single stage — logo
settles, question rises beneath it at 58.95 s, clears, beat, then the
positioning line. Boundaries are now exclusive; see the `// ----- The question`
block in `01_source/web/scenes_a.js`.
