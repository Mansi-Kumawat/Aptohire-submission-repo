# Privacy, Scope and Limitations

## Excluded
- Passwords, API keys, access tokens, credentials and other secrets.
- Account numbers, ticket identifiers, private email addresses and other private contact details.
- Precise location details.
- Unrelated personal, health, financial or educational-record details.
- Hidden internal chain-of-thought or private agent reasoning.

## Retained
Startup-relevant project information: public-facing founder names and role descriptions used in the deck, product positioning, deliverable names, narrative structure and explicitly labelled business assumptions.

## Scope limitation
This is a curated summary based on the AptoHire-related context available at generation time. It is not a complete verbatim transcript and does not include hidden internal reasoning or tool internals.

## Accuracy notes
- Illustrative product visuals are not live screenshots.
- Market sizing and pricing figures are unvalidated planning assumptions.
- Revenue streams are proposals, not claims of current revenue.
- Prototype completion does not establish production readiness.
