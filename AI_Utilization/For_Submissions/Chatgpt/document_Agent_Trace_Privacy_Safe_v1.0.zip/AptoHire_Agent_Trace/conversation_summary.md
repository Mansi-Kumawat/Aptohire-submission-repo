# AptoHire Conversation Summary

## Project and positioning
- **Project:** AptoHire, a skills-first hiring platform.
- **Positioning:** “Prove Skills. Match Potential.”
- **Core story:** Talent exists broadly, but practical capability can be difficult to demonstrate and evaluate through conventional hiring signals.
- **Initial go-to-market hypothesis:** Start with universities and placement teams, validate one focused use case, then expand to employer-side workflows if evidence supports it.
- **Project website referenced in context:** https://aptohire.vercel.app

## Founders shown in the pitch deck
- **Ravi Prakash — Founder:** Originated the idea and contributed to early product discussions.
- **Mansi Kumawat — Co-founder & Team Lead:** Coordination, documentation, full-stack execution, frontend and UI iteration.
- **Lakshmi Narayan — Co-founder:** Technical guidance, technology/UI input and testing feedback.
These are project-context descriptions. No equity split, formal employment arrangement, or unprovided credentials were inferred.

## Storytelling direction
The user liked the previous demo's storytelling and content, but not its visual execution. The requested narrative was:
1. Start with a strong hook.
2. Explain the problem and who experiences it.
3. Introduce AptoHire as the solution.
4. Show product experience and differentiators.
5. Cover market opportunity and competitive context.
6. Explain revenue hypotheses and scalability.
7. Present the founding team and execution journey.
8. Close with a clear ask.

## Demo video work summarized
A concept-style narrated demo was prepared with chapters on the problem, AptoHire, student journey and evidence, employer discovery, university value, differentiation, AI-assisted development, system overview, market opportunity, proposed business model, roadmap and closing.
**Limitation:** Visuals were illustrative mockups, not captured from the live application. Unverified or planned features should not be represented as shipped. A faithful product demo needs screenshots or recordings of verified working flows.

## Pitch deck work summarized
A 14-slide editable PowerPoint and interactive HTML presentation were created:
1. Cover / hook — “Talent is everywhere. Proof is harder to find.”
2. Problem — weak skills signalling for students, universities and employers.
3. Why now — education-system scale and employability context.
4. Solution — AptoHire's evidence-led skills visibility and discovery hypothesis.
5. Product experience — student, employer and university perspectives.
6. Differentiation — evidence, institution workflow, permissions and trust.
7. Competitive landscape — CVs, portfolios, job boards/ATS and campus systems.
8. Market sizing — TAM, SAM and SOM planning scenarios.
9. Revenue model — paid pilots, institutional subscriptions, premium integrations/analytics, and later employer services.
10. Go-to-market — discovery, pilot design and proof of value.
11. Founding team and responsibilities.
12. AI-assisted execution journey.
13. Roadmap, risks and trust requirements.
14. The ask — pilot partners, buyer access and build support.

## Market and revenue assumptions
Illustrative planning scenarios in the deck:
- **TAM:** ₹150–1,500 crore annually.
- **SAM:** ₹15–160 crore annually.
- **Three-year SOM:** ₹0.3–4 crore ARR.

These were explicitly treated as unvalidated assumptions, not verified market forecasts, actual revenue, traction, signed pilots or confirmed willingness-to-pay. Institution counts and pricing need validation.

## AI-assisted development narrative
Project context describes Gemini, Claude, ChatGPT and Arena AI supporting research, planning, prompt refinement and coding workflows, with the team reviewing, testing and iterating. AI-assisted execution was distinguished from production readiness; QA, security/privacy checks and deployment verification remain validation gates.

## Deliverables created or referenced
Created in the recent pitch-deck turn:
- `AptoHire_Investor_Judging_Pitch_Deck.pptx` — editable 14-slide PowerPoint.
- `AptoHire_Interactive_Investor_Pitch_Deck.html` — interactive browser deck with navigation, transitions, speaker notes and full-screen support.
- `AptoHire_Investor_Judging_Pitch_Deck_Pack.zip` — bundle of the above and a README.

Earlier related deliverables referenced in the available context:
- concept-style demo video and video pack;
- Ideation & Validation pack;
- Product & Technical Design pack;
- Market & Competitive Intelligence pack;
- Business & Pitching pack;
- Financial & Operations pack;
- Legal, IP & Compliance pack;
- Topics 7–9 pack;
- Market Potential and Startup Viability notes;
- AI Utilization Report pack.

The earlier artifacts are listed as historical references only; this trace ZIP does not bundle them.

## Recommended next steps
1. Replace illustrative product mockups with screenshots of verified live flows.
2. Confirm which features are implemented, in progress, or planned.
3. Validate target institutions and buyer personas with interviews.
4. Test pricing and willingness-to-pay with budget owners.
5. Source-check market data and document assumptions.
6. Define pilot success metrics and privacy/security controls.
7. Tailor the ask to the actual competition or investor brief.
